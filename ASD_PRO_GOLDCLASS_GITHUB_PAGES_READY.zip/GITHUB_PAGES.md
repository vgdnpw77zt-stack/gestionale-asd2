# GitHub Pages — ASD Pro Goldclass

Questa configurazione usa `HashRouter`, quindi le rotte React non producono 404 su GitHub Pages.

## Pubblicazione
1. Crea un repository GitHub e carica questo progetto sul branch `main`.
2. In **Settings → Pages**, scegli **GitHub Actions**.
3. Il workflow `.github/workflows/deploy-pages.yml` costruisce `frontend` e pubblica `frontend/build`.

## Backend
Il frontend completo continua a usare FastAPI/MongoDB tramite `REACT_APP_BACKEND_URL`. GitHub Pages ospita solo il frontend: per login, dati, pagamenti e tutte le funzioni server serve un backend pubblico separato.

Se `REACT_APP_BACKEND_URL` non è impostata, il sito può essere aperto per verificare l'interfaccia, ma le chiamate API non avranno un backend a cui collegarsi.
