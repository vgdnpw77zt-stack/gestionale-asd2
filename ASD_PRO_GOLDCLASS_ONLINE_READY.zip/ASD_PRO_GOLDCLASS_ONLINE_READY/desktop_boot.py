# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import socket

from app import app
from asd_app.core import init_db, LOG_DIR

HOST = os.environ.get("ASD_HOST", "127.0.0.1")

def find_free_port(start_port: int = 5000) -> int:
    for port in range(start_port, start_port + 50):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                sock.bind((HOST, port))
                return port
            except OSError:
                continue
    raise RuntimeError("Nessuna porta libera disponibile.")

def prepare_app() -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    init_db()

prepare_app()
