# -*- coding: utf-8 -*-
from asd_app.core import app, init_db, LOG_DIR

# Registrazione centralizzata di tutte le funzioni dell'applicazione.
# Un solo punto di bootstrap evita import duplicati tra launcher e build.
_ROUTE_MODULES = (
    "routes_auth", "routes_tenants", "routes_dashboard", "routes_tesserati",
    "routes_corsi", "routes_presenze", "routes_pagamenti", "routes_ricevute",
    "routes_fatture", "routes_contabilita", "routes_documenti", "routes_settings",
    "routes_profile", "routes_backup", "routes_import_admin",
    "routes_license_admin", "routes_minori", "routes_collaboratori", "routes_lavoro_sportivo",
    "routes_collab_receipts", "routes_danza", "routes_guided",
    "routes_prenotazioni", "routes_promemoria", "routes_utenti",
    "routes_user_permissions", "routes_giornata",
)

for _module_name in _ROUTE_MODULES:
    __import__(f"asd_app.{_module_name}")

def start_local_server(host="127.0.0.1", port=5000):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    init_db()
    app.run(host=host, port=port, debug=False, use_reloader=False)

if __name__ == "__main__":
    start_local_server()
