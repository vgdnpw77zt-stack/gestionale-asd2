# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import sys
import threading
import time
import traceback
import webbrowser
from urllib.request import urlopen, Request
from urllib.error import HTTPError
from werkzeug.serving import make_server

try:
    import webview
except Exception:
    webview = None

from desktop_boot import app, HOST, find_free_port

class ServerThread(threading.Thread):
    def __init__(self, flask_app, host: str, port: int):
        super().__init__(daemon=True)
        self.server = make_server(host, port, flask_app, threaded=True)
        self.ctx = flask_app.app_context()
        self.ctx.push()

    def run(self):
        self.server.serve_forever()

    def shutdown(self):
        try:
            self.server.shutdown()
        finally:
            try:
                self.ctx.pop()
            except Exception:
                pass

def wait_ready(url: str, timeout: float = 30.0) -> bool:
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        try:
            with urlopen(Request(url, headers={"User-Agent": "ASD-Pro"}), timeout=1.5) as resp:
                if 200 <= resp.status < 500:
                    return True
        except HTTPError as exc:
            if 300 <= exc.code < 500:
                return True
            last = exc
        except Exception as exc:
            last = exc
        time.sleep(0.35)
    print("Server non pronto:", last)
    return False

def main() -> int:
    port = find_free_port(int(os.environ.get("ASD_PORT", "5000")))
    url = f"http://{HOST}:{port}"
    server = ServerThread(app, HOST, port)
    server.start()

    if not wait_ready(url):
        return 1

    # Default: try native app window. If WebView fails, browser fallback.
    try:
        if webview is None:
            raise RuntimeError("pywebview non disponibile")
        webview.create_window(
            os.environ.get("ASD_APP_TITLE", "ASD Pro Goldclass"),
            url,
            width=1280,
            height=850,
            min_size=(1024, 700),
            confirm_close=True,
        )
        if sys.platform == "darwin":
            webview.start(gui="cocoa", debug=False)
        else:
            webview.start(debug=False)
    except Exception:
        traceback.print_exc()
        webbrowser.open(url)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
    finally:
        try:
            server.shutdown()
        except Exception:
            pass
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
