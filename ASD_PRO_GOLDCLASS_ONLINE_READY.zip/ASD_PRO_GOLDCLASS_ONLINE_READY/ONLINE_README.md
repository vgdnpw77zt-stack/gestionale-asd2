# ASD Pro Goldclass - Online Ready

Questa cartella deriva dal MASTER desktop e mantiene il gestionale Flask originale.

## Modifiche per hosting
- `wsgi.py`: inizializza il database e pubblica l'app Flask a Gunicorn.
- `gunicorn` aggiunto ai requisiti.
- `Dockerfile`: avvio web in produzione.
- `render.yaml`: servizio Render con disco persistente montato in `/var/data`.
- `ASD_PRO_DATA_DIR=/var/data/asd-pro`: SQLite, documenti, media, PDF e backup restano sul disco persistente.
- `ASD_DEV_BYPASS=1`: modalità proprietario/sviluppatore per questa installazione sorgente. La chiave privata di licenza NON è inclusa.
- `ASD_ADMIN_PASSWORD`: va impostata nel pannello hosting e non salvata nel repository.

## Nota importante
Un hosting senza disco persistente può perdere database e file a ogni redeploy. Per questo la configurazione richiede un persistent disk.
