from app import app, init_db

# Initialize schema/users once when the web process starts.
init_db()

application = app
