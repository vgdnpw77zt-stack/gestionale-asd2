from .core import *


def _minor_issue_state(row: dict) -> dict:
   linked = bool(row.get('tesserato_id_link'))
   cert_key, cert_label = get_certificato_status(row.get('certificato_scadenza') or '') if linked else ('n/d', 'Non collegato')
   has_parent = bool((row.get('genitore') or '').strip())
   has_contact = bool((row.get('telefono_genitore') or '').strip() or (row.get('email_genitore') or '').strip())
   consent_ok = int(row.get('consenso_firmato') or 0) == 1
   guardian_problem = not (has_parent and has_contact and consent_ok)
   cert_problem = cert_key in {'mancante', 'scaduto'}
   cert_warning = cert_key == 'in_scadenza'

   if linked:
       if cert_problem and guardian_problem:
           tone = 'error'
           label = 'Certificato + consenso da completare'
       elif guardian_problem:
           tone = 'error'
           label = 'Consenso / tutela da completare'
       elif cert_problem:
           tone = 'error'
           label = 'Certificato critico'
       elif cert_warning:
           tone = 'warning'
           label = 'Certificato in scadenza'
       else:
           tone = 'ok'
           label = 'Tutela completa'
   else:
       if guardian_problem:
           tone = 'warning'
           label = 'Consenso / tutela da completare'
       else:
           tone = 'ok'
           label = 'Scheda manuale completa'

   cert_badge = "<span class='small-muted'>Scheda manuale</span>"
   if linked:
       cert_cls = 'valido' if cert_key == 'valido' else ('in_scadenza' if cert_key == 'in_scadenza' else 'scaduto')
       cert_dot = 'green' if cert_key == 'valido' else ('yellow' if cert_key == 'in_scadenza' else 'red')
       cert_badge = f"<span class='badge {cert_cls}'><span class='badge-dot dot-{cert_dot}'></span>{e(cert_label)}</span>"

   status_cls = 'valido' if tone == 'ok' else ('in_scadenza' if tone == 'warning' else 'scaduto')
   status_dot = 'green' if tone == 'ok' else ('yellow' if tone == 'warning' else 'red')
   linked_html = "<span class='pill'>Auto</span>" if linked else "<span class='small-muted'>Manuale</span>"
   row_class = 'table-row-ok' if tone == 'ok' else ('table-row-warning' if tone == 'warning' else 'table-row-error')
   return {
       'tone': tone,
       'label': label,
       'row_class': row_class,
       'status_badge': f"<span class='badge {status_cls}'><span class='badge-dot dot-{status_dot}'></span>{e(label)}</span>",
       'cert_badge': cert_badge,
       'linked_html': linked_html,
       'sort_key': 0 if tone == 'error' else (1 if tone == 'warning' else 2),
   }


@app.route("/minori", methods=["GET", "POST"])
@login_required
def minori():
   conn = db()
   c = conn.cursor()

   if request.method == "POST":
       try:
           nome = require_non_empty(request.form.get("nome", ""), "Nome")
           cognome = require_non_empty(request.form.get("cognome", ""), "Cognome")
           genitore = require_non_empty(request.form.get("genitore", ""), "Genitore", 140)
           telefono_genitore = truncate(request.form.get("telefono_genitore", "").strip(), 40)
           email_genitore = normalize_email(request.form.get("email_genitore", "").strip(), 140)
           consenso_firmato = 1 if request.form.get("consenso_firmato") == "1" else 0
           data_consenso_raw = request.form.get("data_consenso", "").strip()
           data_consenso = require_valid_date(data_consenso_raw, "la data consenso") if data_consenso_raw else ""
           note_consenso = truncate(request.form.get("note_consenso", "").strip(), 400)
           if consenso_firmato and not data_consenso:
               raise ValueError("Se il consenso è firmato, inserisci anche la data del consenso.")
       except ValueError as exc:
           conn.close()
           return layout(alert_html(str(exc), "error"))

       c.execute(
           """
           INSERT INTO minori(nome, cognome, genitore, telefono_genitore, email_genitore, consenso_firmato, data_consenso, note_consenso)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)
           """,
           (nome, cognome, genitore, telefono_genitore, email_genitore, consenso_firmato, data_consenso, note_consenso),
       )
       rec_id = c.lastrowid
       conn.commit()
       conn.close()
       log_audit("minor_create", details=f"Minore registrato: {nome} {cognome}", entity_type="minore", entity_id=str(rec_id))
       return redirect_with_message("/minori", "Scheda minore salvata correttamente.", "success")

   linked_rows = c.execute(
       """
       SELECT m.id, t.id AS tesserato_id_link, t.nome, t.cognome, t.data_nascita, t.certificato_scadenza,
              m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato, m.data_consenso, m.note_consenso
       FROM tesserati t
       LEFT JOIN minori m ON m.tesserato_id = t.id
       ORDER BY t.cognome, t.nome
       """
   ).fetchall()
   manual_rows = c.execute(
       """
       SELECT m.id, NULL AS tesserato_id_link, m.nome, m.cognome, NULL AS data_nascita, '' AS certificato_scadenza,
              m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato, m.data_consenso, m.note_consenso
       FROM minori m
       WHERE m.tesserato_id IS NULL
       ORDER BY m.cognome, m.nome
       """
   ).fetchall()
   conn.close()

   rows = []
   for r in linked_rows:
       is_minor, _age = get_minor_status_from_birthdate(r['data_nascita'] or '')
       if not is_minor:
           continue
       row = dict(r)
       row.update(_minor_issue_state(row))
       rows.append(row)
   for r in manual_rows:
       row = dict(r)
       row.update(_minor_issue_state(row))
       rows.append(row)

   rows = sorted(rows, key=lambda item: (item['sort_key'], str(item.get('cognome') or '').lower(), str(item.get('nome') or '').lower()))
   firmati = sum(1 for r in rows if int(r['consenso_firmato'] or 0) == 1)
   severe = sum(1 for r in rows if r['tone'] == 'error')
   warnings = sum(1 for r in rows if r['tone'] == 'warning')
   drawer_requested = request.args.get('new') == '1'
   month_now, year_now = current_month_year()
   a7_alerts = get_operational_alerts(month_now, year_now)

   html_rows = []
   for r in rows:
       athlete_link = f"<a href='/tesserati?edit={r['tesserato_id_link']}&drawer=1'>Apri atleta</a>" if r['tesserato_id_link'] else "<span class='small-muted'>Scheda autonoma</span>"
       a7_status = render_member_status_badge(compute_member_status(r['tesserato_id_link'], month_now, year_now, a7_alerts)) if r['tesserato_id_link'] else r['status_badge']
       html_rows.append(f"""
       <tr class='{r['row_class']}'>
           <td><strong>{e(r['nome'])} {e(r['cognome'])}</strong><div class='small-muted'>{r['linked_html']}</div></td>
           <td>{e(format_display_date(r['data_nascita'])) or '-'}</td>
           <td>{e(r['genitore'] or '-')}</td>
           <td>{e(r['telefono_genitore'] or '-')}</td>
           <td>{e(r['email_genitore'] or '-')}</td>
           <td>{r['cert_badge']}</td>
           <td>{a7_status}<div class='small-muted'>Auto A.7</div></td>
           <td>
               <div class='actions'>
                   {athlete_link}
                   <form method='POST' action='/minori/delete' class='inline-form' onsubmit="return confirm('Eliminare questa scheda minore?');">
                       {csrf_input()}
                       <input type='hidden' name='id' value='{r['id'] or ''}'>
                       <button class='danger' {'disabled' if not r['id'] else ''}>Elimina</button>
                   </form>
               </div>
           </td>
       </tr>""")
   table_html = ''.join(html_rows) if html_rows else "<tr><td colspan='8'><div class='empty-state'>Nessun minore censito.</div></td></tr>"

   drawer = f"""
   <div class='drawer-shell {'open' if drawer_requested else ''}'>
      <div class='drawer-backdrop' data-close-drawer='1'></div>
      <div class='drawer-panel'>
         <div class='drawer-head'>
            <div>
               <div class='kicker'>Nuova scheda</div>
               <h3 class='section-title'>Inserimento manuale minore</h3>
               <div class='small-muted'>Usa questa scheda solo quando ti serve una voce autonoma non derivata direttamente dalla sezione Tesserati.</div>
            </div>
            <a href='/minori' class='drawer-close'>×</a>
         </div>
         <form method='POST' class='form-row'>
            {csrf_input()}
            <div class='card soft' style='grid-column:1 / -1;'>
               <div class='form-row'>
                  <input name='nome' placeholder='Nome' required>
                  <input name='cognome' placeholder='Cognome' required>
                  <input name='genitore' placeholder='Genitore / esercente responsabilità' required>
                  <input name='telefono_genitore' placeholder='Telefono genitore'>
                  <input name='email_genitore' placeholder='Email genitore'>
                  <input name='data_consenso' placeholder='Data consenso (DD/MM/YYYY)'>
                  <label style='align-self:center;'><input type='checkbox' name='consenso_firmato' value='1'> Consenso firmato</label>
                  <textarea name='note_consenso' placeholder='Note consenso o documentazione collegata'></textarea>
               </div>
            </div>
            <div class='toolbar-actions' style='grid-column:1 / -1;'>
               <button class='cta-primary'>Salva scheda</button>
               <a href='/minori' style='align-self:center;'>Chiudi</a>
            </div>
         </form>
      </div>
   </div>
   """

   return layout(f"""
   <div class='app-section-hero'>
       <div class='kicker'>Tutela e consenso</div>
       <h2 class='section-title'>Minori</h2>
       <div class='small-muted'>Prima i casi critici, poi le verifiche, infine le schede già complete. Nessuna alternanza confusa tra ok e alert.</div>
       <div class='page-actions'>
         <a href='/minori?new=1' class='cta-primary'>Nuova scheda manuale</a>
         
       </div>
   </div>
   <div class='metric-strip'>
       <div class='metric-box'><div class='label'>Criticità forti</div><div class='value'>{severe}</div></div>
       <div class='metric-box'><div class='label'>Verifiche</div><div class='value'>{warnings}</div></div>
       <div class='metric-box'><div class='label'>Consensi registrati</div><div class='value'>{firmati}</div></div>
       <div class='metric-box'><div class='label'>Schede totali</div><div class='value'>{len(rows)}</div></div>
   </div>
   <div class='compact-grid'>
      <div class='card'>
         <div class='kicker'>Archivio minori</div>
         <h3 class='section-title'>Vista operativa</h3>
         <div class='small-muted'>Rosso quando manca consenso/tutela oppure il certificato è scaduto/mancante. Arancio per certificati in scadenza o verifiche leggere.</div>
      </div>
      <div class='mini-card'><strong>Sync da Tesserati</strong><div class='small-muted'>I minori collegati agli atleti ereditano il controllo certificato medico e si aggiornano senza doppio inserimento.</div></div>
      <div class='mini-card'><strong>Dati del genitore</strong><div class='small-muted'>Telefono ed email restano centrali per promemoria, documenti e verifiche rapide.</div></div>
      <div class='mini-card a7-mini'><strong>Stato automatico atleta</strong><div class='small-muted'>BLOCCATO se manca consenso/tutela o certificato. Non è cosmetico: viene letto anche da dashboard e promemoria.</div></div>
   </div>
   <div class='card'>
      <div class='table-toolbar'>
         <div>
            <div class='kicker'>Archivio minori</div>
            <h3 class='section-title' style='margin-bottom:4px;'>Elenco schede</h3>
            <div class='small-muted'>Il certificato medico e il consenso vengono letti insieme: consenso/tutela incompleti o certificato critico = rosso.</div>
         </div>
      </div>
      <table>
         <tr><th>Minore</th><th>Data nascita</th><th>Genitore</th><th>Telefono</th><th>Email</th><th>Certificato</th><th>Stato</th><th>Azioni</th></tr>
         {table_html}
      </table>
   </div>
   {drawer}
   <script>document.querySelectorAll('[data-close-drawer="1"]').forEach(function(el){{el.addEventListener('click', function(){{ window.location.href='/minori'; }});}});</script>
   """)


@app.route("/minori/delete", methods=["POST"])
@login_required
def minori_delete():
   rec_id = parse_int(request.form.get("id"), 0)
   if rec_id <= 0:
       return redirect_with_message("/minori", "Scheda minore non valida.", "error")
   conn = db()
   row = conn.execute("SELECT id, nome, cognome, tesserato_id FROM minori WHERE id=?", (rec_id,)).fetchone()
   if not row:
       conn.close()
       return redirect_with_message("/minori", "Scheda minore non trovata.", "warning")
   conn.execute("DELETE FROM minori WHERE id=?", (rec_id,))
   conn.commit()
   conn.close()
   log_audit("minor_delete", details=f"Scheda minore eliminata: {row['nome']} {row['cognome']}", entity_type="minore", entity_id=str(rec_id))
   return redirect_with_message("/minori", "Scheda minore eliminata.", "success")
