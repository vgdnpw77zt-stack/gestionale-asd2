from .core import *

# BACKUP
# ==============================
# Il backup è un archivio dati portabile. Il database reale vive dentro
# tenants/<slug>/asd.db; database/asd.db è mantenuto solo come alias per
# compatibilità con vecchie versioni.

BACKUP_FORMAT_VERSION = 2


def _migrate_legacy_backups() -> None:
    """Recupera una volta i backup creati dalle vecchie versioni locali."""
    try:
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        candidates = [BASE_DIR / "backups", BASE_DIR.parent / "backups"]
        seen = {p.resolve() for p in candidates if p.exists()}
        for source_dir in candidates:
            if not source_dir.exists() or not source_dir.is_dir():
                continue
            for source in source_dir.glob("*.zip"):
                if not source.is_file():
                    continue
                target = BACKUP_DIR / source.name
                if not target.exists():
                    shutil.copy2(source, target)
    except Exception:
        # Il backup corrente deve continuare a funzionare anche se una vecchia
        # cartella non è più accessibile.
        pass


def _backup_files() -> list[Path]:
    _migrate_legacy_backups()
    if not BACKUP_DIR.exists():
        return []
    return sorted(
        (p for p in BACKUP_DIR.glob("*.zip") if p.is_file() and p.name.startswith("backup_")),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )


def _backup_label(path: Path) -> str:
    try:
        return datetime.fromtimestamp(path.stat().st_mtime).strftime("%d/%m/%Y %H:%M")
    except Exception:
        return ""


@app.route("/backup")
@login_required
def backup_page():
    existing = _backup_files()
    latest_label = _backup_label(existing[0]) if existing else "Nessun backup disponibile"
    rows = []
    for path in existing[:20]:
        size_mb = path.stat().st_size / (1024 * 1024)
        rows.append(
            "<tr>"
            f"<td><b>{e(path.name)}</b><div class='small-muted'>{e(_backup_label(path))} · {size_mb:.2f} MB</div></td>"
            f"<td style='text-align:right;white-space:nowrap;'>"
            f"<a class='a2-btn' href='/backup/download/{quote(path.name)}'>Scarica</a> "
            f"<form method='POST' action='/backup/restore-saved/{quote(path.name)}' style='display:inline;' "
            f"onsubmit=\"return confirm('Ripristinare {e(path.name)}? Verrà creato prima un backup di sicurezza.');\">"
            f"{csrf_input()}<button class='warning'>Ripristina</button></form></td>"
            "</tr>"
        )
    saved_html = (
        "<div class='card form-panel'><div class='kicker'>Backup locali</div>"
        "<h3 class='section-title'>Backup già salvati</h3>"
        "<p class='small-muted'>Puoi scaricare oppure ripristinare direttamente un backup già presente sul computer. Non serve ricaricarlo manualmente.</p>"
        "<div style='overflow:auto;'><table class='data-table'><tbody>"
        + "".join(rows)
        + "</tbody></table></div></div>"
        if rows else ""
    )
    return layout(f"""
    <div class='app-section-hero'>
        <div class='kicker'>Dati ASD</div>
        <h2 class='section-title'>Backup completo</h2>
        <div class='small-muted'>Salva e ripristina dati, database, tenant, configurazioni, documenti, media e file dell'ASD.</div>
    </div>
    <div class='metric-strip'>
       <div class='metric-box'><div class='label'>Backup presenti</div><div class='value'>{len(existing)}</div></div>
       <div class='metric-box'><div class='label'>Ultimo backup</div><div class='value' style='font-size:1.1rem;line-height:1.2;'>{latest_label}</div></div>
    </div>
    <div class='card form-panel'>
        <div class='kicker'>Operazione guidata</div>
        <h3 class='section-title'>Genera backup completo</h3>
        <p class='small-muted'>Viene creato un ZIP locale e scaricato subito. Il file rimane anche nell'elenco dei backup salvati.</p>
        <form method='POST' action='/backup/create'>
            {csrf_input()}
            <button>Crea e scarica backup</button>
        </form>
    </div>
    {saved_html}
    <div class='card form-panel'>
        <div class='kicker'>Restore da file</div>
        <h3 class='section-title'>Importa un backup ZIP</h3>
        <p class='small-muted'>Prima del ripristino viene creato automaticamente un backup di sicurezza dello stato attuale.</p>
        <form method='POST' action='/backup/restore' enctype='multipart/form-data' onsubmit="return confirm('Ripristinare questo backup? Verrà creato prima un backup di sicurezza dello stato attuale.');">
            {csrf_input()}
            <input type='file' name='backup_file' accept='.zip' required>
            <button class='warning'>Ripristina backup</button>
        </form>
    </div>
    """)


def _safe_zip_add_file(zip_handle, file_path, arcname, added: set[str] | None = None):
    file_path = Path(file_path)
    arcname = str(arcname).replace("\\", "/").lstrip("/")
    while "../" in arcname:
        arcname = arcname.replace("../", "")
    if not arcname or (added is not None and arcname in added):
        return
    if file_path.is_file():
        zip_handle.write(file_path, arcname)
        if added is not None:
            added.add(arcname)


def _sqlite_snapshot(source_path: Path, destination: Path) -> None:
    """Crea uno snapshot SQLite consistente senza copiare il DB a caldo."""
    source = sqlite3.connect(source_path, timeout=15)
    target = sqlite3.connect(destination, timeout=15)
    try:
        source.backup(target)
        target.commit()
    finally:
        try:
            target.close()
        finally:
            source.close()


def _validate_sqlite(path: Path) -> None:
    if not path.exists() or path.stat().st_size < 100:
        raise ValueError("Database del backup assente o vuoto.")
    conn = sqlite3.connect(path, timeout=10)
    try:
        result = conn.execute("PRAGMA integrity_check").fetchone()
        if not result or str(result[0]).lower() != "ok":
            raise ValueError("Database del backup non integro.")
        count = conn.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
        if int(count or 0) == 0:
            raise ValueError("Database del backup privo di tabelle.")
    finally:
        conn.close()


def _create_backup_zip(prefix: str = "backup_completo") -> Path:
    import tempfile
    import zipfile

    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = now().strftime("%Y%m%d_%H%M%S_%f")
    zip_path = BACKUP_DIR / f"{prefix}_{stamp}.zip"
    current_slug = current_tenant_slug()
    current_db_path = get_workspace_db_path(current_slug).resolve()

    with tempfile.TemporaryDirectory(prefix="asd_backup_") as td:
        temp_root = Path(td)
        snapshots: dict[Path, Path] = {}

        # Snapshot di ogni database tenant, non solo di quello aperto nella sessione.
        if TENANTS_DIR.exists():
            for db_path in TENANTS_DIR.glob("*/asd.db"):
                if db_path.is_file():
                    snapshot = temp_root / f"{len(snapshots):04d}.sqlite"
                    _sqlite_snapshot(db_path, snapshot)
                    _validate_sqlite(snapshot)
                    snapshots[db_path.resolve()] = snapshot

        # Compatibilità con vecchie installazioni che usavano il DB nella root.
        if DB_NAME.exists() and DB_NAME.is_file() and DB_NAME.resolve() not in snapshots:
            snapshot = temp_root / "legacy.sqlite"
            _sqlite_snapshot(DB_NAME, snapshot)
            _validate_sqlite(snapshot)
            snapshots[DB_NAME.resolve()] = snapshot

        # Il workspace corrente deve avere almeno un DB valido.
        if current_db_path not in snapshots:
            raise ValueError("Database del tenant corrente non disponibile per il backup.")

        import json
        manifest = {
            "format": BACKUP_FORMAT_VERSION,
            "created_at": now_iso_dt(),
            "current_tenant": current_slug,
            "tenants": [p.parent.name for p in snapshots if p.parent.parent.resolve() == TENANTS_DIR.resolve()],
        }

        added: set[str] = set()
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            zf.writestr("backup_manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
            added.add("backup_manifest.json")

            # Tutti i file runtime, tranne backup già esistenti e i lock SQLite.
            if DATA_DIR.exists():
                for item in DATA_DIR.rglob("*"):
                    if not item.is_file():
                        continue
                    resolved = item.resolve()
                    try:
                        resolved.relative_to(BACKUP_DIR.resolve())
                        continue
                    except ValueError:
                        pass
                    if item.name.endswith(("-journal", "-wal", "-shm")):
                        continue
                    rel = item.relative_to(DATA_DIR)
                    snapshot = snapshots.get(resolved)
                    _safe_zip_add_file(zf, snapshot or item, rel, added)

            # Alias stabile per restore/compatibilità.
            _safe_zip_add_file(zf, snapshots[current_db_path], "database/asd.db", added)

    return zip_path


@app.route("/backup/create", methods=["POST"])
@login_required
def backup_create():
    try:
        zip_path = _create_backup_zip("backup_completo")
        cleanup_old_files(BACKUP_DIR, "backup_completo_*.zip", keep=20)
        cleanup_old_files(BACKUP_DIR, "pre_restore_*.zip", keep=10)
        return send_file(zip_path, as_attachment=True, download_name=zip_path.name)
    except Exception as exc:
        try:
            log_exception(f"backup_create: {exc}")
        except Exception:
            pass
        return layout(alert_html("Errore durante il backup completo.", "error") + details_block("Dettagli", e(str(exc))))


def _normalize_backup_member(name: str) -> str | None:
    """Normalizza backup vecchi/nuovi senza bloccare file innocui.

    L'unico caso rifiutato è il path traversal o un percorso assoluto. Tutto ciò
    che non appartiene ai dati del gestionale viene semplicemente ignorato.
    """
    raw = str(name or "").replace("\\", "/")
    if raw.startswith("/") or raw.startswith("~"):
        raise ValueError("Archivio backup non sicuro.")
    parts = [p for p in raw.split("/") if p not in ("", ".")]
    if not parts or any(p == ".." for p in parts):
        raise ValueError("Archivio backup non sicuro.")
    allowed = {"backup_manifest.json", "config.json", "database", "config", "tenants", "tenant", "media", "pdf", "user_static", "documenti", "documents", "logs"}
    idx = next((i for i, part in enumerate(parts) if part in allowed), None)
    if idx is None:
        return None
    normalized = "/".join(parts[idx:])
    if normalized == "backup_manifest.json":
        return normalized
    root = normalized.split("/", 1)[0]
    if root == "tenant":
        normalized = "tenants/" + "/".join(normalized.split("/")[1:])
        root = "tenants"
    if root in {"documenti", "documents"}:
        normalized = "media/documenti_asd/" + "/".join(normalized.split("/", 1)[1:]) if "/" in normalized else "media/documenti_asd"
        root = "media"
    if root not in {"database", "config", "tenants", "media", "pdf", "user_static", "logs"}:
        return None
    return normalized

def _is_safe_zip_member(name: str) -> bool:
    try:
        return _normalize_backup_member(name) is not None
    except ValueError:
        return False


def _extract_and_validate_backup(zip_path: Path, extract_root: Path) -> None:
    import json
    import zipfile

    max_total = 2 * 1024 * 1024 * 1024
    total_uncompressed = 0
    written: set[str] = set()

    with zipfile.ZipFile(zip_path) as zf:
        bad = zf.testzip()
        if bad:
            raise ValueError(f"Archivio ZIP danneggiato: {bad}")
        infos = zf.infolist()
        if not infos:
            raise ValueError("Backup vuoto.")

        for info in infos:
            if info.is_dir():
                continue
            normalized = _normalize_backup_member(info.filename)
            if normalized is None:
                # Metadati innocui (es. __MACOSX/.DS_Store) o file di altre
                # versioni: non devono impedire il ripristino dei dati utili.
                continue
            if info.file_size > 2 * 1024 * 1024 * 1024:
                raise ValueError("Un file del backup supera il limite di sicurezza di 2 GB.")
            total_uncompressed += int(info.file_size or 0)
            if total_uncompressed > max_total:
                raise ValueError("Il contenuto estratto del backup supera il limite di sicurezza di 2 GB.")
            if normalized in written:
                continue

            destination = extract_root / normalized
            destination.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info, "r") as src, destination.open("wb") as dst:
                shutil.copyfileobj(src, dst, length=1024 * 1024)
            written.add(normalized)

    manifest_path = extract_root / "backup_manifest.json"
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            if int(manifest.get("format", 1)) > BACKUP_FORMAT_VERSION:
                raise ValueError("Questo backup è stato creato da una versione più recente del programma.")
        except ValueError:
            raise
        except Exception as exc:
            raise ValueError(f"Manifest del backup non leggibile: {exc}")

    db_files = list((extract_root / "tenants").glob("*/asd.db")) if (extract_root / "tenants").exists() else []
    legacy_db = extract_root / "database" / "asd.db"
    # Compatibilità con backup molto vecchi che contengono semplicemente asd.db
    # alla radice o dentro una cartella contenitore.
    root_db = extract_root / "asd.db"
    if not db_files and not legacy_db.exists() and root_db.exists():
        legacy_db.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root_db, legacy_db)
        root_db.unlink(missing_ok=True)
        legacy_db = extract_root / "database" / "asd.db"

    if not db_files and not legacy_db.exists():
        raise ValueError("Il file selezionato non contiene un database ASD ripristinabile.")
    for db_path in db_files + ([legacy_db] if legacy_db.exists() else []):
        _validate_sqlite(db_path)

def _restore_extracted_backup(extracted: Path) -> None:
    """Sostituisce i dati applicativi con il contenuto già validato."""
    # Prima copia le directory in una staging area della stessa DATA_DIR, poi
    # sostituisce le directory. In questo modo un errore di estrazione non tocca i dati.
    import tempfile
    import json

    restore_folders = ("tenants", "media", "pdf", "user_static")
    with tempfile.TemporaryDirectory(prefix="asd_restore_stage_", dir=str(DATA_DIR.parent)) as td:
        stage = Path(td)
        staged = []
        for folder in restore_folders:
            src = extracted / folder
            if src.exists() and src.is_dir():
                dst = stage / folder
                shutil.copytree(src, dst)
                staged.append(folder)

        config_src = extracted / "config" / "config.json"
        if config_src.exists() and config_src.is_file():
            shutil.copy2(config_src, stage / "config.json")

        # Vecchio formato: database/asd.db senza tenants/. Lo convertiamo nel tenant default.
        legacy_db = extracted / "database" / "asd.db"
        tenants_stage = stage / "tenants"
        if not (tenants_stage / f"{DEFAULT_TENANT_SLUG}/asd.db").exists() and legacy_db.exists():
            tenant_stage = tenants_stage / DEFAULT_TENANT_SLUG
            tenant_stage.mkdir(parents=True, exist_ok=True)
            shutil.copy2(legacy_db, tenant_stage / "asd.db")
            if config_src.exists() and config_src.is_file():
                shutil.copy2(config_src, tenant_stage / "config.json")
            elif not (tenant_stage / "config.json").exists():
                tenant_stage.joinpath("config.json").write_text(
                    json.dumps({"nome_asd": "Nuova ASD", "setup_completed": "0"}, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )

        # Il restore non sovrascrive licenza e segreto locale: sono credenziali
        # dell'installazione/dispositivo, non dati dell'ASD.
        for folder in restore_folders:
            staged_dir = stage / folder
            if staged_dir.exists():
                target = DATA_DIR / folder
                old = DATA_DIR / f".{folder}.restore_old"
                if old.exists():
                    shutil.rmtree(old, ignore_errors=True)
                if target.exists():
                    target.rename(old)
                try:
                    staged_dir.rename(target)
                except Exception:
                    if old.exists() and not target.exists():
                        old.rename(target)
                    raise
                shutil.rmtree(old, ignore_errors=True)

        staged_config = stage / "config.json"
        if staged_config.exists():
            target = CONFIG_FILE
            backup_old = DATA_DIR / ".config.restore_old"
            if backup_old.exists():
                backup_old.unlink(missing_ok=True)
            if target.exists():
                target.rename(backup_old)
            try:
                staged_config.rename(target)
            except Exception:
                if backup_old.exists() and not target.exists():
                    backup_old.rename(target)
                raise
            backup_old.unlink(missing_ok=True)

        # Mantiene compatibilità con eventuali moduli che leggono il vecchio DB root.
        restored_default = get_workspace_db_path(DEFAULT_TENANT_SLUG)
        if restored_default.exists():
            shutil.copy2(restored_default, DB_NAME)



def _restore_backup_zip(zip_path: Path) -> None:
    import tempfile

    with tempfile.TemporaryDirectory(prefix="asd_restore_") as td:
        extracted = Path(td) / "extract"
        extracted.mkdir(parents=True, exist_ok=True)
        _extract_and_validate_backup(zip_path, extracted)
        # Backup di sicurezza PRIMA di qualsiasi modifica.
        _create_backup_zip("pre_restore")
        _restore_extracted_backup(extracted)
    # Ricostruisce/migra ogni tenant e il registro.
    registry = load_tenants_registry()
    slugs = {str(item.get("slug") or "").strip() for item in registry}
    if TENANTS_DIR.exists():
        slugs.update(p.name for p in TENANTS_DIR.iterdir() if p.is_dir() and p.name != "__pycache__")
    slugs.discard("")
    for slug in sorted(slugs):
        ensure_workspace_ready(slug)
    ensure_workspace_ready(DEFAULT_TENANT_SLUG)


@app.route("/backup/download/<path:filename>")
@login_required
@admin_required
def backup_download(filename: str):
    safe_name = Path(filename).name
    path = BACKUP_DIR / safe_name
    if safe_name != filename or not safe_name.startswith("backup_") or path.suffix.lower() != ".zip" or not path.is_file():
        return "Backup non trovato", 404
    return send_file(path, as_attachment=True, download_name=path.name)


def _restore_saved_backup(filename: str):
    safe_name = Path(filename).name
    path = BACKUP_DIR / safe_name
    if safe_name != filename or not safe_name.startswith("backup_") or path.suffix.lower() != ".zip" or not path.is_file():
        return redirect_with_message("/backup", "Backup salvato non trovato.", "error")
    try:
        _restore_backup_zip(path)
        log_audit("backup_restore", details=f"Backup salvato ripristinato: {safe_name}", entity_type="backup")
        return redirect_with_message("/backup", "Backup ripristinato correttamente.", "success")
    except Exception as exc:
        try:
            log_exception(f"backup_restore_saved: {exc}")
        except Exception:
            pass
        return redirect_with_message("/backup", f"Errore restore: {exc}", "error")


@app.route("/backup/restore-saved/<path:filename>", methods=["POST"])
@login_required
@admin_required
def backup_restore_saved(filename: str):
    return _restore_saved_backup(filename)


@app.route("/backup/restore", methods=["POST"])
@login_required
@admin_required
def backup_restore():
    uploaded = request.files.get("backup_file")
    if not uploaded or not uploaded.filename:
        return redirect_with_message("/backup", "Seleziona un file backup ZIP.", "error")
    if not str(uploaded.filename).lower().endswith(".zip"):
        return redirect_with_message("/backup", "Il file deve essere un archivio ZIP.", "error")
    try:
        import tempfile
        with tempfile.TemporaryDirectory(prefix="asd_uploaded_backup_") as td:
            zip_path = Path(td) / "restore.zip"
            uploaded.save(zip_path)
            _restore_backup_zip(zip_path)
        log_audit("backup_restore", details="Backup ZIP importato e ripristinato", entity_type="backup")
        return redirect_with_message("/backup", "Backup ripristinato correttamente.", "success")
    except Exception as exc:
        try:
            log_exception(f"backup_restore: {exc}")
        except Exception:
            pass
        return redirect_with_message("/backup", f"Errore restore: {exc}", "error")
