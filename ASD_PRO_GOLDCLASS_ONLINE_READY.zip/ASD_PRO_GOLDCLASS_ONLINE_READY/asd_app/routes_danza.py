from .core import *

# DANZA AEREA
# ==============================
def _danza_order_sql(prefix: str = "") -> str:
   p = f"{prefix}." if prefix else ""
   return f"""CASE {p}livello
       WHEN 'Livello 1' THEN 1
       WHEN 'Livello 2' THEN 2
       WHEN 'Livello 3' THEN 3
       WHEN 'Livello 4' THEN 4
       WHEN 'Livello 5' THEN 5
       WHEN 'Advanced' THEN 6
       ELSE 99
   END, {p}ordine, {p}nome"""


@app.route("/danza")
@login_required
def danza():
   livello_filter = request.args.get("livello", "").strip()
   tipo_filter = request.args.get("tipo", "").strip()
   search = request.args.get("q", "").strip()

   conn = db()
   c = conn.cursor()

   sql = "SELECT * FROM danza_elementi WHERE attivo=1"
   params = []

   if livello_filter:
       sql += " AND livello=?"
       params.append(livello_filter)
   if tipo_filter:
       sql += " AND tipo=?"
       params.append(tipo_filter)
   if search:
       pattern = f"%{search}%"
       sql += " AND (nome LIKE ? OR descrizione LIKE ? OR focus LIKE ? OR prerequisiti LIKE ? OR consigli LIKE ? OR sequenza LIKE ?)"
       params.extend([pattern, pattern, pattern, pattern, pattern, pattern])

   sql += " ORDER BY " + _danza_order_sql()
   rows = c.execute(sql, params).fetchall()
   conn.close()

   grouped = {}
   for row in rows:
       grouped.setdefault(row["livello"], []).append(row)

   livello_options = "".join(
       f"<option value='{e(level)}' {'selected' if livello_filter == level else ''}>{e(level)}</option>"
       for level in DANZA_LEVELS
   )
   tipo_options = "".join(
       f"<option value='{e(tipo)}' {'selected' if tipo_filter == tipo else ''}>{e(tipo.title())}</option>"
       for tipo in DANZA_TYPES
   )

   style_block = """
   <style>
   .danza-hero {
       position:relative;
       overflow:hidden;
       border-radius:24px;
       padding:28px;
       background:
           radial-gradient(circle at top right, rgba(56,189,248,.18), transparent 28%),
           linear-gradient(145deg, rgba(8,15,30,.94), rgba(12,20,36,.84));
       border:1px solid rgba(56,189,248,.14);
       margin-bottom:18px;
   }
   .danza-hero h2 { margin:6px 0 10px 0; font-size:1.95rem; }
   .danza-hero p {
       max-width:820px; line-height:1.6; color:rgba(229,238,252,.82);
   }
   .danza-toolbar {
       display:flex; flex-wrap:wrap; gap:10px; align-items:end; margin-top:18px;
   }
   .danza-toolbar form {
       display:flex; flex-wrap:wrap; gap:10px; align-items:end; width:100%;
   }
   .danza-grid {
       display:grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap:18px;
   }
   .danza-card {
       background: linear-gradient(180deg, rgba(17,24,39,.96), rgba(9,15,28,.98));
       border:1px solid rgba(96,165,250,.14);
       border-radius:22px;
       overflow:hidden;
       box-shadow:0 18px 42px rgba(0,0,0,.28);
       transition:.18s ease;
   }
   .danza-card:hover {
       transform:translateY(-2px);
       border-color:rgba(96,165,250,.28);
   }
   .danza-card img {
       width:100%; height:240px; object-fit:cover; display:block; background:#0f172a;
   }
   .danza-card-body { padding:18px; }
   .danza-badges {
       display:flex; flex-wrap:wrap; gap:8px; margin-bottom:14px;
   }
   .danza-badge-level { background:#1d4ed8; color:white; }
   .danza-badge-type { background:#0f766e; color:white; text-transform:capitalize; }
   .danza-section-title {
       margin:26px 0 14px; padding-bottom:8px;
       border-bottom:1px solid rgba(255,255,255,.10); font-size:1.18rem;
   }
   .danza-meta { display:grid; gap:10px; }
   .danza-meta-item {
       padding:10px 12px; border-radius:12px; background:rgba(255,255,255,.035);
       border:1px solid rgba(255,255,255,.06); line-height:1.5;
   }
   .danza-empty {
       padding:30px; text-align:center; border:1px dashed rgba(255,255,255,.18);
       border-radius:18px; background:rgba(15,23,42,.55);
   }
   .danza-actions-bar { display:flex; gap:10px; flex-wrap:wrap; margin-top:14px; }
   .danza-actions-bar a {
       display:inline-flex; align-items:center; gap:8px; padding:10px 12px; border-radius:12px;
       background:rgba(56,189,248,.12); border:1px solid rgba(56,189,248,.16);
       color:#bfe9ff; text-decoration:none; font-weight:800;
   }
   .danza-summary-grid {
       display:grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap:12px; margin-top:14px;
   }
   .danza-summary-box {
       padding:14px; border-radius:16px; background:rgba(255,255,255,.04);
       border:1px solid rgba(255,255,255,.07);
   }
   .danza-summary-box .big { font-size:1.3rem; font-weight:800; margin-top:6px; }
   .danza-note-list { display:grid; gap:8px; margin-top:12px; }
   .danza-note-list .note {
       padding:10px 12px; border-radius:12px; background:rgba(255,255,255,.03);
       border:1px solid rgba(255,255,255,.06);
   }
   </style>
   """

   total_items = len(rows)
   combo_count = sum(1 for r in rows if r["tipo"] == "combo")
   trick_count = sum(1 for r in rows if r["tipo"] == "trick")

   html_out = f"""
   {style_block}
   <div class="danza-hero">
       <div class="kicker">Archivio tecnico</div>
       <h2>Danza Aerea – Catalogo Pro</h2>
       <p>
           Raccolta ordinata di trick e combo, con focus tecnici, prerequisiti, consigli pratici,
           errori comuni, note di sicurezza e accesso rapido ai video. La pagina è pensata per essere
           veloce da consultare anche da telefono e utile durante le lezioni.
       </p>

       <div class="danza-summary-grid">
           <div class="danza-summary-box"><div class="small-muted">Elementi visibili</div><div class="big">{total_items}</div></div>
           <div class="danza-summary-box"><div class="small-muted">Trick</div><div class="big">{trick_count}</div></div>
           <div class="danza-summary-box"><div class="small-muted">Combo</div><div class="big">{combo_count}</div></div>
           <div class="danza-summary-box"><div class="small-muted">Livelli attivi</div><div class="big">{len(grouped)}</div></div>
       </div>

       <div class="danza-toolbar">
           <form method="GET">
               <div class="form-col">
                   <label>Ricerca</label>
                   <input name="q" value="{e(search)}" placeholder="Nome, focus, consigli...">
               </div>
               <div class="form-col">
                   <label>Livello</label>
                   <select name="livello">
                       <option value="">Tutti i livelli</option>
                       {livello_options}
                   </select>
               </div>
               <div class="form-col">
                   <label>Tipo</label>
                   <select name="tipo">
                       <option value="">Tutti i tipi</option>
                       {tipo_options}
                   </select>
               </div>
               <div class="form-col">
                   <button type="submit">Filtra</button>
                   <a href="/danza" style="margin-top:10px;">Reset</a>
               </div>
           </form>
       </div>

       <div class="danza-note-list">
           <div class="note"><b>Uso consigliato:</b> apri il video solo dopo aver letto focus, prerequisiti e sicurezza.</div>
           <div class="note"><b>Progressione:</b> i livelli sono ordinati per consultazione, non sostituiscono la valutazione tecnica dell'istruttore.</div>
       </div>
   </div>
   """

   ordered_levels = [lvl for lvl in DANZA_LEVELS if lvl in grouped]
   extra_levels = [lvl for lvl in grouped.keys() if lvl not in DANZA_LEVELS]
   final_levels = ordered_levels + sorted(extra_levels)

   if not rows:
       html_out += """
       <div class="danza-empty">
           <h3 style="margin-top:0;">Nessun elemento disponibile</h3>
           <p class="small-muted">Non ci sono elementi attivi corrispondenti ai filtri selezionati.</p>
       </div>
       """
   else:
       for livello in final_levels:
           html_out += f"<h3 class='danza-section-title'>{e(livello)}</h3><div class='danza-grid'>"
           for item in grouped[livello]:
               placeholder = danza_placeholder_data_uri(item["nome"] or "Danza Aerea")
               image_src = file_url(item["immagine"]) if item["immagine"] else placeholder

               video_html = ""

               sequenza_html = ""
               if item["tipo"] == "combo" and item["sequenza"]:
                   sequenza_html = f"<div class='danza-meta-item'><b>Sequenza</b><br>{e(item['sequenza'])}</div>"

               errori_html = ""
               if item["errori_comuni"]:
                   errori_html = f"<div class='danza-meta-item'><b>Errori comuni</b><br>{e(item['errori_comuni'])}</div>"

               html_out += f"""
               <div class="danza-card">
                   <img src="{image_src}" alt="{e(item['nome'])}" onerror="this.onerror=null;this.src='{placeholder}';">
                   <div class="danza-card-body">
                       <div class="danza-badges">
                           <span class="badge danza-badge-level">{e(item['livello'])}</span>
                           <span class="badge danza-badge-type">{e(item['tipo'])}</span>
                       </div>
                       <h3 style="margin:0 0 12px 0;">{e(item['nome'])}</h3>
                       <div class="danza-meta">
                           <div class='danza-meta-item'><b>Descrizione</b><br>{e(item['descrizione'])}</div>
                           {sequenza_html}
                           <div class='danza-meta-item'><b>Focus</b><br>{e(item['focus'])}</div>
                           <div class='danza-meta-item'><b>Prerequisiti</b><br>{e(item['prerequisiti'])}</div>
                           <div class='danza-meta-item'><b>Consigli</b><br>{e(item['consigli'])}</div>
                           {errori_html}
                           <div class='danza-meta-item'><b>Sicurezza</b><br>{e(item['nota_sicurezza'])}</div>
                       </div>
                       {video_html}
                   </div>
               </div>
               """
           html_out += "</div>"

   return layout(html_out)


@app.route("/danza/admin", methods=["GET", "POST"])
@login_required
def danza_admin():
   conn = db()
   c = conn.cursor()

   if request.method == "POST":
       action = request.form.get("action", "create").strip()
       rec_id = parse_int(request.form.get("id"), 0)

       tipo = request.form.get("tipo", "trick").strip().lower()
       livello = request.form.get("livello", "Livello 1").strip()
       nome = request.form.get("nome", "").strip()
       descrizione = request.form.get("descrizione", "").strip()
       sequenza = request.form.get("sequenza", "").strip()
       video_url = ""
       focus = request.form.get("focus", "").strip()
       prerequisiti = request.form.get("prerequisiti", "").strip()
       consigli = request.form.get("consigli", "").strip()
       errori_comuni = request.form.get("errori_comuni", "").strip()
       nota_sicurezza = request.form.get("nota_sicurezza", "").strip()
       ordine = parse_int(request.form.get("ordine", 0), 0)
       attivo = 1 if request.form.get("attivo") == "on" else 0

       if tipo not in DANZA_TYPES:
           conn.close()
           return layout(alert_html("Tipo non valido. Usa trick oppure combo.", "error"))
       if livello not in DANZA_LEVELS:
           conn.close()
           return layout(alert_html("Livello non valido.", "error"))
       if not nome.strip():
           conn.close()
           return layout(alert_html("Il nome è obbligatorio.", "error"))
       nome = truncate(nome, 140)
       descrizione = truncate(descrizione, 1000)
       sequenza = truncate(sequenza, 1000)
       focus = truncate(focus, 1000)
       prerequisiti = truncate(prerequisiti, 1000)
       consigli = truncate(consigli, 1000)
       errori_comuni = truncate(errori_comuni, 1000)
       nota_sicurezza = truncate(nota_sicurezza, 1000)

       if tipo != "combo":
           sequenza = ""

       immagine_path = ""
       if action == "update":
           old_row = c.execute("SELECT * FROM danza_elementi WHERE id=?", (rec_id,)).fetchone()
           if not old_row:
               conn.close()
               return layout(alert_html("Elemento non trovato.", "error"))
           immagine_path = old_row["immagine"] or ""

       image_file = request.files.get("immagine")
       if image_file and image_file.filename:
           try:
               new_image_path = save_uploaded_image(image_file, "danza")
               if immagine_path and immagine_path != new_image_path:
                   delete_uploaded_image(immagine_path)
               immagine_path = new_image_path
           except ValueError as exc:
               conn.close()
               return layout(alert_html(str(exc), "error"))

       now_str = now_iso_dt()
       if action == "update":
           c.execute(
               """
               UPDATE danza_elementi
               SET tipo=?, livello=?, nome=?, descrizione=?, sequenza=?, immagine=?, video_url=?,
                   focus=?, prerequisiti=?, consigli=?, errori_comuni=?, nota_sicurezza=?,
                   ordine=?, attivo=?, updated_at=?
               WHERE id=?
               """,
               (
                   tipo,
                   livello,
                   nome,
                   descrizione,
                   sequenza,
                   immagine_path,
                   video_url,
                   focus,
                   prerequisiti,
                   consigli,
                   errori_comuni,
                   nota_sicurezza,
                   ordine,
                   attivo,
                   now_str,
                   rec_id,
               ),
           )
       else:
           c.execute(
               """
               INSERT INTO danza_elementi(
                   tipo, livello, nome, descrizione, sequenza, immagine, video_url,
                   focus, prerequisiti, consigli, errori_comuni, nota_sicurezza,
                   ordine, attivo, created_at, updated_at
               ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               """,
               (
                   tipo,
                   livello,
                   nome,
                   descrizione,
                   sequenza,
                   immagine_path,
                   video_url,
                   focus,
                   prerequisiti,
                   consigli,
                   errori_comuni,
                   nota_sicurezza,
                   ordine,
                   attivo,
                   now_str,
                   now_str,
               ),
           )

       conn.commit()
       conn.close()
       return redirect("/danza/admin")

   edit_row = None
   if request.args.get("edit"):
       edit_id = parse_int(request.args.get("edit"), 0)
       edit_row = c.execute("SELECT * FROM danza_elementi WHERE id=?", (edit_id,)).fetchone()

   rows = c.execute("SELECT * FROM danza_elementi ORDER BY " + _danza_order_sql()).fetchall()
   conn.close()

   form_action = "update" if edit_row else "create"
   current_tipo = edit_row["tipo"] if edit_row else "trick"
   current_livello = edit_row["livello"] if edit_row else "Livello 1"
   checked_attivo = "checked" if (not edit_row or int(edit_row["attivo"] or 0) == 1) else ""

   tipo_options = "".join(
       f"<option value='{e(tipo)}' {'selected' if current_tipo == tipo else ''}>{e(tipo.title())}</option>"
       for tipo in DANZA_TYPES
   )
   livello_options = "".join(
       f"<option value='{e(level)}' {'selected' if current_livello == level else ''}>{e(level)}</option>"
       for level in DANZA_LEVELS
   )
   preview_src = (
       file_url(edit_row["immagine"])
       if (edit_row and edit_row["immagine"])
       else danza_placeholder_data_uri("Anteprima immagine")
   )

   style_block = """
   <style>
   .danza-admin-grid {
       display:grid;
       grid-template-columns: minmax(340px, 1.15fr) minmax(320px, .85fr);
       gap:18px;
   }
   .danza-admin-form-wrap .field-row {
       display:flex;
       flex-wrap:wrap;
       gap:10px;
       margin-bottom:12px;
   }
   .danza-admin-form-wrap .field-row > div { flex:1 1 220px; }
   .danza-preview {
       width:100%; max-width:460px; height:250px; object-fit:cover;
       border-radius:16px; border:1px solid rgba(255,255,255,.10);
       background:#0f172a; display:block; margin-top:10px;
   }
   .danza-admin-table img {
       width:72px; height:72px; object-fit:cover; border-radius:10px; background:#0f172a;
   }
   @media (max-width: 1040px) {
       .danza-admin-grid { grid-template-columns: 1fr; }
   }
   </style>
   """

   html_out = f"""
   {style_block}
   <div class="card">
       <div class="page-head">
           <div>
               <div class="kicker">Backoffice tecnico</div>
               <h2 class="section-title">Admin Danza Aerea</h2>
           </div>
       </div>

       <div class="danza-admin-grid">
           <div class="card soft danza-admin-form-wrap" style="margin-bottom:0;">
               <h3>{'Modifica elemento' if edit_row else 'Nuovo elemento'}</h3>
               <form method="POST" enctype="multipart/form-data">
                   {csrf_input()}
                   <input type="hidden" name="action" value="{form_action}">
                   <input type="hidden" name="id" value="{edit_row['id'] if edit_row else ''}">

                   <div class="field-row">
                       <div>
                           <label>Tipo</label><br>
                           <select name="tipo" id="danza_tipo" onchange="toggleSequenzaField()">
                               {tipo_options}
                           </select>
                       </div>
                       <div>
                           <label>Livello</label><br>
                           <select name="livello">{livello_options}</select>
                       </div>
                       <div>
                           <label>Ordine</label><br>
                           {number_input("ordine", int(edit_row['ordine']) if edit_row else 0, "Ordine", "1", 0, "100%")}
                       </div>
                   </div>

                   <div class="field-row">
                       <div>
                           <label>Nome</label><br>
                           <input name="nome" required value="{e(edit_row['nome'] if edit_row else '')}" style="width:95%;">
                       </div>
                   </div>

                   <div class="field-row">
                       <div><label>Descrizione</label><br><textarea name="descrizione">{e(edit_row['descrizione'] if edit_row else '')}</textarea></div>
                   </div>

                   <div class="field-row" id="sequenza_wrap" style="display:{'flex' if current_tipo == 'combo' else 'none'};">
                       <div><label>Sequenza (solo combo)</label><br><textarea name="sequenza">{e(edit_row['sequenza'] if edit_row else '')}</textarea></div>
                   </div>

                   <div class="field-row">
                       <div><label>Focus</label><br><textarea name="focus">{e(edit_row['focus'] if edit_row else '')}</textarea></div>
                       <div><label>Prerequisiti</label><br><textarea name="prerequisiti">{e(edit_row['prerequisiti'] if edit_row else '')}</textarea></div>
                   </div>

                   <div class="field-row">
                       <div><label>Consigli</label><br><textarea name="consigli">{e(edit_row['consigli'] if edit_row else '')}</textarea></div>
                       <div><label>Errori comuni</label><br><textarea name="errori_comuni">{e(edit_row['errori_comuni'] if edit_row else '')}</textarea></div>
                   </div>

                   <div class="field-row">
                       <div><label>Nota sicurezza</label><br><textarea name="nota_sicurezza">{e(edit_row['nota_sicurezza'] if edit_row else '')}</textarea></div>
                   </div>

                   <div class="field-row">
                       <div>
                           <label>Immagine</label><br>
                           <input type="file" name="immagine" id="immagine_input" accept=".png,.jpg,.jpeg,.webp,.gif">
                           <img id="preview_immagine" class="danza-preview" src="{preview_src}" alt="Anteprima"
                                onerror="this.onerror=null;this.src='{danza_placeholder_data_uri('Anteprima immagine')}';">
                       </div>
                   </div>

                   <div class="field-row">
                       <div><label><input type="checkbox" name="attivo" {checked_attivo}> Attivo</label></div>
                   </div>

                   <button>{'Aggiorna elemento' if edit_row else 'Salva elemento'}</button>
                   {"<a href='/danza/admin' style='margin-left:8px;'>Annulla modifica</a>" if edit_row else ""}
               </form>
           </div>

           <div class="card soft" style="margin-bottom:0;">
               <h3>Linee guida compilazione</h3>
               <p><b>Focus:</b> forza, inversione, spin, flessibilità, grip, transizione.</p>
               <p><b>Prerequisiti:</b> indica elementi già acquisiti o capacità richieste.</p>
               <p><b>Consigli:</b> pratici, brevi e realmente utili in lezione.</p>
               <p><b>Errori comuni:</b> utile per correzione tecnica e prevenzione errori.</p>
               <p><b>Nota sicurezza:</b> concreta e specifica, non generica.</p>
               <p><b>Ordine:</b> numero basso = visualizzazione prima.</p>
                              <p><a href="/danza">Apri pagina catalogo danza</a></p>
           </div>
       </div>
   </div>

   <div class="card">
       <h3>Elenco elementi</h3>
       <table class="danza-admin-table">
           <tr>
               <th>Img</th><th>Ordine</th><th>Nome</th><th>Livello</th><th>Tipo</th><th>Stato</th><th>Azioni</th>
           </tr>
   """

   for row in rows:
       thumb = file_url(row["immagine"]) if row["immagine"] else danza_placeholder_data_uri(row["nome"] or "Danza")
       stato_badge = (
           "<span class='badge valido'>Attivo</span>"
           if int(row["attivo"] or 0) == 1
           else "<span class='badge scaduto'>Disattivo</span>"
       )
       html_out += f"""
       <tr>
           <td><img src="{thumb}" alt="{e(row['nome'])}" onerror="this.onerror=null;this.src='{danza_placeholder_data_uri(row['nome'] or 'Danza')}';"></td>
           <td>{int(row['ordine'] or 0)}</td>
           <td><b>{e(row['nome'])}</b></td>
           <td>{e(row['livello'])}</td>
           <td><span class="badge">{e(row['tipo'])}</span></td>
           <td>{stato_badge}</td>
           <td>
               <div class="actions">
                   <a href="/danza/admin?edit={row['id']}">Modifica</a>
                   <form method="POST" action="/danza/admin/toggle" class="inline-form">
                       {csrf_input()}
                       <input type="hidden" name="id" value="{row['id']}">
                       <button>{'Disattiva' if int(row['attivo'] or 0) == 1 else 'Attiva'}</button>
                   </form>
                   <form method="POST" action="/danza/admin/delete" class="inline-form" onsubmit="return confirm('Eliminare questo elemento?');">
                       {csrf_input()}
                       <input type="hidden" name="id" value="{row['id']}">
                       <button class="danger">Elimina</button>
                   </form>
               </div>
           </td>
       </tr>"""
   html_out += """
       </table>
   </div>

   <script>
   function toggleSequenzaField() {
       const tipo = document.getElementById("danza_tipo");
       const wrap = document.getElementById("sequenza_wrap");
       if (!tipo || !wrap) return;
       wrap.style.display = (tipo.value === "combo") ? "flex" : "none";
   }

   const inputImg = document.getElementById("immagine_input");
   const previewImg = document.getElementById("preview_immagine");
   if (inputImg && previewImg) {
       inputImg.addEventListener("change", function() {
           const file = this.files && this.files[0];
           if (!file) return;
           const reader = new FileReader();
           reader.onload = function(ev) { previewImg.src = ev.target.result; };
           reader.readAsDataURL(file);
       });
   }
   toggleSequenzaField();
   </script>
   """

   return layout(html_out)


@app.route("/danza/admin/delete", methods=["POST"])
@login_required
def danza_admin_delete():
   rec_id = parse_int(request.form.get("id"), 0)
   conn = db()
   c = conn.cursor()
   row = c.execute("SELECT immagine FROM danza_elementi WHERE id=?", (rec_id,)).fetchone()
   if row:
       delete_uploaded_image(row["immagine"] or "")
       c.execute("DELETE FROM danza_elementi WHERE id=?", (rec_id,))
       conn.commit()
   conn.close()
   return redirect("/danza/admin")


@app.route("/danza/admin/toggle", methods=["POST"])
@login_required
def danza_admin_toggle():
   rec_id = parse_int(request.form.get("id"), 0)
   conn = db()
