from .core import *

USER_ROLE_OPTIONS = ["viewer", "operator", "manager", "admin"]

@app.route("/utenti", methods=["GET", "POST"])
@admin_required
def utenti():
    conn = db()
    c = conn.cursor()

    if request.method == "POST":
        action = (request.form.get("action") or "").strip()

        if action == "create":
            try:
                username = require_non_empty(request.form.get("username", ""), "Username", 80)
                password = require_non_empty(request.form.get("password", ""), "Password", 120)
                full_name = truncate(request.form.get("full_name", "").strip(), 140)
                email = normalize_email(request.form.get("email", ""), 160)
                role = (request.form.get("role", "operator") or "operator").strip().lower()
                if role not in ROLE_LEVELS:
                    role = "operator"
                active = 1 if request.form.get("active") == "1" else 0
                must_change_password = 1 if request.form.get("must_change_password") == "1" else 0
                existing = c.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
                if existing:
                    raise ValueError("Username già esistente.")
                c.execute(
                    """
                    INSERT INTO users(username, password, role, active, full_name, email, must_change_password, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (username, generate_password_hash(password), role, active, full_name, email, must_change_password, now_iso_dt(), now_iso_dt()),
                )
                conn.commit()
                log_audit('user_create', details=f'Creato utente {username} ruolo={role}', entity_type='user', entity_id=str(c.lastrowid))
                conn.close()
                return redirect_with_message("/utenti", "Utente creato correttamente.", "success")
            except ValueError as exc:
                conn.close()
                return redirect_with_message("/utenti", str(exc), "error")

        user_id = parse_int(request.form.get("id", "0"), 0)
        user = c.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone() if user_id > 0 else None

        if action == "toggle_active":
            if not user:
                conn.close()
                return redirect_with_message("/utenti", "Utente non trovato.", "error")
            if str(user["username"] or "") == "admin" and int(user["active"] or 0) == 1:
                conn.close()
                return redirect_with_message("/utenti", "L'utente admin principale non può essere disattivato da qui.", "error")
            new_active = 0 if int(user["active"] or 0) == 1 else 1
            c.execute("UPDATE users SET active=?, updated_at=? WHERE id=?", (new_active, now_iso_dt(), user_id))
            conn.commit()
            log_audit('user_toggle_active', details=f'Utente {user["username"]} active={new_active}', entity_type='user', entity_id=str(user_id))
            conn.close()
            return redirect_with_message("/utenti", "Stato utente aggiornato.", "success")

        if action == "change_role":
            if not user:
                conn.close()
                return redirect_with_message("/utenti", "Utente non trovato.", "error")
            role = (request.form.get("role", "operator") or "operator").strip().lower()
            if role not in ROLE_LEVELS:
                role = "operator"
            if str(user["username"] or "") == "admin" and role != "admin":
                conn.close()
                return redirect_with_message("/utenti", "L'utente admin principale deve restare admin.", "error")
            c.execute("UPDATE users SET role=?, updated_at=? WHERE id=?", (role, now_iso_dt(), user_id))
            conn.commit()
            log_audit('user_change_role', details=f'Utente {user["username"]} ruolo={role}', entity_type='user', entity_id=str(user_id))
            conn.close()
            return redirect_with_message("/utenti", "Ruolo aggiornato.", "success")

        if action == "update_profile":
            if not user:
                conn.close()
                return redirect_with_message("/utenti", "Utente non trovato.", "error")
            full_name = truncate(request.form.get("full_name", "").strip(), 140)
            email = normalize_email(request.form.get("email", ""), 160)
            must_change_password = 1 if request.form.get("must_change_password") == "1" else 0
            c.execute(
                "UPDATE users SET full_name=?, email=?, must_change_password=?, updated_at=? WHERE id=?",
                (full_name, email, must_change_password, now_iso_dt(), user_id),
            )
            conn.commit()
            log_audit('user_update_profile', details=f'Utente {user["username"]}', entity_type='user', entity_id=str(user_id))
            conn.close()
            return redirect_with_message("/utenti", "Profilo utente aggiornato.", "success")

        if action == "reset_password":
            if not user:
                conn.close()
                return redirect_with_message("/utenti", "Utente non trovato.", "error")
            new_password = require_non_empty(request.form.get("new_password", ""), "Nuova password", 120)
            c.execute(
                "UPDATE users SET password=?, must_change_password=1, updated_at=? WHERE id=?",
                (generate_password_hash(new_password), now_iso_dt(), user_id),
            )
            conn.commit()
            conn.close()
            return redirect_with_message("/utenti", "Password reimpostata. Al prossimo accesso l'utente dovrà cambiarla.", "success")

        if action == "delete_user":
            if not user:
                conn.close()
                return redirect_with_message("/utenti", "Utente non trovato.", "error")

            username = str(user["username"] or "").strip()
            role = str(user["role"] or "operator").strip().lower()

            # Sicurezza: non permettere di eliminare l'utente con cui sei collegato.
            if username == current_username():
                conn.close()
                return redirect_with_message("/utenti", "Non puoi eliminare l'utente con cui sei attualmente collegato.", "error")

            # Sicurezza: l'admin tecnico principale resta sempre presente.
            if username == "admin":
                conn.close()
                return redirect_with_message("/utenti", "L'utente admin principale non può essere eliminato.", "error")

            # Sicurezza: non lasciare il gestionale senza amministratori.
            if role == "admin":
                admin_count = c.execute("SELECT COUNT(*) AS n FROM users WHERE role='admin' AND active=1").fetchone()["n"]
                if int(admin_count or 0) <= 1:
                    conn.close()
                    return redirect_with_message("/utenti", "Non puoi eliminare l'ultimo amministratore attivo.", "error")

            c.execute("DELETE FROM users WHERE id=?", (user_id,))
            conn.commit()
            log_audit('user_delete', details=f'Eliminato utente {username}', entity_type='user', entity_id=str(user_id))
            conn.close()
            return redirect_with_message("/utenti", "Utente eliminato correttamente.", "success")

        conn.close()
        return redirect_with_message("/utenti", "Azione non valida.", "error")

    rows = c.execute("SELECT id, username, full_name, email, role, active, must_change_password, created_at, last_login_at FROM users ORDER BY username").fetchall()
    conn.close()

    role_options = "".join(f"<option value='{e(role)}'>{e(role_label(role))}</option>" for role in USER_ROLE_OPTIONS)

    rows_html = ""
    for r in rows:
        active_label = "Attivo" if int(r["active"] or 0) == 1 else "Disattivato"
        toggle_label = "Disattiva" if int(r["active"] or 0) == 1 else "Attiva"
        role_select = "".join(
            f"<option value='{e(role)}'{' selected' if r['role'] == role else ''}>{e(role_label(role))}</option>"
            for role in USER_ROLE_OPTIONS
        )
        last_login = format_display_date(r["last_login_at"]) if r["last_login_at"] else "Mai"
        must_change = "Sì" if int(r["must_change_password"] or 0) == 1 else "No"
        rows_html += f"""
        <tr>
            <td><b>{e(r['username'])}</b><br><span class='small-muted'>{e(r['full_name'] or '-')}</span></td>
            <td>{e(r['email'] or '-')}</td>
            <td><span class='badge'>{e(role_label(r['role']))}</span><br><span class='small-muted'>{e(role_description(r['role']))}</span></td>
            <td>{e(active_label)}</td>
            <td>{e(must_change)}</td>
            <td>{e(last_login)}</td>
            <td>
                <div class='actions'>
                    <form method='POST' class='inline-form'>
                        {csrf_input()}
                        <input type='hidden' name='action' value='change_role'>
                        <input type='hidden' name='id' value='{r['id']}'>
                        <select name='role'>{role_select}</select>
                        <button>Aggiorna ruolo</button>
                    </form>
                    <form method='POST' class='inline-form'>
                        {csrf_input()}
                        <input type='hidden' name='action' value='toggle_active'>
                        <input type='hidden' name='id' value='{r['id']}'>
                        <button>{toggle_label}</button>
                    </form>
                </div>
                <form method='POST' class='form-row' style='margin-top:10px;'>
                    {csrf_input()}
                    <input type='hidden' name='action' value='update_profile'>
                    <input type='hidden' name='id' value='{r['id']}'>
                    <input name='full_name' value='{e(r['full_name'] or '')}' placeholder='Nome completo'>
                    <input name='email' value='{e(r['email'] or '')}' placeholder='Email'>
                    <label><input type='checkbox' name='must_change_password' value='1' {'checked' if int(r['must_change_password'] or 0) == 1 else ''}> Cambio password obbligatorio</label>
                    <button>Salva profilo</button>
                </form>
                <form method='POST' class='form-row' style='margin-top:8px;'>
                    {csrf_input()}
                    <input type='hidden' name='action' value='reset_password'>
                    <input type='hidden' name='id' value='{r['id']}'>
                    <input name='new_password' type='password' placeholder='Nuova password temporanea' required>
                    <button>Reimposta password</button>
                </form>
                <form method='POST' class='form-row' style='margin-top:8px;' onsubmit="return confirm('Confermi di voler eliminare definitivamente questo utente?');">
                    {csrf_input()}
                    <input type='hidden' name='action' value='delete_user'>
                    <input type='hidden' name='id' value='{r['id']}'>
                    <button type='submit' style='background:#b42318;border-color:#b42318;'>Elimina utente</button>
                </form>
            </td>
        </tr>
        """

    html_out = f"""
    <div class='card'>
        <div class='page-head'><div><div class='kicker'>Amministrazione multi-utente</div><h2 class='section-title'>Utenti e permessi</h2></div></div>
        <div class='grid-2'>
            <div class='card soft'>
                <h3 class='section-title'>Nuovo utente</h3>
                <form method='POST' class='form-row'>
                    {csrf_input()}
                    <input type='hidden' name='action' value='create'>
                    <input name='username' placeholder='Username' required>
                    <input name='full_name' placeholder='Nome completo'>
                    <input name='email' placeholder='Email'>
                    <input name='password' type='password' placeholder='Password iniziale' required>
                    <select name='role'>{role_options}</select>
                    <select name='active'><option value='1'>Attivo</option><option value='0'>Disattivato</option></select>
                    <label><input type='checkbox' name='must_change_password' value='1' checked> Cambio password obbligatorio al primo accesso</label>
                    <button>Crea utente</button>
                </form>
            </div>
            <div class='card soft'>
                <h3 class='section-title'>Gerarchia ruoli</h3>
                <ul>
                    <li><b>Viewer</b>: consultazione controllata.</li>
                    <li><b>Operatore</b>: tesserati, corsi, documenti, promemoria, danza.</li>
                    <li><b>Manager</b>: tutto l'operatore + incassi, ricevute, fatture, contabilità.</li>
                    <li><b>Admin</b>: tutto il manager + impostazioni, utenti e backup.</li>
                </ul>
                <div class='small-muted'>Questa struttura è pensata per distribuire il software a più ASD senza permettere agli utenti standard di agire come amministratori.</div>
            </div>
        </div>
        <h3 class='section-title'>Elenco utenti</h3>
        <table><tr><th>Utente</th><th>Email</th><th>Ruolo</th><th>Stato</th><th>Cambio password</th><th>Ultimo accesso</th><th>Azioni</th></tr>{rows_html}</table>
    </div>
    """
    return layout(html_out)


