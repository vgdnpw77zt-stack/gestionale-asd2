from .core import *


def _minor_payload_from_form() -> dict:
   consenso_raw = str(request.form.get("consenso_firmato") or "0")
   return {
       "genitore": request.form.get("genitore", ""),
       "telefono_genitore": request.form.get("telefono_genitore", ""),
       "email_genitore": request.form.get("email_genitore", ""),
       "consenso_firmato": "1" if consenso_raw in {"1", "on", "true", "True"} else "0",
       "data_consenso": request.form.get("data_consenso", ""),
       "note_consenso": request.form.get("note_consenso", ""),
   }


def _guardian_alert_state(row: dict) -> tuple[bool, bool, bool]:
   is_minor = bool(row.get("is_minor"))
   if not is_minor:
       return False, False, False
   has_parent = bool((row.get("genitore") or "").strip())
   has_contact = bool((row.get("telefono_genitore") or "").strip() or (row.get("email_genitore") or "").strip())
   consent_signed = int(row.get("consenso_firmato") or 0) == 1
   is_ok = has_parent and has_contact and consent_signed
   return is_minor, is_ok, consent_signed


def _row_state(row: dict) -> tuple[str, str, list[str], bool]:
   cert_key, cert_label = get_certificato_status(row.get("certificato_scadenza") or "")
   is_minor, guardian_ok, consent_ok = _guardian_alert_state(row)
   issues = []
   if cert_key == "mancante":
       issues.append("Certificato mancante")
   elif cert_key == "scaduto":
       issues.append("Certificato scaduto")
   elif cert_key == "in_scadenza":
       issues.append("Certificato in scadenza")
   if is_minor:
       if not (row.get("genitore") or "").strip():
           issues.append("Serve genitore")
       if not ((row.get("telefono_genitore") or "").strip() or (row.get("email_genitore") or "").strip()):
           issues.append("Manca recapito")
       if not consent_ok:
           issues.append("Consenso mancante")
   if any(x in issues for x in ["Certificato mancante", "Certificato scaduto", "Serve genitore", "Manca recapito", "Consenso mancante"]):
       return "error", cert_label, issues, bool(is_minor and not guardian_ok)
   if cert_key == "in_scadenza":
       return "warning", cert_label, issues, False
   return "ok", cert_label, issues, False




@app.post("/tesserati/pacchetti/create")
@login_required
def tesserati_package_create():
   conn = db()
   c = conn.cursor()
   try:
       tesserato_id = parse_int(request.form.get("tesserato_id"), 0)
       if tesserato_id <= 0:
           raise ValueError("Tesserato non valido.")
       tipo = truncate((request.form.get("tipo") or "Pacchetto ingressi").strip(), 120) or "Pacchetto ingressi"
       ingressi_totali = parse_int(request.form.get("ingressi_totali"), 0)
       ingressi_residui = parse_int(request.form.get("ingressi_residui"), ingressi_totali)
       data_acquisto = parse_date_input((request.form.get("data_acquisto") or "").strip()) or now_iso_date()
       scadenza_raw = (request.form.get("scadenza") or "").strip()
       scadenza = parse_date_input(scadenza_raw) if scadenza_raw else ""
       if scadenza_raw and not scadenza:
           raise ValueError("Data scadenza pacchetto non valida.")
       note = truncate((request.form.get("note") or "").strip(), 400)
       certificato_richiesto = 1 if str(request.form.get("certificato_richiesto") or "0") in {"1","on","true","True"} else 0
       if ingressi_totali <= 0:
           raise ValueError("Inserisci il numero di ingressi del pacchetto.")
       if ingressi_residui < 0 or ingressi_residui > ingressi_totali:
           raise ValueError("Gli ingressi residui devono essere compresi tra 0 e il totale.")
       c.execute("UPDATE packages SET attivo=0, updated_at=? WHERE tesserato_id=?", (now_iso_dt(), tesserato_id))
       c.execute("""
           INSERT INTO packages(tesserato_id, tipo, ingressi_totali, ingressi_residui, data_acquisto, scadenza, certificato_richiesto, attivo, note, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
       """, (tesserato_id, tipo, ingressi_totali, ingressi_residui, data_acquisto, scadenza, certificato_richiesto, note, now_iso_dt(), now_iso_dt()))
       conn.commit()
       return redirect_with_message('/tesserati', 'Pacchetto salvato correttamente.', 'success', edit=tesserato_id, drawer=1)
   except ValueError as exc:
       conn.rollback()
       return redirect_with_message('/tesserati', str(exc), 'error', edit=parse_int(request.form.get("tesserato_id"),0), drawer=1)
   finally:
       conn.close()


@app.post("/tesserati/pacchetti/delete")
@login_required
def tesserati_package_delete():
   conn = db()
   c = conn.cursor()
   try:
       package_id = parse_int(request.form.get("package_id"), 0)
       row = c.execute("SELECT id, tesserato_id FROM packages WHERE id=?", (package_id,)).fetchone()
       if not row:
           return redirect_with_message('/tesserati', 'Pacchetto non trovato.', 'error')
       c.execute("DELETE FROM package_usages WHERE package_id=?", (package_id,))
       c.execute("DELETE FROM packages WHERE id=?", (package_id,))
       conn.commit()
       return redirect_with_message('/tesserati', 'Pacchetto eliminato.', 'success', edit=row['tesserato_id'], drawer=1)
   finally:
       conn.close()

@app.route("/tesserati/wizard")
@login_required
def tesserati_wizard_redirect():
   return redirect('/tesserati?mode=wizard&drawer=1')


@app.route("/tesserati", methods=["GET", "POST"])
@login_required
def tesserati():
   conn = db()
   c = conn.cursor()

   if request.method == "POST":
       action = request.form.get("action", "create")
       minor_payload = _minor_payload_from_form()
       ui_mode = (request.form.get("ui_mode") or "").strip().lower()
       drawer_mode = request.form.get("drawer_mode", "1")
       try:
           nome = require_non_empty(request.form.get("nome", ""), "Nome")
           cognome = require_non_empty(request.form.get("cognome", ""), "Cognome")
           telefono = truncate(request.form.get("telefono", "").strip(), 40)
           corso = truncate(request.form.get("corso", "").strip(), 120)
           luogo_nascita = truncate(request.form.get("luogo_nascita", "").strip(), 120)
           data_nascita_raw = request.form.get("data_nascita", "").strip()
           data_nascita = parse_date_input(data_nascita_raw) if data_nascita_raw else ""
           if data_nascita_raw and not data_nascita:
               raise ValueError("La data di nascita non è valida. Usa GG/MM/AAAA.")
           codice_fiscale = truncate(request.form.get("codice_fiscale", "").strip().upper(), 32)
           residenza = truncate(request.form.get("residenza", "").strip(), 200)
           email = normalize_email(request.form.get("email", "").strip(), 140)
           documento_identita = truncate(request.form.get("documento_identita", "").strip(), 160)
           certificato_raw = request.form.get("certificato", "").strip()
           certificato = ""
           if certificato_raw:
               certificato = parse_date_input(certificato_raw)
               if not certificato:
                   raise ValueError("La data del certificato non è valida. Usa GG/MM/AAAA.")
           is_minor, age = get_minor_status_from_birthdate(data_nascita)
       except ValueError as exc:
           conn.close()
           return layout(alert_html(str(exc), "error"))

       if action == "update":
           rec_id = parse_int(request.form.get("id"), 0)
           c.execute(
               """
               UPDATE tesserati
               SET nome=?, cognome=?, telefono=?, corso=?, certificato_scadenza=?,
                   luogo_nascita=?, data_nascita=?, codice_fiscale=?, residenza=?, email=?, documento_identita=?
               WHERE id=?
               """,
               (
                   nome, cognome, telefono, corso, certificato,
                   luogo_nascita, data_nascita, codice_fiscale, residenza, email, documento_identita,
                   rec_id,
               ),
           )
           tesserato_id = rec_id
           msg = "Tesserato aggiornato correttamente."
       else:
           c.execute(
               """
               INSERT INTO tesserati(
                   nome, cognome, telefono, corso, certificato_scadenza,
                   luogo_nascita, data_nascita, codice_fiscale, residenza, email, documento_identita
               ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               """,
               (
                   nome, cognome, telefono, corso, certificato,
                   luogo_nascita, data_nascita, codice_fiscale, residenza, email, documento_identita,
               ),
           )
           tesserato_id = c.lastrowid
           msg = "Tesserato creato correttamente."

       tesserato_row = {
           "id": tesserato_id,
           "nome": nome,
           "cognome": cognome,
           "telefono": telefono,
           "corso": corso,
           "certificato_scadenza": certificato,
           "luogo_nascita": luogo_nascita,
           "data_nascita": data_nascita,
           "codice_fiscale": codice_fiscale,
           "residenza": residenza,
           "email": email,
           "documento_identita": documento_identita,
       }
       try:
           _minor_created, minor_msg = upsert_minore_from_tesserato(c, tesserato_row, minor_payload)
       except ValueError as exc:
           conn.rollback()
           conn.close()
           return layout(alert_html(str(exc), "error"))

       conn.commit()
       conn.close()
       final_msg = msg
       if is_minor:
           final_msg += f" Rilevato automaticamente minorenne ({age} anni)."
       if minor_msg:
           final_msg += f" {minor_msg}"
       if action == 'update' or ui_mode == 'wizard' or drawer_mode == '1':
           return redirect_with_message('/tesserati', final_msg, 'success', edit=tesserato_id, drawer=1)
       return redirect_with_message('/tesserati', final_msg, 'success')

   edit_row = None
   if request.args.get("edit"):
       edit_id = parse_int(request.args.get("edit"), 0)
       edit_row = c.execute(
           """
           SELECT t.*, m.id AS minor_id, m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato, m.data_consenso, m.note_consenso
           FROM tesserati t
           LEFT JOIN minori m ON m.tesserato_id = t.id
           WHERE t.id=?
           """,
           (edit_id,),
       ).fetchone()

   pacchetti_edit = []
   package_usage_count = 0
   if edit_row:
       package_rows = c.execute("SELECT * FROM packages WHERE tesserato_id=? ORDER BY attivo DESC, id DESC", (edit_row['id'],)).fetchall()
       pacchetti_edit = [dict(r) for r in package_rows]
       if pacchetti_edit:
           package_usage_count = c.execute("SELECT COUNT(*) AS n FROM package_usages WHERE tesserato_id=?", (edit_row['id'],)).fetchone()['n']

   search = request.args.get("search", "").strip()
   filter_key = (request.args.get("filter") or "").strip().lower()
   minor_filter = request.args.get("eta", "").strip().lower()
   mode = (request.args.get('mode') or '').strip().lower()
   drawer_requested = request.args.get('drawer', '') == '1' or bool(edit_row) or mode == 'wizard' or request.args.get('new') == '1'
   wizard_mode = mode == 'wizard' and not edit_row
   base_query = (
       "SELECT t.*, m.id AS minor_id, m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato, m.data_consenso, m.note_consenso "
       "FROM tesserati t LEFT JOIN minori m ON m.tesserato_id = t.id "
   )
   if search:
       rows = c.execute(
           base_query +
           "WHERE t.nome LIKE ? OR t.cognome LIKE ? OR t.corso LIKE ? OR t.codice_fiscale LIKE ? OR t.email LIKE ? ORDER BY t.cognome, t.nome",
           (f"%{search}%", f"%{search}%", f"%{search}%", f"%{search}%", f"%{search}%"),
       ).fetchall()
   else:
       rows = c.execute(base_query + "ORDER BY t.cognome, t.nome").fetchall()

   member_alerts_for_status = get_operational_alerts(*current_month_year())
   filtered_rows = []
   for r in rows:
       is_minor, age = get_minor_status_from_birthdate(r["data_nascita"] or "")
       enriched = dict(r)
       enriched["is_minor"] = is_minor
       enriched["age"] = age
       state_key, cert_label, issues, minor_needs_alert = _row_state(enriched)
       enriched["visual_state"] = state_key
       enriched["cert_label"] = cert_label
       enriched["issues"] = issues
       enriched["minor_needs_alert"] = minor_needs_alert
       enriched["global_status"] = compute_member_status(enriched.get("id"), *current_month_year(), member_alerts_for_status)
       if filter_key == "certificati_mancanti" and get_certificato_status(r["certificato_scadenza"])[0] != "mancante":
           continue
       if filter_key == "certificati_scaduti" and get_certificato_status(r["certificato_scadenza"])[0] != "scaduto":
           continue
       if filter_key == "certificati_in_scadenza" and get_certificato_status(r["certificato_scadenza"])[0] != "in_scadenza":
           continue
       if filter_key == "minori_alert" and not minor_needs_alert:
           continue
       if minor_filter == "minori" and not is_minor:
           continue
       if minor_filter == "maggiorenni" and is_minor:
           continue
       filtered_rows.append(enriched)
   rows = sorted(filtered_rows, key=lambda r: (0 if r['visual_state']=='error' else (1 if r['visual_state']=='warning' else 2), str(r.get('cognome') or '').lower(), str(r.get('nome') or '').lower()))

   total = len(rows)
   blocked_total = sum(1 for r in rows if (r.get('global_status') or {}).get('code') == 'blocked')
   attention_total = sum(1 for r in rows if (r.get('global_status') or {}).get('code') in {'attention','critical'})
   cert_ok = cert_warn = cert_bad = with_email = minors_total = missing_guardian = incomplete_consent = 0
   for r in rows:
       status_key, _ = get_certificato_status(r["certificato_scadenza"])
       if status_key == "valido":
           cert_ok += 1
       elif status_key == "in_scadenza":
           cert_warn += 1
       else:
           cert_bad += 1
       if (r["email"] or "").strip():
           with_email += 1
       is_minor, is_ok, consent_signed = _guardian_alert_state(r)
       if is_minor:
           minors_total += 1
           if not is_ok:
               missing_guardian += 1
           if not consent_signed:
               incomplete_consent += 1

   conn.close()

   form_action = "update" if edit_row else "create"
   form_title = "Aggiorna tesserato" if edit_row else ("Nuova iscrizione guidata" if wizard_mode else "Nuovo tesserato")
   current_birthdate = edit_row["data_nascita"] if edit_row else ""
   current_is_minor, current_age = get_minor_status_from_birthdate(current_birthdate or "")
   current_guardian_ok = False
   current_consent_ok = False
   if edit_row:
       _, current_guardian_ok, current_consent_ok = _guardian_alert_state(dict(edit_row) | {"is_minor": current_is_minor})
   minor_banner = ""
   if current_is_minor:
       tone = 'success' if current_guardian_ok and current_consent_ok else 'warning'
       parent_label = "Tutela minori completa e allineata." if current_guardian_ok and current_consent_ok else "Completa genitore, recapiti e consenso per mantenere la scheda regolare."
       minor_banner = f"<div class='alert {tone}' style='margin-bottom:12px;'><strong>Minorenne rilevato automaticamente.</strong> Età stimata: {current_age} anni. {parent_label}</div>"

   package_section_html = ""
   if edit_row:
       if pacchetti_edit:
           package_rows_html = []
           for p in pacchetti_edit:
               package_rows_html.append(
                   f"<tr><td>{e(p['tipo'])}</td><td>{int(p['ingressi_totali'] or 0)}</td><td>{int(p['ingressi_residui'] or 0)}</td><td>{e(format_display_date(p['scadenza'] or '')) or '-'}</td><td>{'Attivo' if int(p['attivo'] or 0)==1 else 'Storico'}</td><td><form method='POST' action='/tesserati/pacchetti/delete' class='inline-form' onsubmit=\"return confirm('Eliminare questo pacchetto?');\">{csrf_input()}<input type='hidden' name='package_id' value='{int(p['id'])}'><button class='danger'>Elimina</button></form></td></tr>"
               )
           package_table_html = "<table style='margin-top:12px;'><tr><th>Tipo</th><th>Totali</th><th>Residui</th><th>Scadenza</th><th>Stato</th><th>Azioni</th></tr>" + ''.join(package_rows_html) + "</table>"
           first_pkg = pacchetti_edit[0]
       else:
           package_table_html = "<div class='small-muted'>Nessun pacchetto ancora registrato per questo atleta.</div>"
           first_pkg = {}
       checked_pkg = 'checked' if (not pacchetti_edit or int(first_pkg.get('certificato_richiesto') or 0) == 1) else ''
       package_section_html = f"""
             <div class='card soft' style='grid-column:1 / -1;'>
                 <div class='kicker'>Pacchetti ingressi</div>
                 <h4 class='section-title' style='margin-bottom:8px;'>Gestione pacchetto attivo</h4>
                 <div class='small-muted' style='margin-bottom:12px;'>I pacchetti vengono scaricati dalle presenze solo quando esiste un pacchetto attivo. Lo storico utilizzi registrati per questo atleta è <b>{package_usage_count}</b>.</div>
                 <form method='POST' action='/tesserati/pacchetti/create' class='form-row'>
                     {csrf_input()}
                     <input type='hidden' name='tesserato_id' value='{edit_row['id']}'>
                     <input name='tipo' placeholder='Tipo pacchetto' value='{e(first_pkg.get('tipo',''))}'>
                     <input name='ingressi_totali' type='number' min='1' placeholder='Ingressi totali' value='{e(first_pkg.get('ingressi_totali',''))}'>
                     <input name='ingressi_residui' type='number' min='0' placeholder='Ingressi residui' value='{e(first_pkg.get('ingressi_residui',''))}'>
                     <input name='data_acquisto' placeholder='Data acquisto (DD/MM/YYYY)' value='{e(format_display_date(first_pkg.get('data_acquisto','')))}'>
                     <input name='scadenza' placeholder='Scadenza (DD/MM/YYYY)' value='{e(format_display_date(first_pkg.get('scadenza','')))}'>
                     <label style='align-self:center;'><input type='checkbox' name='certificato_richiesto' value='1' {checked_pkg}> Certificato richiesto</label>
                     <textarea name='note' placeholder='Note pacchetto'>{e(first_pkg.get('note',''))}</textarea>
                     <button>Salva pacchetto</button>
                 </form>
                 {package_table_html}
             </div>
       """

   metric_html = f"""
   <div class='metric-strip'>
      <div class='metric-box'><div class='label'>Tesserati visibili</div><div class='value'>{total}</div></div>
      <div class='metric-box danger'><div class='label'>Atleti bloccati</div><div class='value'>{blocked_total}</div></div>
      <div class='metric-box warn'><div class='label'>In attenzione</div><div class='value'>{attention_total}</div></div>
      <div class='metric-box'><div class='label'>Minori rilevati</div><div class='value'>{minors_total}</div></div>
      <div class='metric-box'><div class='label'>Alert genitore</div><div class='value'>{missing_guardian}</div></div>
      <div class='metric-box'><div class='label'>Consensi mancanti</div><div class='value'>{incomplete_consent}</div></div>
      <div class='metric-box'><div class='label'>Certificati validi</div><div class='value'>{cert_ok}</div></div>
      <div class='metric-box'><div class='label'>In scadenza</div><div class='value'>{cert_warn}</div></div>
      <div class='metric-box'><div class='label'>Criticità archivio</div><div class='value'>{cert_bad + missing_guardian}</div></div>
      <div class='metric-box'><div class='label'>Email presenti</div><div class='value'>{with_email}</div></div>
   </div>
   """

   rows_html = []
   for r in rows:
       cert_key = get_certificato_status(r["certificato_scadenza"])[0]
       row_class = 'table-row-ok' if r['visual_state'] == 'ok' else ('table-row-warning' if r['visual_state'] == 'warning' else 'table-row-error')
       dot = 'green' if r['visual_state'] == 'ok' else ('yellow' if r['visual_state'] == 'warning' else 'red')
       minor_badge = "<span class='pill'>Minore</span>" if r.get("is_minor") else ""
       # Niente badge duplicati sopra il nome: lasciamo solo il badge strutturale "Minore".
       issue_badges = ''
       is_minor, guardian_ok, consent_ok = _guardian_alert_state(r)
       if is_minor:
           if guardian_ok:
               guardian_state = "<span class='badge valido'><span class='badge-dot dot-green'></span>Tutela completa</span>"
           elif (r.get('genitore') or '').strip():
               guardian_state = "<span class='badge in_scadenza'><span class='badge-dot dot-yellow'></span>Completa recapiti</span>"
           else:
               guardian_state = "<span class='badge scaduto'><span class='badge-dot dot-red'></span>Serve genitore</span>"
       else:
           guardian_state = "<span class='small-muted'>—</span>"
       status_badge_class = 'valido' if cert_key == 'valido' else ('in_scadenza' if cert_key == 'in_scadenza' else 'scaduto')
       rows_html.append(f"""
       <tr class='{row_class}'>
           <td><strong>{e(r['nome'])} {e(r['cognome'])}</strong><div class='small-muted'>{minor_badge} {render_member_status_badge(r.get('global_status') or {})}</div></td>
           <td>{e(r['corso'] or '-')}</td>
           <td>{e(r['telefono'] or '-')}</td>
           <td>{e(r['email'] or '-')}</td>
           <td>{e(format_display_date(r['data_nascita'])) or '-'}{'<div class="small-muted">'+str(r.get('age'))+' anni</div>' if r.get('age') is not None else ''}</td>
           <td>{guardian_state}</td>
           <td><span class='badge {status_badge_class}'><span class='badge-dot dot-{dot}'></span>{e(r['cert_label'])}</span></td>
           <td>
               <div class='actions'>
                   <a href='/tesserati?edit={r['id']}&drawer=1'>Apri scheda</a>
                   <a href='/documenti?tesserato_id={r['id']}'>Documenti</a>\n                   <a href='/documenti/iscrizione-csen/{r['id']}'>Modulo iscrizione</a>
                   <a href='/pagamenti?tesserato_id={r['id']}'>Pagamenti</a>
                   <form method='POST' action='/tesserati/delete' class='inline-form' onsubmit="return confirm('Eliminare questo tesserato?');">
                       {csrf_input()}
                       <input type='hidden' name='id' value='{r['id']}'>
                       <button class='danger'>Elimina</button>
                   </form>
               </div>
           </td>
       </tr>
       """)
   table_html = ''.join(rows_html) if rows_html else "<tr><td colspan='8'><div class='empty-state'>Nessun tesserato trovato.</div></td></tr>"

   quick_cards = f"""
   <div class='compact-stat-grid'>
       <div class='mini-card'>
           <div class='kicker'>Controlli rapidi</div>
           <strong>Criticità reali</strong>
           <div class='small-muted'>Certificati mancanti o scaduti, tutela minori incompleta e dati da chiudere subito.</div>
           <div class='toolbar-actions' style='margin-top:12px;'>
               <a href='/tesserati?filter=certificati_mancanti' class='nav-link' style='display:inline-flex;padding:10px 14px;width:auto;'>Mancanti</a>
               <a href='/tesserati?filter=certificati_scaduti' class='nav-link' style='display:inline-flex;padding:10px 14px;width:auto;'>Scaduti</a>
               <a href='/tesserati?filter=minori_alert' class='nav-link' style='display:inline-flex;padding:10px 14px;width:auto;'>Minori con alert</a>
           </div>
       </div>
       <div class='mini-card'>
           <div class='kicker'>Archivio</div>
           <strong>Copertura contatti</strong>
           <div class='small-muted'>Email presenti: <b>{with_email}</b> su <b>{total}</b>. Più l'anagrafica è completa, più rende bene su documenti e comunicazioni.</div>
       </div>
   </div>
   """

   mode_hidden = "wizard" if wizard_mode else "standard"
   drawer_open_class = 'open' if drawer_requested else ''
   close_href = '/tesserati'

   drawer_intro = ""
   if wizard_mode:
       drawer_intro = """
       <div class='card soft' style='margin-bottom:14px;'>
           <div class='kicker'>Wizard premium</div>
           <div class='small-muted'>Percorso guidato in 3 passi: anagrafica, contatti e tutela minori. La scheda resta nello stesso contesto della tabella senza spaccare la pagina.</div>
       </div>
       """

   drawer_body = f"""
   <div class='drawer-shell {drawer_open_class}' id='tesserato-drawer'>
      <div class='drawer-backdrop' data-close-drawer='1'></div>
      <div class='drawer-panel'>
         <div class='drawer-head'>
            <div>
               <div class='kicker'>{'Wizard iscrizione' if wizard_mode else 'Scheda atleta'}</div>
               <h3 class='section-title'>{form_title}</h3>
               <div class='small-muted'>Compila l’anagrafica essenziale, i contatti e la scadenza del certificato. Se l’atleta è minorenne, la parte genitore si apre in automatico.</div>
            </div>
            <a href='{close_href}' class='drawer-close' aria-label='Chiudi'>×</a>
         </div>
         {drawer_intro}
         {minor_banner}
         <form method='POST' class='form-row' id='tesserato-form'>
             {csrf_input()}
             <input type='hidden' name='action' value='{form_action}'>
             <input type='hidden' name='ui_mode' value='{mode_hidden}'>
             <input type='hidden' name='drawer_mode' value='1'>
             <input type='hidden' name='id' value='{edit_row['id'] if edit_row else ''}'>
             <div class='card soft' style='grid-column:1 / -1;'>
                 <div class='kicker'>Anagrafica</div>
                 <div class='form-row'>
                     <input name='nome' placeholder='Nome' required value='{e(edit_row['nome'] if edit_row else '')}'>
                     <input name='cognome' placeholder='Cognome' required value='{e(edit_row['cognome'] if edit_row else '')}'>
                     <input name='corso' placeholder='Corso' value='{e(edit_row['corso'] if edit_row else '')}'>
                     <input name='luogo_nascita' placeholder='Luogo di nascita' value='{e(edit_row['luogo_nascita'] if edit_row else '')}'>
                     <input name='data_nascita' id='data_nascita' placeholder='Data di nascita (DD/MM/YYYY)' value='{e(format_display_date(edit_row['data_nascita']) if edit_row else '')}'>
                     <input name='codice_fiscale' placeholder='Codice fiscale' value='{e(edit_row['codice_fiscale'] if edit_row else '')}'>
                 </div>
             </div>
             <div class='card soft' style='grid-column:1 / -1;'>
                 <div class='kicker'>Contatti e documenti</div>
                 <div class='form-row'>
                     <input name='telefono' placeholder='Telefono atleta' value='{e(edit_row['telefono'] if edit_row else '')}'>
                     <input name='email' placeholder='Email atleta' value='{e(edit_row['email'] if edit_row else '')}'>
                     <input name='residenza' placeholder='Residenza' value='{e(edit_row['residenza'] if edit_row else '')}'>
                     <input name='documento_identita' placeholder='Documento di identità allegato' value='{e(edit_row['documento_identita'] if edit_row else '')}'>
                     <input name='certificato' placeholder='Certificato scadenza (DD/MM/YYYY)' value='{e(format_display_date(edit_row['certificato_scadenza']) if edit_row else '')}'>
                 </div>
             </div>
             <div id='minor-panel' class='card soft' style='grid-column:1 / -1;display:{'block' if current_is_minor else 'none'};'>
                 <div class='kicker'>Tutela minori</div>
                 <h4 class='section-title' style='margin-bottom:8px;'>Genitore / tutore</h4>
                 <div id='minor-alert' class='alert warning' style='margin-bottom:12px;'>Questo atleta risulta minorenne. Inserisci i dati del genitore o tutore: la categoria <strong>Minori</strong> verrà aggiornata in automatico.</div>
                 <div class='form-row'>
                     <input name='genitore' placeholder='Genitore / tutore' value='{e(edit_row['genitore'] if edit_row and edit_row['genitore'] else '')}'>
                     <input name='telefono_genitore' placeholder='Telefono genitore' value='{e(edit_row['telefono_genitore'] if edit_row and edit_row['telefono_genitore'] else '')}'>
                     <input name='email_genitore' placeholder='Email genitore' value='{e(edit_row['email_genitore'] if edit_row and edit_row['email_genitore'] else '')}'>
                     <input name='data_consenso' placeholder='Data consenso (DD/MM/YYYY)' value='{e(format_display_date(edit_row['data_consenso']) if edit_row and edit_row['data_consenso'] else '')}'>
                     <label style='align-self:center;'><input type='checkbox' name='consenso_firmato' value='1' {'checked' if edit_row and int(edit_row['consenso_firmato'] or 0) == 1 else ''}> Consenso firmato</label>
                     <textarea name='note_consenso' placeholder='Note consenso / documentazione'>{e(edit_row['note_consenso'] if edit_row and edit_row['note_consenso'] else '')}</textarea>
                 </div>
             </div>
             <div class='toolbar-actions' style='grid-column:1 / -1;'>
                 <button>{'Aggiorna tesserato' if edit_row else ('Completa iscrizione guidata' if wizard_mode else 'Salva tesserato')}</button>
                 <a href='{close_href}' style='align-self:center;'>Chiudi</a>
                 {f"<a href='/documenti?tesserato_id={edit_row['id']}' style='align-self:center;'>Apri documenti atleta</a> <a href='/documenti/iscrizione-csen/{edit_row['id']}' style='align-self:center;'>Genera modulo CSEN</a>" if edit_row else ''}
             </div>
         </form>
         {package_section_html}
      </div>
   </div>
   """

   return layout(f"""
   <div class='app-section-hero'>
       <div>
           <div class='kicker'>Anagrafica sportiva</div>
           <h2 class='section-title'>Tesserati</h2>
           <div class='small-muted'>Vista più compatta, tabella più leggibile e scheda atleta aperta solo quando serve davvero.</div>
       </div>
       <div class='page-actions'>
           <a href='/tesserati?new=1&drawer=1' class='cta-primary'>Nuovo tesserato</a>
           <a href='/tesserati/wizard' class='cta-secondary'>Iscrizione guidata</a>
           
       </div>
   </div>
   {metric_html}
   <div class='compact-grid'>
       <div class='card form-panel card-elevated'>
           <div class='kicker'>Filtro operativo</div>
           <h3 class='section-title'>Ricerca e segmenti</h3>
           <form method='GET' class='form-row' style='margin-bottom:10px;'>
               <input name='search' value='{e(search)}' placeholder='Cerca nome, cognome, corso, CF o email'>
               <select name='filter'><option value=''>Tutti</option><option value='certificati_mancanti' {'selected' if filter_key=='certificati_mancanti' else ''}>Certificati mancanti</option><option value='certificati_scaduti' {'selected' if filter_key=='certificati_scaduti' else ''}>Certificati scaduti</option><option value='certificati_in_scadenza' {'selected' if filter_key=='certificati_in_scadenza' else ''}>In scadenza 30 giorni</option><option value='minori_alert' {'selected' if filter_key=='minori_alert' else ''}>Minori con alert</option></select>
               <select name='eta'><option value=''>Tutte le età</option><option value='minori' {'selected' if minor_filter=='minori' else ''}>Solo minori</option><option value='maggiorenni' {'selected' if minor_filter=='maggiorenni' else ''}>Solo maggiorenni</option></select>
               <button>Cerca</button>
               <a href='/tesserati' class='nav-link' style='display:inline-flex;padding:10px 14px;width:auto;'>Reset</a>
           </form>
           <div class='toolbar-actions'>
               <a href='/tesserati?eta=minori' class='nav-link' style='display:inline-flex;padding:10px 14px;width:auto;'>Vedi minori</a>
               <a href='/tesserati?filter=certificati_mancanti' class='nav-link' style='display:inline-flex;padding:10px 14px;width:auto;'>Vedi mancanti</a>
               <a href='/tesserati?filter=certificati_scaduti' class='nav-link' style='display:inline-flex;padding:10px 14px;width:auto;'>Vedi scaduti</a>
               <a href='/minori' class='nav-link' style='display:inline-flex;padding:10px 14px;width:auto;'>Apri categoria Minori</a>
           </div>
           <div class='form-hint'>Il software riconosce automaticamente i minori dalla data di nascita e chiede i dati del genitore solo quando servono davvero.</div>
       </div>
       {quick_cards}
   </div>
   <div class='card'>
       <div class='table-toolbar'>
           <div>
               <div class='kicker'>Archivio completo</div>
               <h3 class='section-title' style='margin-bottom:4px;'>Elenco tesserati</h3>
               <div class='small-muted'>Righe più compatte, stato visivo coerente e apertura scheda in drawer laterale.</div>
           </div>
       </div>
       <table>
           <tr><th>Tesserato / Stato</th><th>Corso</th><th>Telefono</th><th>Email</th><th>Data nascita</th><th>Tutela</th><th>Certificato</th><th>Azioni</th></tr>
           {table_html}
       </table>
   </div>
   {drawer_body}
   <script>
   (function() {{
       const birth = document.getElementById('data_nascita');
       const panel = document.getElementById('minor-panel');
       if (birth && panel) {{
           function parseItalianDate(value) {{
               const v = (value || '').trim();
               if (!v) return null;
               const parts = v.includes('/') ? v.split('/') : (v.includes('-') ? v.split('-') : []);
               if (parts.length !== 3) return null;
               let day, month, year;
               if (v.includes('/')) {{ day = parseInt(parts[0], 10); month = parseInt(parts[1], 10); year = parseInt(parts[2], 10); }}
               else if (parts[0].length === 4) {{ year = parseInt(parts[0], 10); month = parseInt(parts[1], 10); day = parseInt(parts[2], 10); }}
               else {{ day = parseInt(parts[0], 10); month = parseInt(parts[1], 10); year = parseInt(parts[2], 10); }}
               if (!day || !month || !year) return null;
               return new Date(year, month - 1, day);
           }}
           function refreshMinorPanel() {{
               const d = parseItalianDate(birth.value);
               if (!d || Number.isNaN(d.getTime())) {{ panel.style.display = 'none'; return; }}
               const now = new Date();
               let age = now.getFullYear() - d.getFullYear();
               const m = now.getMonth() - d.getMonth();
               if (m < 0 || (m === 0 && now.getDate() < d.getDate())) age--;
               panel.style.display = age < 18 ? 'block' : 'none';
           }}
           birth.addEventListener('input', refreshMinorPanel);
           birth.addEventListener('change', refreshMinorPanel);
           refreshMinorPanel();
       }}
       document.querySelectorAll('[data-close-drawer="1"]').forEach(function(el) {{
           el.addEventListener('click', function() {{ window.location.href = '{close_href}'; }});
       }});
   }})();
   </script>
   """)


@app.route("/tesserati/delete", methods=["POST"])
@login_required
def tesserati_delete():
   rec_id = parse_int(request.form.get("id"), 0)
   if rec_id <= 0:
       return redirect_with_message("/tesserati", "Tesserato non valido.", "error")
   conn = db()
   conn.execute("DELETE FROM minori WHERE tesserato_id=?", (rec_id,))
   conn.execute("DELETE FROM tesserati WHERE id=?", (rec_id,))
   conn.commit()
   conn.close()
   media_dir = get_tesserato_media_dir(rec_id)
   if media_dir.exists():
       shutil.rmtree(media_dir, ignore_errors=True)
   log_audit("tesserato_delete", details=f"Tesserato eliminato: id={rec_id}", entity_type="tesserato", entity_id=str(rec_id))
   return redirect_with_message("/tesserati", "Tesserato eliminato correttamente.", "success")
