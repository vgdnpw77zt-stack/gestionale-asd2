from .core import *


@app.route("/presenze", methods=["GET", "POST"])
@login_required
def presenze():
    conn = db()
    c = conn.cursor()

    selected_date = parse_date_input(request.args.get("data", "").strip()) or now_iso_date()
    selected_course = parse_int(request.args.get("corso_id", "0"), 0)
    corsi = c.execute("SELECT * FROM corsi ORDER BY nome").fetchall()

    if request.method == "POST":
        try:
            data = require_valid_date(request.form.get("data", "").strip(), "la data")
            corso_id = parse_int(request.form.get("corso_id", "0"), 0)
            if corso_id <= 0:
                raise ValueError("Seleziona un corso.")
        except ValueError as exc:
            conn.close()
            return redirect_with_message("/presenze", str(exc), "error")

        corso_row = c.execute("SELECT * FROM corsi WHERE id=?", (corso_id,)).fetchone()
        if not corso_row:
            conn.close()
            return redirect_with_message("/presenze", "Corso non trovato.", "error")

        iscritti = c.execute(
            "SELECT id FROM tesserati WHERE corso=? ORDER BY cognome, nome",
            (corso_row["nome"],),
        ).fetchall()
        candidate_ids = {int(r["id"]) for r in iscritti}

        c.execute("DELETE FROM presenze WHERE corso_id=? AND data=?", (corso_id, data))
        inserted = 0
        assenti = 0
        present_ids_post = set()
        for tesserato_id in candidate_ids:
            is_present = request.form.get(f"pres_{tesserato_id}") == "1"
            stato = "presente" if is_present else "assente"
            if is_present:
                inserted += 1
                present_ids_post.add(tesserato_id)
            else:
                assenti += 1
            c.execute(
                """
                INSERT INTO presenze(tesserato_id, corso_id, data, stato, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (tesserato_id, corso_id, data, stato, now_iso_dt(), now_iso_dt()),
            )

        reconcile_package_usages(c, corso_id, data, present_ids_post)
        conn.commit()
        conn.close()
        return redirect_with_message(
            "/presenze",
            f"Registro aggiornato: {inserted} presenti, {assenti} assenti.",
            "success",
            data=data,
            corso_id=corso_id,
        )

    tesserati = []
    present_ids = set()
    status_by_id = {}
    selected_course_row = None
    if selected_course > 0:
        selected_course_row = c.execute("SELECT * FROM corsi WHERE id=?", (selected_course,)).fetchone()
        if selected_course_row:
            tesserati = c.execute(
                "SELECT * FROM tesserati WHERE corso=? ORDER BY cognome, nome",
                (selected_course_row["nome"],),
            ).fetchall()
            present_rows = c.execute(
                "SELECT tesserato_id FROM presenze WHERE corso_id=? AND data=? AND stato='presente' AND stato='presente'",
                (selected_course, selected_date),
            ).fetchall()
            present_ids = {int(row["tesserato_id"]) for row in present_rows}
            status_rows = c.execute("SELECT tesserato_id, stato FROM presenze WHERE corso_id=? AND data=?", (selected_course, selected_date)).fetchall()
            status_by_id = {int(row["tesserato_id"]): (row["stato"] or "assente") for row in status_rows}

    conn.close()

    options = "<option value='0'>Seleziona corso</option>" + "".join(
        f"<option value='{c['id']}' {'selected' if int(c['id']) == selected_course else ''}>{e(c['nome'])}</option>"
        for c in corsi
    )
    rows = "".join(
        f"""
        <tr>
            <td><b>{e(t['nome'])} {e(t['cognome'])}</b></td>
            <td>{e(t['corso'] or '-')}</td>
            <td>{e(format_display_date(selected_date))}</td>
            <td style='text-align:center;'>
                <div class='presenze-status-row'>
                    <span class='presence-dot {'presente' if int(t['id']) in present_ids else ('giustificato' if status_by_id.get(int(t['id'])) == 'giustificato' else 'assente')}'></span>
                    <span class='presenze-status-label'>{'Presente' if int(t['id']) in present_ids else ('Giustificato' if status_by_id.get(int(t['id'])) == 'giustificato' else 'Assente')}</span>
                    <input type='checkbox' name='pres_{t['id']}' value='1' {'checked' if int(t['id']) in present_ids else ''} style='min-width:auto;transform:scale(1.15);'>
                </div>
            </td>
        </tr>
        """
        for t in tesserati
    )

    stats_html = f"""
    <div class='presenze-header'>
      <div class='presenze-stat presente'>
        <span>Presenti</span>
        <b>{len(present_ids)}</b>
      </div>
      <div class='presenze-stat assente'>
        <span>Assenti</span>
        <b>{max(0, len(tesserati) - len(present_ids))}</b>
      </div>
      <div class='presenze-stat totale'>
        <span>Totale</span>
        <b>{len(tesserati)}</b>
      </div>
    </div>
    <div class='presenze-actions'>
      <button type='button' class='success' onclick='markAll(true)'>Tutti presenti</button>
      <button type='button' class='danger' onclick='markAll(false)'>Tutti assenti</button>
      <a href='/giornata'>Giornata operativa</a>
      <a href='/documenti'>DOCX</a>
    </div>
    """

    helper = (
        "Il registro salva presenti e assenti; i pacchetti vengono scaricati solo ai presenti una sola volta per corso/data."
        if selected_course_row
        else "Prima scegli un corso: così il registro resta pulito e non mischia atleti di corsi diversi."
    )

    return layout(f'''
    <div class="app-section-hero">
        <div>
            <div class="kicker">Corsi & presenze</div>
            <h2 class="section-title">Registro presenze</h2>
            <div class="small-muted">Un solo flusso: scegli il corso, carica gli iscritti corretti e salva il registro senza doppi scarichi pacchetti.</div>
        </div>
        <div class="page-actions">
            <a href="/corsi" class="nav-link" style="display:inline-flex;padding:10px 14px;width:auto;">Gestisci corsi</a>
        </div>
    </div>
    <div class="card">
        <form method="GET" class="form-row">
            <input type="date" name="data" value="{e(selected_date)}">
            <select name="corso_id">{options}</select>
            <button>Carica registro</button>
        </form>
        <div class="small-muted" style="margin-top:10px;">{helper}</div>
    </div>
    <div class="card">
        <form method="POST">
            {csrf_input()}
            <input type="hidden" name="data" value="{e(selected_date)}">
            <input type="hidden" name="corso_id" value="{selected_course}">
            {stats_html}
            <table>
                <tr><th>Tesserato</th><th>Corso</th><th>Data</th><th style="text-align:center;">Stato / Presente</th></tr>
                {rows if rows else "<tr><td colspan='4'><div class='empty-state'>Nessun atleta collegato a questo corso.</div></td></tr>"}
            </table>
            <div class="actions" style="margin-top:14px;">
                <button {'disabled' if selected_course <= 0 else ''}>Salva presenze</button>
                <span class="small-muted">Il salvataggio sostituisce il registro del giorno scelto in modo coerente.</span>
            </div>
        </form>
    </div>
    ''')
