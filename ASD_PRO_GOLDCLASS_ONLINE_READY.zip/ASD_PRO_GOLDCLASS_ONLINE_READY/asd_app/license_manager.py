from __future__ import annotations

import hashlib
import hmac
import json
import os
import sys
import platform
import uuid
from datetime import datetime
from pathlib import Path
from typing import Iterable

# Licenze cliente: firma RSA SHA-256 offline.
# La APP contiene SOLO la chiave pubblica. La chiave privata resta nello spazio sviluppatore
# OWNER_DEV_LICENSE_KIT/private_key.json e non deve mai entrare in DMG/EXE cliente.
PUBLIC_KEY = {
    "kty": "RSA",
    "n": "0x8ab6c344eb1ddb458df635c831883cf463f8b492f1564741f17ce6bff4d4aff59b118359c22803c42aa7a4048f6d6fbdbf964c39342804fb183a9b4e1019d89b0c6949f8d66ecf9ef1737c0c03912857a86875907e50fad8af9b9ff184dfbdb0227ca7df7f32b5ecc394f1ac18c1a3df4cc18b8f5d949484dabbce464f42c445ce046d9a0d329241aa89d72e34b7850d26a3497a2fab964b2e25beb882d8e8ceb283b9ad1c5ef8872543d62fe1dd2cffae0ee779cc342ccb09c63f0279af16e60793ad53de160ae974a33ea4f641f32d49d41e011540d5ceee436024ba601ab6d134a997fba64355737d064278b5a7798e18801484529f5064a416785d2a7a0b",
    "e": 65537,
    "alg": "RS256",
    "use": "sig",
}

# Legacy HMAC: accettato solo se esplicitamente abilitato in ambiente sviluppatore.
LEGACY_HMAC_SECRET = "ASD_PRO_SYSTEM_LIC_2026_V1"
DEFAULT_FILENAME = "license.json"
DEVELOPER_BYPASS_FILENAME = ".developer_bypass"
OWNER_DEV_DIRNAME = "OWNER_DEV_LICENSE_KIT"
PRIVATE_KEY_FILENAME = "private_key.json"
RSA_DIGESTINFO_SHA256_PREFIX = bytes.fromhex("3031300d060960864801650304020105000420")


DEVICE_BINDING_ENV = "ASD_LICENSE_DEVICE_ID"


def current_device_fingerprint() -> str:
    """Fingerprint locale stabile ma non invasivo.
    In produzione può essere letto dal cliente e mandato allo sviluppatore per generare
    una licenza legata al dispositivo. Override possibile con ASD_LICENSE_DEVICE_ID.
    """
    override = os.environ.get(DEVICE_BINDING_ENV, "").strip()
    if override:
        return override
    raw = "|".join([
        platform.node() or "unknown-host",
        platform.system() or "unknown-os",
        platform.machine() or "unknown-machine",
        str(uuid.getnode() or "0"),
    ])
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]


def _int_from_hex(value: str | int) -> int:
    if isinstance(value, int):
        return value
    text = str(value).strip().lower()
    return int(text, 16 if text.startswith("0x") else 10)


def _public_key() -> tuple[int, int]:
    return _int_from_hex(PUBLIC_KEY["n"]), int(PUBLIC_KEY["e"])


def _key_size_bytes(n: int) -> int:
    return (int(n).bit_length() + 7) // 8


def _canonical_json(data: dict) -> str:
    return json.dumps(canonical_payload(data), ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def _rsassa_pkcs1_v1_5_encode_sha256(message: bytes, key_size: int) -> bytes:
    digest = hashlib.sha256(message).digest()
    digest_info = RSA_DIGESTINFO_SHA256_PREFIX + digest
    ps_len = key_size - len(digest_info) - 3
    if ps_len < 8:
        raise ValueError("Chiave RSA troppo corta")
    return b"\x00\x01" + (b"\xff" * ps_len) + b"\x00" + digest_info


def _rsa_sign_sha256(data: dict, private_key: dict) -> str:
    n = _int_from_hex(private_key["n"])
    d = _int_from_hex(private_key["d"])
    encoded = _rsassa_pkcs1_v1_5_encode_sha256(_canonical_json(data).encode("utf-8"), _key_size_bytes(n))
    sig_int = pow(int.from_bytes(encoded, "big"), d, n)
    return sig_int.to_bytes(_key_size_bytes(n), "big").hex()


def _rsa_verify_sha256(data: dict, signature_hex: str) -> bool:
    try:
        n, e = _public_key()
        key_size = _key_size_bytes(n)
        sig = bytes.fromhex(str(signature_hex or "").strip())
        if len(sig) != key_size:
            return False
        decoded_int = pow(int.from_bytes(sig, "big"), e, n)
        decoded = decoded_int.to_bytes(key_size, "big")
        expected = _rsassa_pkcs1_v1_5_encode_sha256(_canonical_json(data).encode("utf-8"), key_size)
        return hmac.compare_digest(decoded, expected)
    except Exception:
        return False


def developer_bypass_path(base_dir: str | Path) -> Path:
    """Percorso legacy locale. Non deve entrare in build cliente."""
    return Path(base_dir) / DEVELOPER_BYPASS_FILENAME


def owner_developer_bypass_path(app_base_dir: str | Path) -> Path:
    """Percorso corretto per il proprietario: SVILUPPATORE/OWNER_DEV_LICENSE_KIT/.developer_bypass."""
    return Path(app_base_dir).resolve().parent / OWNER_DEV_DIRNAME / DEVELOPER_BYPASS_FILENAME


def owner_private_key_path(app_base_dir: str | Path) -> Path:
    return Path(app_base_dir).resolve().parent / OWNER_DEV_DIRNAME / PRIVATE_KEY_FILENAME


def developer_bypass_enabled(base_dir: str | Path, app_base_dir: str | Path | None = None) -> bool:
    if os.environ.get("ASD_DEV_BYPASS", "").strip() == "1" and not getattr(sys, "frozen", False):
        return True
    # In build PyInstaller il bypass da file è sempre disabilitato.
    if getattr(sys, "frozen", False):
        return False
    candidates = [developer_bypass_path(base_dir), owner_developer_bypass_path(app_base_dir or base_dir)]
    return any(p.exists() and p.is_file() for p in candidates)


def enable_developer_bypass(base_dir: str | Path, note: str = "owner") -> Path:
    path = owner_developer_bypass_path(base_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(str(note or "owner").strip() + "\n", encoding="utf-8")
    return path


def disable_developer_bypass(base_dir: str | Path) -> None:
    for path in (developer_bypass_path(base_dir), owner_developer_bypass_path(base_dir)):
        if path.exists():
            path.unlink()


def license_file_path(base_dir: str | Path) -> Path:
    return Path(base_dir) / DEFAULT_FILENAME


def _normalize_features(features: Iterable[str] | None) -> list[str]:
    clean = []
    for item in (features or []):
        value = str(item or "").strip().lower()
        if value and value not in clean:
            clean.append(value)
    return sorted(clean)


def canonical_payload(data: dict) -> dict:
    cliente = data.get("cliente") if data.get("cliente") not in (None, "") else data.get("customer_name")
    codice_cliente = data.get("codice_cliente") if data.get("codice_cliente") not in (None, "") else data.get("customer_code")
    scadenza = data.get("scadenza") if data.get("scadenza") not in (None, "") else data.get("expires_at")
    max_utenti = data.get("max_utenti") if data.get("max_utenti") not in (None, "") else data.get("max_users")
    piano = data.get("piano") if data.get("piano") not in (None, "") else data.get("plan")
    device_id = data.get("device_id") or data.get("device_fingerprint") or data.get("hardware_id") or ""
    return {
        "cliente": str(cliente or "").strip(),
        "codice_cliente": str(codice_cliente or "").strip().upper(),
        "scadenza": str(scadenza or "").strip(),
        "max_utenti": int(max_utenti or 1),
        "piano": str(piano or "standard").strip().lower(),
        "features": _normalize_features(data.get("features") or []),
        "device_id": str(device_id or "").strip(),
    }


def _load_private_key(private_key_path: str | Path | None = None, app_base_dir: str | Path | None = None) -> dict:
    env_path = os.environ.get("ASD_LICENSE_PRIVATE_KEY_FILE", "").strip()
    candidates: list[Path] = []
    if private_key_path:
        candidates.append(Path(private_key_path).expanduser())
    if env_path:
        candidates.append(Path(env_path).expanduser())
    if app_base_dir:
        candidates.append(owner_private_key_path(app_base_dir))
    candidates.append(Path(__file__).resolve().parents[2] / OWNER_DEV_DIRNAME / PRIVATE_KEY_FILENAME)
    for path in candidates:
        try:
            if path.exists() and path.is_file():
                return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
    raise FileNotFoundError("Chiave privata licenze non trovata nello spazio sviluppatore")


def build_license(data: dict, private_key_path: str | Path | None = None, app_base_dir: str | Path | None = None) -> dict:
    payload = canonical_payload(data)
    private_key = _load_private_key(private_key_path=private_key_path, app_base_dir=app_base_dir)
    payload["signature_alg"] = "RS256"
    payload["signature"] = _rsa_sign_sha256(payload, private_key)
    return payload


def save_license(data: dict, destination: str | Path, private_key_path: str | Path | None = None, app_base_dir: str | Path | None = None) -> Path:
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = build_license(data, private_key_path=private_key_path, app_base_dir=app_base_dir)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def load_license(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _legacy_hmac_expected(data: dict) -> str:
    payload = canonical_payload(data)
    base = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return hmac.new(os.environ.get("ASD_LICENSE_SECRET", LEGACY_HMAC_SECRET).encode("utf-8"), base.encode("utf-8"), hashlib.sha256).hexdigest()


def validate_license_file(path: str | Path) -> tuple[bool, dict | str]:
    try:
        raw = load_license(path)
    except FileNotFoundError:
        return False, "Licenza assente"
    except Exception as exc:
        return False, f"Licenza non leggibile: {exc}"
    try:
        payload = canonical_payload(raw)
        if not payload["cliente"]:
            return False, "Campo cliente mancante"
        if not payload["codice_cliente"]:
            return False, "Codice cliente mancante"
        alg = str(raw.get("signature_alg") or "").strip().upper()
        signature = str(raw.get("signature") or "").strip()
        if alg == "RS256":
            if not _rsa_verify_sha256(payload, signature):
                return False, "Firma RSA licenza non valida"
        elif os.environ.get("ASD_ALLOW_LEGACY_HMAC_LICENSES", "").strip() == "1":
            expected = _legacy_hmac_expected(payload)
            if not hmac.compare_digest(signature, expected):
                return False, "Firma licenza legacy non valida"
            payload["signature_alg"] = "HMAC-SHA256-LEGACY"
        else:
            return False, "Algoritmo licenza non supportato: serve RS256"
        expiry = datetime.strptime(payload["scadenza"], "%Y-%m-%d").date()
        if datetime.now().date() > expiry:
            return False, f"Licenza scaduta il {expiry.isoformat()}"
        licensed_device = str(payload.get("device_id") or "").strip()
        if licensed_device and licensed_device not in {"*", "ANY", "any"}:
            current_device = current_device_fingerprint()
            if not hmac.compare_digest(licensed_device, current_device):
                return False, "Licenza non valida per questo dispositivo"
        payload["device_fingerprint_current"] = current_device_fingerprint()
        payload["signature_alg"] = alg or payload.get("signature_alg") or "RS256"
        return True, payload
    except Exception as exc:
        return False, f"Licenza non valida: {exc}"


def find_and_validate_license(base_dir: str | Path, app_base_dir: str | Path | None = None) -> tuple[bool, dict | str, Path]:
    if developer_bypass_enabled(base_dir, app_base_dir):
        path = owner_developer_bypass_path(app_base_dir or base_dir)
        return True, {
            "cliente": "SVILUPPATORE",
            "codice_cliente": "DEV-BYPASS",
            "scadenza": "2099-12-31",
            "max_utenti": 9999,
            "piano": "developer",
            "features": ["all"],
            "device_id": "",
            "signature_alg": "DEV-BYPASS",
            "developer_bypass": True,
        }, path
    path = license_file_path(base_dir)
    ok, payload = validate_license_file(path)
    return ok, payload, path
