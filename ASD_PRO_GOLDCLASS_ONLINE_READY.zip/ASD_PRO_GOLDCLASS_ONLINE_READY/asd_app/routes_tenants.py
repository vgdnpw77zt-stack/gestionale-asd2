# -*- coding: utf-8 -*-
"""Gestione semplice delle ASD locali (tenant).

È una funzione desktop locale: ogni ASD ha il proprio database, configurazione,
media e documenti. Non è un modulo SaaS e non apre servizi online.
"""
from __future__ import annotations

import io
import json
import shutil
import tempfile
import zipfile
from pathlib import Path

from .core import *


def _safe_member(name: str) -> str:
    p = Path(str(name).replace("\\", "/"))
    if p.is_absolute() or ".." in p.parts:
        raise ValueError("Archivio ASD non valido: percorso non ammesso.")
    return str(p).lstrip("./")


def _zip_tenant(slug: str) -> bytes:
    root = get_tenant_root(slug)
    if not root.exists():
        raise ValueError("ASD non trovata.")
    static_root = DATA_DIR / "user_static" / get_tenant_static_prefix(slug)
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for path in root.rglob("*"):
            if path.is_file():
                z.write(path, Path("tenants") / slug / path.relative_to(root))
        if static_root.exists():
            for path in static_root.rglob("*"):
                if path.is_file():
                    z.write(path, Path("user_static") / get_tenant_static_prefix(slug) / path.relative_to(static_root))
        info = get_tenant_by_code_or_slug(slug) or {"slug": slug, "name": slug.replace("-", " ").title()}
        z.writestr("tenant.json", json.dumps(info, ensure_ascii=False, indent=2))
    return out.getvalue()


@app.route("/tenants", methods=["GET", "POST"])
@login_required
def tenants_admin():
    if not is_admin():
        return layout(alert_html("Accesso riservato all'amministratore.", "error")), 403

    if request.method == "POST":
        action = (request.form.get("action") or "").strip()
        if action == "create":
            name = require_non_empty(request.form.get("name", ""), "Nome ASD", 120)
            code = truncate((request.form.get("code") or "").strip().upper(), 32) or slugify_tenant(name).upper()
            slug = slugify_tenant(request.form.get("slug") or name)
            if get_tenant_by_code_or_slug(slug) or get_tenant_by_code_or_slug(code):
                return redirect_with_message("/tenants", "Esiste già una ASD con questo nome/codice.", "warning")
            ensure_workspace_dirs(slug)
            init_db_for_path(get_workspace_db_path(slug), slug)
            cfg = {"nome_asd": name, "firma": "", "setup_completed": "1", "documenti": {"denominazione": name}}
            get_workspace_config_path(slug).write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
            items = load_tenants_registry()
            items.append({"slug": slug, "name": name, "code": code, "active": 1, "created_at": now_iso_dt()})
            save_tenants_registry(items)
            return redirect_with_message("/tenants", f"ASD '{name}' creata correttamente.", "success")

        if action == "switch":
            slug = slugify_tenant(request.form.get("slug", ""), "")
            item = get_tenant_by_code_or_slug(slug)
            if not item or int(item.get("active", 1) or 0) != 1:
                return redirect_with_message("/tenants", "ASD non disponibile.", "error")
            set_current_tenant(slug)
            return redirect_with_message("/", f"ASD attiva: {item.get('name') or slug}.", "success")

        if action == "toggle":
            slug = slugify_tenant(request.form.get("slug", ""), "")
            items = load_tenants_registry()
            for item in items:
                if item.get("slug") == slug:
                    item["active"] = 0 if int(item.get("active", 1) or 0) else 1
                    break
            save_tenants_registry(items)
            return redirect_with_message("/tenants", "Stato ASD aggiornato.", "success")

        if action == "export":
            slug = slugify_tenant(request.form.get("slug", ""), "")
            try:
                data = _zip_tenant(slug)
            except ValueError as exc:
                return redirect_with_message("/tenants", str(exc), "error")
            return send_file(io.BytesIO(data), as_attachment=True, download_name=f"ASD_{slug}.zip", mimetype="application/zip")

        if action == "import":
            upload = request.files.get("tenant_zip")
            if not upload or not upload.filename:
                return redirect_with_message("/tenants", "Seleziona un archivio ASD (.zip).", "error")
            try:
                with tempfile.TemporaryDirectory(prefix="asd_tenant_import_") as tmp:
                    tmp_path = Path(tmp) / "archive.zip"
                    upload.save(tmp_path)
                    with zipfile.ZipFile(tmp_path) as z:
                        members = [_safe_member(x) for x in z.namelist()]
                        z.extractall(Path(tmp) / "extract", members)
                    root = Path(tmp) / "extract"
                    candidates = [p.parent for p in (root / "tenants").glob("*/asd.db")] if (root / "tenants").exists() else []
                    if not candidates:
                        raise ValueError("Nell'archivio non è presente un tenant valido con database.")
                    src = candidates[0]
                    slug = slugify_tenant(request.form.get("slug") or src.name)
                    if get_tenant_by_code_or_slug(slug):
                        raise ValueError("Esiste già una ASD con questo codice/nome.")
                    dest = get_tenant_root(slug)
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copytree(src, dest)
                    static_src = root / "user_static" / "tenants" / src.name
                    if static_src.exists():
                        shutil.copytree(static_src, DATA_DIR / "user_static" / "tenants" / slug, dirs_exist_ok=True)
                    init_db_for_path(dest / "asd.db", slug)
                    meta = {}
                    meta_path = root / "tenant.json"
                    if meta_path.exists():
                        try: meta = json.loads(meta_path.read_text(encoding="utf-8"))
                        except Exception: meta = {}
                    items = load_tenants_registry()
                    items.append({"slug": slug, "name": str(meta.get("name") or slug.replace("-", " ").title()), "code": str(meta.get("code") or slug.upper()), "active": 1, "created_at": now_iso_dt()})
                    save_tenants_registry(items)
                return redirect_with_message("/tenants", f"ASD '{slug}' importata correttamente.", "success")
            except (zipfile.BadZipFile, OSError, ValueError) as exc:
                return redirect_with_message("/tenants", f"Importazione non riuscita: {exc}", "error")

        return redirect_with_message("/tenants", "Operazione non riconosciuta.", "error")

    items = load_tenants_registry()
    current = current_tenant_slug()
    rows = ""
    for item in items:
        slug = e(item.get("slug")); name = e(item.get("name")); code = e(item.get("code"))
        active = int(item.get("active", 1) or 0)
        status = "Attiva" if active else "Disattivata"
        rows += f"""<tr><td><strong>{name}</strong><div class='small-muted'>{code} · {slug}</div></td>
        <td>{status}</td><td>{'In uso' if item.get('slug') == current else ''}</td><td><div class='actions'>
        <form method='post' class='inline-form'>{csrf_input()}<input type='hidden' name='action' value='switch'><input type='hidden' name='slug' value='{slug}'><button class='cta-primary'>Usa</button></form>
        <form method='post' class='inline-form'>{csrf_input()}<input type='hidden' name='action' value='toggle'><input type='hidden' name='slug' value='{slug}'><button class='cta-secondary'>{'Disattiva' if active else 'Attiva'}</button></form>
        <form method='post' class='inline-form'>{csrf_input()}<input type='hidden' name='action' value='export'><input type='hidden' name='slug' value='{slug}'><button class='cta-secondary'>Esporta</button></form>
        </div></td></tr>"""
    return layout(f"""
    <div class='app-section-hero'><div><div class='kicker'>Amministrazione</div><h2 class='section-title'>Gestione ASD</h2><div class='small-muted'>Ogni ASD locale mantiene separati database, documenti, media e impostazioni.</div></div><a class='pro-cta strong' href='/'>Dashboard</a></div>
    <div class='grid-2'>
      <section class='card'><div class='kicker'>Nuova ASD</div><h3 class='section-title'>Crea workspace</h3><form method='post' class='form-row'>{csrf_input()}<input type='hidden' name='action' value='create'><input name='name' placeholder='Nome ASD' required><input name='code' placeholder='Codice ASD'><input name='slug' placeholder='Identificativo locale'><button class='cta-primary'>Crea ASD</button></form></section>
      <section class='card'><div class='kicker'>Importazione</div><h3 class='section-title'>Importa una ASD</h3><form method='post' enctype='multipart/form-data' class='form-row'>{csrf_input()}<input type='hidden' name='action' value='import'><input type='file' name='tenant_zip' accept='.zip' required><input name='slug' placeholder='Nuovo identificativo (facoltativo)'><button class='cta-primary'>Importa</button></form><div class='form-hint'>Puoi importare un archivio ASD esportato dal gestionale o un backup che contenga un tenant.</div></section>
    </div>
    <div class='card'><div class='kicker'>Workspace locali</div><table><tr><th>ASD</th><th>Stato</th><th></th><th>Azioni</th></tr>{rows or "<tr><td colspan='4'>Nessuna ASD configurata.</td></tr>"}</table></div>
    """)
