from .core import *

@app.route("/settings", methods=["GET", "POST"])
@admin_required
def settings():
   cfg = load_config()
   STATIC_DIR.mkdir(parents=True, exist_ok=True)
   get_template_library_dir()

   if request.method == "POST":
       cfg["nome_asd"] = truncate(request.form.get("nome_asd", "").strip(), 120) or cfg["nome_asd"]
       cfg["firma"] = truncate(request.form.get("firma", "").strip(), 120)
       cfg["iban"] = truncate(request.form.get("iban", "").strip(), 80)

       branding = cfg.get("branding", {})
       branding["app_name"] = truncate(request.form.get("branding_app_name", "").strip() or "Asd Pro System", 120)
       branding["suite_label"] = truncate(request.form.get("branding_suite_label", "").strip() or "ASD Pro Manager", 120)
       branding["login_title"] = truncate(request.form.get("branding_login_title", "").strip() or "Accesso area riservata", 120)
       branding["login_subtitle"] = truncate(request.form.get("branding_login_subtitle", "").strip(), 260)
       cfg["branding"] = branding

       fatt = cfg.get("fatturapa", {})
       fatt["cedente_nome"] = truncate(request.form.get("cedente_nome", "").strip(), 120)
       fatt["cedente_piva"] = truncate(request.form.get("cedente_piva", "").strip(), 32)
       fatt["cedente_cf"] = truncate(request.form.get("cedente_cf", "").strip(), 32)
       fatt["regime_fiscale"] = truncate(request.form.get("regime_fiscale", "").strip() or "RF01", 8)
       fatt["cedente_indirizzo"] = truncate(request.form.get("cedente_indirizzo", "").strip(), 120)
       fatt["cedente_cap"] = truncate(request.form.get("cedente_cap", "").strip(), 12)
       fatt["cedente_comune"] = truncate(request.form.get("cedente_comune", "").strip(), 80)
       fatt["cedente_provincia"] = truncate(request.form.get("cedente_provincia", "").strip().upper(), 8)
       fatt["cedente_nazione"] = truncate(request.form.get("cedente_nazione", "").strip().upper() or "IT", 4)
       fatt["cedente_pec"] = normalize_email(request.form.get("cedente_pec", ""), 140)
       fatt["cedente_telefono"] = truncate(request.form.get("cedente_telefono", "").strip(), 32)
       fatt["codice_destinatario_default"] = truncate(request.form.get("codice_destinatario_default", "").strip() or "0000000", 16)
       fatt["iva_default"] = "{:.2f}".format(parse_float(request.form.get("iva_default", "0"), 0))
       fatt["natura_default"] = truncate(request.form.get("natura_default", "").strip() or "N2.2", 8)
       fatt["esigibilita_iva"] = truncate(request.form.get("esigibilita_iva", "").strip() or "I", 2)
       cfg["fatturapa"] = fatt

       doc = cfg.get("documenti", {})
       doc["denominazione"] = truncate(request.form.get("doc_denominazione", "").strip(), 140)
       doc["cf"] = truncate(request.form.get("doc_cf", "").strip().upper(), 32)
       doc["piva"] = truncate(request.form.get("doc_piva", "").strip(), 32)
       doc["sede_indirizzo"] = truncate(request.form.get("doc_sede_indirizzo", "").strip(), 160)
       doc["sede_cap"] = truncate(request.form.get("doc_sede_cap", "").strip(), 12)
       doc["sede_comune"] = truncate(request.form.get("doc_sede_comune", "").strip(), 80)
       doc["sede_provincia"] = truncate(request.form.get("doc_sede_provincia", "").strip().upper(), 8)
       doc["telefono"] = truncate(request.form.get("doc_telefono", "").strip(), 32)
       doc["email"] = normalize_email(request.form.get("doc_email", ""), 140)
       doc["pec"] = normalize_email(request.form.get("doc_pec", ""), 140)
       doc["affiliazione"] = truncate(request.form.get("doc_affiliazione", "").strip(), 120)
       doc["numero_affiliazione"] = truncate(request.form.get("doc_numero_affiliazione", "").strip(), 80)
       doc["presidente"] = truncate(request.form.get("doc_presidente", "").strip(), 120)
       doc["referente_privacy"] = truncate(request.form.get("doc_referente_privacy", "").strip(), 120)
       doc["luogo_firma"] = truncate(request.form.get("doc_luogo_firma", "").strip(), 120)
       doc["foro_competente"] = truncate(request.form.get("doc_foro_competente", "").strip(), 120)
       doc["iban"] = truncate(request.form.get("doc_iban", "").strip(), 80)
       doc["sito_web"] = truncate(request.form.get("doc_sito_web", "").strip(), 160)
       doc["note_legali"] = truncate(request.form.get("doc_note_legali", "").strip(), 600)
       cfg["documenti"] = doc

       cfg["mail"] = {"enabled": "1" if request.form.get("mail_enabled") == "1" else "0"}
       cfg["whatsapp"] = {"enabled": "1" if request.form.get("wa_enabled") == "1" else "0", "template_reminder": truncate(request.form.get("wa_template", "").strip() or "Ciao {nome}, ti ricordiamo la quota {periodo} per {asd}. Importo: € {importo}.", 1000), "template_confirmed": "Ciao {nome}, abbiamo registrato il pagamento di € {importo}. Grazie."}

       logo = request.files.get("logo")
       if logo and logo.filename:
           try:
               old_logo = cfg.get("logo", "")
               cfg["logo"] = save_uploaded_image(logo, "logo")
               if old_logo and old_logo != cfg["logo"]:
                   delete_uploaded_image(old_logo)
           except ValueError as exc:
               return layout(alert_html(str(exc), "error"))

       background = request.files.get("background")
       if background and background.filename:
           try:
               old_bg = cfg.get("background", "")
               cfg["background"] = save_uploaded_image(background, "background")
               if old_bg and old_bg != cfg["background"]:
                   delete_uploaded_image(old_bg)
           except ValueError as exc:
               return layout(alert_html(str(exc), "error"))

       permissions = cfg.get("permissions", {}) if isinstance(cfg.get("permissions"), dict) else {}
       for role in ROLE_LEVELS:
           role_bucket = permissions.get(role, {}) if isinstance(permissions.get(role), dict) else {}
           for section in SECTION_LABELS:
               field_name = f"perm__{role}__{section}"
               role_bucket[section] = True if request.form.get(field_name) == "1" else False
           if role == "admin":
               for section in SECTION_LABELS:
                   role_bucket[section] = True
           permissions[role] = role_bucket
       cfg["permissions"] = permissions
       cfg["setup_completed"] = "1"

       save_config(cfg)
       return redirect_with_message("/settings", "Impostazioni salvate correttamente.", "success")

   fatt = cfg.get("fatturapa", {})
   doc = cfg.get("documenti", {})
   mail = cfg.get("mail", {})
   branding = cfg.get("branding", {})
   logo_preview = f"<img src='{file_url(cfg['logo'])}' style='max-width:220px;border-radius:14px;border:1px solid rgba(255,255,255,.12);'>" if cfg.get("logo") else ""
   bg_preview = f"<img src='{file_url(cfg['background'])}' style='max-width:220px;border-radius:14px;border:1px solid rgba(255,255,255,.12);'>" if cfg.get("background") else ""
   library_files = list_template_library_files()
   library_html = "".join(f"<li>{e(item['label'])} <span class='small-muted'>({e(item['filename'])})</span></li>" for item in library_files) or "<li class='small-muted'>Nessun modello presente in media/modelli_asd.</li>"
   permission_rows = []
   permissions_cfg = cfg.get("permissions", {}) if isinstance(cfg.get("permissions"), dict) else {}
   permission_header = "".join(f"<th>{e(role_label(role))}</th>" for role in ROLE_LEVELS)
   for section, section_label in SECTION_LABELS.items():
       cells = []
       for role in ROLE_LEVELS:
           role_bucket = permissions_cfg.get(role, {}) if isinstance(permissions_cfg.get(role), dict) else {}
           checked = "checked" if bool(role_bucket.get(section, DEFAULT_ROLE_SECTION_PERMISSIONS.get(role, {}).get(section, False))) else ""
           disabled = "disabled" if role == "admin" else ""
           hidden = "" if role != "admin" else f"<input type='hidden' name='perm__{role}__{section}' value='1'>"
           cells.append(f"<td style='text-align:center;'><label><input type='checkbox' name='perm__{role}__{section}' value='1' {checked} {disabled}></label>{hidden}</td>")
       permission_rows.append(f"<tr><td><b>{e(section_label)}</b></td>{''.join(cells)}</tr>")
   permission_matrix_html = f"<div class='settings-permissions-table'><table><tr><th>Sezione</th>{permission_header}</tr>{''.join(permission_rows)}</table></div>"

   return layout(f"""
   <div class="card">
       <div class="page-head">
           <div>
               <div class="kicker">Dati ASD, documenti e comunicazioni</div>
               <h2 class="section-title">Impostazioni ASD</h2>
           </div>
       </div>
       <form method="POST" enctype="multipart/form-data" class="form-row settings-a4-form">
           {csrf_input()}
           <input name="nome_asd" value="{e(cfg.get('nome_asd', ''))}" placeholder="Nome ASD / cliente">
           <input name="firma" value="{e(cfg.get('firma', ''))}" placeholder="Referente / firma">
           <input name="iban" value="{e(cfg.get('iban', ''))}" placeholder="IBAN generale">

           <div class="form-col"><label><b>Brand software white-label</b></label></div>
           <input name="branding_app_name" value="{e(branding.get('app_name', 'Asd Pro System'))}" placeholder="Nome app visibile">
           <input name="branding_suite_label" value="{e(branding.get('suite_label', 'ASD Pro Manager'))}" placeholder="Etichetta suite">
           <input name="branding_login_title" value="{e(branding.get('login_title', 'Accesso area riservata'))}" placeholder="Titolo schermata login">
           <input name="branding_login_subtitle" value="{e(branding.get('login_subtitle', ''))}" placeholder="Sottotitolo login / sidebar">

           <div class="form-col">
               <label><b>Logo</b></label>
               <input type="file" name="logo" accept=".png,.jpg,.jpeg,.webp,.gif">
               {logo_preview}
           </div>

           <div class="form-col">
               <label><b>Sfondo</b></label>
               <input type="file" name="background" accept=".png,.jpg,.jpeg,.webp,.gif">
               {bg_preview}
           </div>

           <hr>

           <div class="form-col"><label><b>Intestazione documenti / ricevute / PDF</b></label></div>
           <input name="doc_denominazione" value="{e(doc.get('denominazione', ''))}" placeholder="Denominazione per documenti e ricevute">
           <input name="doc_cf" value="{e(doc.get('cf', ''))}" placeholder="Codice fiscale ASD">
           <input name="doc_piva" value="{e(doc.get('piva', ''))}" placeholder="Partita IVA ASD">
           <input name="doc_sede_indirizzo" value="{e(doc.get('sede_indirizzo', ''))}" placeholder="Indirizzo sede">
           <input name="doc_sede_cap" value="{e(doc.get('sede_cap', ''))}" placeholder="CAP sede">
           <input name="doc_sede_comune" value="{e(doc.get('sede_comune', ''))}" placeholder="Comune sede">
           <input name="doc_sede_provincia" value="{e(doc.get('sede_provincia', ''))}" placeholder="Provincia sede">
           <input name="doc_telefono" value="{e(doc.get('telefono', ''))}" placeholder="Telefono ASD">
           <input name="doc_email" value="{e(doc.get('email', ''))}" placeholder="Email ASD">
           <input name="doc_pec" value="{e(doc.get('pec', ''))}" placeholder="PEC ASD">
           <input name="doc_affiliazione" value="{e(doc.get('affiliazione', ''))}" placeholder="Affiliazione / EPS / Ente">
           <input name="doc_numero_affiliazione" value="{e(doc.get('numero_affiliazione', ''))}" placeholder="Numero affiliazione">
           <input name="doc_presidente" value="{e(doc.get('presidente', ''))}" placeholder="Presidente / firmatario">
           <input name="doc_referente_privacy" value="{e(doc.get('referente_privacy', ''))}" placeholder="Referente privacy">
           <input name="doc_luogo_firma" value="{e(doc.get('luogo_firma', ''))}" placeholder="Luogo firma">
           <input name="doc_foro_competente" value="{e(doc.get('foro_competente', ''))}" placeholder="Foro competente">
           <input name="doc_iban" value="{e(doc.get('iban', ''))}" placeholder="IBAN documentale">
           <input name="doc_sito_web" value="{e(doc.get('sito_web', ''))}" placeholder="Sito web">
           <textarea name="doc_note_legali" placeholder="Note legali / privacy / clausole standard" rows="4" style="min-height:120px;">{e(doc.get('note_legali', ''))}</textarea>

           <hr>

           <div class="form-col"><label><b>Dati emittente FatturaPA</b></label></div>
           <input name="cedente_nome" value="{e(fatt.get('cedente_nome', ''))}" placeholder="Denominazione emittente">
           <input name="cedente_piva" value="{e(fatt.get('cedente_piva', ''))}" placeholder="Partita IVA emittente">
           <input name="cedente_cf" value="{e(fatt.get('cedente_cf', ''))}" placeholder="Codice fiscale emittente">
           <input name="regime_fiscale" value="{e(fatt.get('regime_fiscale', 'RF01'))}" placeholder="Regime fiscale">
           <input name="cedente_indirizzo" value="{e(fatt.get('cedente_indirizzo', ''))}" placeholder="Indirizzo">
           <input name="cedente_cap" value="{e(fatt.get('cedente_cap', ''))}" placeholder="CAP">
           <input name="cedente_comune" value="{e(fatt.get('cedente_comune', ''))}" placeholder="Comune">
           <input name="cedente_provincia" value="{e(fatt.get('cedente_provincia', ''))}" placeholder="Provincia">
           <input name="cedente_nazione" value="{e(fatt.get('cedente_nazione', 'IT'))}" placeholder="Nazione">
           <input name="cedente_pec" value="{e(fatt.get('cedente_pec', ''))}" placeholder="PEC emittente">
           <input name="cedente_telefono" value="{e(fatt.get('cedente_telefono', ''))}" placeholder="Telefono emittente">
           <input name="codice_destinatario_default" value="{e(fatt.get('codice_destinatario_default', '0000000'))}" placeholder="Codice destinatario default">
           <input name="iva_default" value="{e(fatt.get('iva_default', '0.00'))}" placeholder="Aliquota IVA default">
           <input name="natura_default" value="{e(fatt.get('natura_default', 'N2.2'))}" placeholder="Natura default">
           <input name="esigibilita_iva" value="{e(fatt.get('esigibilita_iva', 'I'))}" placeholder="Esigibilità IVA">

           <hr>

           <div class="form-col"><label><b>Comunicazioni</b></label></div>
           <div class="small-muted" style="grid-column:1/-1;">Il software usa le app del tuo Mac. Non servono SMTP, API o account da inserire nel gestionale.</div>
           <label><input type="checkbox" name="mail_enabled" value="1" {'checked' if str(mail.get('enabled','0'))=='1' else ''}> Abilita Email</label>
           <label><input type="checkbox" name="wa_enabled" value="1" {'checked' if str((cfg.get('whatsapp') or {}).get('enabled','1'))=='1' else ''}> Abilita WhatsApp</label>
           <textarea name="wa_template" rows="3" placeholder="Testo promemoria">{e((cfg.get('whatsapp') or {}).get('template_reminder','Ciao {nome}, ti ricordiamo la quota {periodo} per {asd}. Importo: € {importo}.'))}</textarea>

           <hr>

           <div class="settings-a4-wide settings-a4-bottom-grid">
               <section class="card soft settings-a4-panel models-card">
                   <div class="settings-a4-panel-head">
                       <div>
                           <div class="kicker">Modelli ASD disponibili</div>
                           <h3>Archivio modelli DOCX</h3>
                       </div>
                   </div>
                   <p class="small-muted">La libreria modelli viene letta dalla cartella <b>media/modelli_asd</b>. I modelli DOCX restano modificabili, ma la conformità legale finale va sempre verificata sul caso concreto.</p>
                   <ul class="settings-a4-model-list">{library_html}</ul>
               </section>

               <section class="card soft settings-a4-panel permissions-card">
                   <div class="settings-a4-panel-head">
                       <div>
                           <div class="kicker">Permessi granulari per sezione</div>
                           <h3>Matrice ruoli e sezioni</h3>
                       </div>
                   </div>
                   <p class="small-muted">Qui decidi quali ruoli possono aprire ogni area del software. L’admin resta sempre completo per sicurezza.</p>
                   {permission_matrix_html}
               </section>
           </div>

           <button>Salva impostazioni</button>
       </form>
   </div>
   """)


@app.route("/setup-wizard", methods=["GET", "POST"])
@admin_required
def setup_wizard():
   cfg=load_config(); doc=cfg.get("documenti",{}) if isinstance(cfg.get("documenti"),dict) else {}
   if request.method=="POST":
      cfg["nome_asd"]=truncate(request.form.get("nome_asd","").strip(),120) or "ASD"; cfg["firma"]=truncate(request.form.get("firma","").strip(),120)
      for key,limit in (("denominazione",140),("cf",32),("telefono",32),("presidente",120),("sede_indirizzo",160),("sede_comune",80),("sede_provincia",8)):
         doc[key]=truncate(request.form.get("doc_"+key,"").strip(),limit)
      doc["email"]=normalize_email(request.form.get("doc_email",""),140); cfg["documenti"]=doc
      cfg["mail"]={"enabled":"1" if request.form.get("mail_enabled")=="1" else "0"}
      cfg["whatsapp"]={"enabled":"1" if request.form.get("wa_enabled")=="1" else "0","template_reminder":truncate(request.form.get("wa_template","").strip() or "Ciao {nome}, ti ricordiamo la quota {periodo} per {asd}. Importo: € {importo}.",1000),"template_confirmed":"Ciao {nome}, abbiamo registrato il pagamento di € {importo}. Grazie."}
      cfg["setup_completed"]="1"; save_config(cfg); return redirect_with_message("/","Configurazione iniziale completata.","success")
   mail=cfg.get("mail",{}); wa=cfg.get("whatsapp",{})
   return layout(f"""<div class='card'><div class='page-head'><div><div class='kicker'>Prima apertura</div><h2 class='section-title'>Configura la tua ASD</h2><div class='small-muted'>Solo i dati necessari per iniziare.</div></div></div><form method='POST' class='form-row'>{csrf_input()}<input name='nome_asd' value='{e(cfg.get("nome_asd",""))}' placeholder='Nome ASD' required><input name='firma' value='{e(cfg.get("firma",""))}' placeholder='Referente / firma'><input name='doc_denominazione' value='{e(doc.get("denominazione",""))}' placeholder='Denominazione documenti'><input name='doc_cf' value='{e(doc.get("cf",""))}' placeholder='Codice fiscale'><input name='doc_telefono' value='{e(doc.get("telefono",""))}' placeholder='Telefono'><input name='doc_email' value='{e(doc.get("email",""))}' placeholder='Email ASD'><input name='doc_presidente' value='{e(doc.get("presidente",""))}' placeholder='Presidente'><input name='doc_sede_indirizzo' value='{e(doc.get("sede_indirizzo",""))}' placeholder='Indirizzo sede'><input name='doc_sede_comune' value='{e(doc.get("sede_comune",""))}' placeholder='Comune'><input name='doc_sede_provincia' value='{e(doc.get("sede_provincia",""))}' placeholder='Provincia'><hr style='grid-column:1/-1'><div class='form-col'><b>Comunicazioni</b></div><label><input type='checkbox' name='mail_enabled' value='1' {'checked' if str(mail.get('enabled','0'))=='1' else ''}> Email tramite Mail</label><label><input type='checkbox' name='wa_enabled' value='1' {'checked' if str(wa.get('enabled','1'))=='1' else ''}> WhatsApp tramite app del Mac</label><textarea name='wa_template' rows='3' placeholder='Testo promemoria'>{e(wa.get('template_reminder','Ciao {nome}, ti ricordiamo la quota {periodo} per {asd}. Importo: € {importo}.'))}</textarea><button class='cta-primary' style='grid-column:1/-1'>Salva e inizia</button></form></div>""")
