from __future__ import annotations

from io import BytesIO
from pathlib import Path
from datetime import datetime

from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader


def _template_path(base_dir: Path, name: str) -> Path:
    path = Path(base_dir) / "media" / "modelli_asd" / name
    if not path.exists():
        raise FileNotFoundError(f"Modello PDF non trovato: {name}")
    return path


def _fill(reader: PdfReader, values: dict[str, str], checks: set[str]) -> bytes:
    writer = PdfWriter()
    writer.clone_document_from_reader(reader)
    page = writer.pages[0]
    field_values = {k: str(v or "") for k, v in values.items()}
    for key in checks:
        field_values[key] = "/Yes"
    writer.update_page_form_field_values(page, field_values, auto_regenerate=True)
    out = BytesIO()
    writer.write(out)
    return out.getvalue()


def build_iscrizione_pdf(base_dir: Path, data: dict) -> bytes:
    reader = PdfReader(_template_path(base_dir, "modello_iscrizione_csen_80308.pdf"))
    values = {
        "nome": data.get("nome_cognome", ""),
        "cf": data.get("codice_fiscale", ""),
        "nato_a": data.get("luogo_nascita", ""),
        "nato_il": data.get("data_nascita", ""),
        "residente": data.get("residenza", ""),
        "email": data.get("email", ""),
        "tel": data.get("telefono", ""),
        "disc": data.get("disciplina", "Danza Acrobatica Aerea 2026/27 - CSEN 80308"),
        "sottoscritto": data.get("nome_cognome", ""),
        "tutore_di": data.get("nome_cognome", "") if data.get("is_minor") else "",
        "tutore": data.get("genitore", "") if data.get("is_minor") else "",
        "cf_tutore": data.get("cf_tutore", ""),
        "tel_tutore": data.get("telefono_genitore", ""),
        "mail_tutore": data.get("email_genitore", ""),
        "luogo": data.get("luogo_firma", ""),
    }
    # The form is deliberately left ready for signature. Consent/photo choices
    # are never guessed from database data.
    checks = {"chk_reg"}
    if data.get("consenso_firmato"):
        checks.add("cons1")
    return _fill(reader, values, checks)


def _receipt_overlay() -> bytes:
    out = BytesIO()
    c = canvas.Canvas(out, pagesize=A4)
    w, h = A4
    # The supplied template contained a reference to L.398/91, which does not
    # match this ASD's configured fiscal position. Replace only that fiscal
    # paragraph while preserving the user's visual template.
    c.setFillColorRGB(1, 1, 1)
    c.rect(34, h - 410, 527, 68, fill=1, stroke=0)
    c.setFillColorRGB(0, 0, 0)
    c.setFont("Helvetica-Bold", 7.5)
    c.drawString(40, h - 352, "VALIDITÀ DOCUMENTALE")
    c.setFont("Helvetica", 6.5)
    lines = [
        "• Ricevuta / quietanza relativa alla quota o al contributo indicato nel documento.",
        "• Il trattamento fiscale applicabile dipende dalla natura dell’entrata e dal regime fiscale dell’ASD.",
        "• Il presente documento non costituisce fattura elettronica.",
    ]
    y = h - 364
    for line in lines:
        c.drawString(40, y, line)
        y -= 9
    c.save()
    return out.getvalue()


def _tenant_brand_overlay(data: dict) -> bytes:
    """Sovrappone intestazione/firma dinamiche quando il modello base è tenant-specifico."""
    out = BytesIO()
    c = canvas.Canvas(out, pagesize=A4)
    w, h = A4
    name = str(data.get("tenant_name") or "").strip()
    if not name:
        c.save(); return out.getvalue()
    c.setFillColorRGB(1, 1, 1)
    c.roundRect(30, h-92, w-60, 78, 12, fill=1, stroke=0)
    logo_path = str(data.get("tenant_logo") or "").strip()
    if logo_path and Path(logo_path).exists():
        try:
            c.drawImage(ImageReader(logo_path), 42, h-78, width=55, height=55, preserveAspectRatio=True, mask="auto")
        except Exception:
            pass
    c.setFillColorRGB(0.10, 0.30, 0.36)
    c.setFont("Helvetica-Bold", 15)
    c.drawString(112, h-42, name[:65])
    c.setFillColorRGB(0.15, 0.15, 0.15)
    c.setFont("Helvetica", 8.5)
    details=[]
    if data.get("tenant_address"): details.append(str(data["tenant_address"]))
    if data.get("tenant_cf"): details.append(f"C.F. {data['tenant_cf']}")
    if data.get("tenant_affiliation"): details.append(str(data["tenant_affiliation"]))
    c.drawString(112, h-58, "  •  ".join(details)[:110])
    # Copre solo le righe fiscali/stampistiche hard-coded del modello e le rende tenant-neutral.
    c.setFillColorRGB(1,1,1); c.rect(30, 20, w-60, 150, fill=1, stroke=0)
    c.setFillColorRGB(0.10,0.10,0.10); c.setFont("Helvetica-Bold",9)
    c.drawString(42, 135, "Per ricevuta (firma socio / tutore)")
    c.drawString(325, 135, "Per l'ASD - Presidente / Legale rappresentante")
    c.setFont("Helvetica",8)
    c.drawString(42, 118, "Firma: ________________________________")
    c.drawString(325, 118, "Firma: ________________________________")
    c.drawString(42, 96, f"{name[:75]}")
    c.drawString(325, 96, str(data.get("tenant_representative") or "").strip()[:55])
    c.save()
    return out.getvalue()


def build_ricevuta_pdf(base_dir: Path, data: dict) -> bytes:
    reader = PdfReader(_template_path(base_dir, "modello_ricevuta_bodymind.pdf"))
    writer = PdfWriter()
    writer.clone_document_from_reader(reader)
    page = writer.pages[0]

    overlay = PdfReader(BytesIO(_receipt_overlay())).pages[0]
    page.merge_page(overlay)
    if data.get("tenant_name"):
        brand_overlay = PdfReader(BytesIO(_tenant_brand_overlay(data))).pages[0]
        page.merge_page(brand_overlay)

    causale = (data.get("causale") or "").lower()
    checks = set()
    if "iscrizione" in causale or "tesseramento" in causale:
        checks.add("chk_iscriz")
    elif "mensile" in causale:
        checks.add("chk_mensile")
    elif "corso" in causale or "danza" in causale:
        checks.add("chk_corso")
    elif "quota associativa" in causale or "annuale" in causale:
        checks.add("chk_quota_annuale")
    else:
        checks.add("chk_altro")

    method = (data.get("metodo_pagamento") or "").lower()
    if method == "contanti":
        checks.add("pay_contanti")
    elif method == "bonifico":
        checks.add("pay_bonifico")
    else:
        checks.add("pay_altro")

    values = {
        "num_ricevuta": data.get("numero", ""),
        "data": data.get("data", datetime.now().strftime("%d/%m/%Y")),
        "importo": data.get("importo", ""),
        "ricevuto_da": data.get("ricevuto_da", ""),
        "cf_pagante": data.get("cf_pagante", ""),
        "per_conto_minore": data.get("per_conto_minore", ""),
        "mod_pag_dett": data.get("metodo_dettaglio", ""),
    }
    writer.update_page_form_field_values(page, values | {k: "/Yes" for k in checks}, auto_regenerate=True)
    out = BytesIO()
    writer.write(out)
    return out.getvalue()
