from .core import *

# Permessi: unica fonte dati = config.json del tenant.
# Il vecchio user_permissions.json era una seconda configurazione non usata
# dal motore di autorizzazione e poteva quindi dare all'utente una falsa
# impressione di aver modificato i permessi.

@app.route("/utenti-permessi", methods=["GET", "POST"])
@admin_required
def utenti_permessi():
    cfg = load_config()
    permissions = cfg.get("permissions", {}) if isinstance(cfg.get("permissions"), dict) else {}

    if request.method == "POST":
        new_permissions = {}
        for role in ROLE_LEVELS:
            bucket = {}
            for section in SECTION_LABELS:
                bucket[section] = request.form.get(f"perm__{role}__{section}") == "1"
            if role == "admin":
                bucket = {section: True for section in SECTION_LABELS}
            new_permissions[role] = bucket
        cfg["permissions"] = new_permissions
        save_config(cfg)
        return redirect_with_message("/utenti-permessi", "Permessi aggiornati correttamente.", "success")

    cards = []
    for role in ROLE_LEVELS:
        role_permissions = permissions.get(role, {}) if isinstance(permissions.get(role), dict) else {}
        defaults = DEFAULT_ROLE_SECTION_PERMISSIONS.get(role, {})
        checks = []
        for section, label in SECTION_LABELS.items():
            checked = bool(role_permissions.get(section, defaults.get(section, False)))
            disabled = role == "admin"
            checks.append(
                f"<label style='display:flex;gap:8px;align-items:center;margin:6px 0;'>"
                f"<input type='checkbox' name='perm__{e(role)}__{e(section)}' value='1' {'checked' if checked else ''} {'disabled' if disabled else ''}> {e(label)}</label>"
            )
            if disabled:
                checks.append(f"<input type='hidden' name='perm__{e(role)}__{e(section)}' value='1'>")
        cards.append(f"<div class='perm-card'><h3>{e(role_label(role))}</h3>{''.join(checks)}</div>")

    return layout(f"""
    <div class='app-section-hero'>
      <div>
        <div class='kicker'>Utenti e sicurezza</div>
        <h2 class='section-title'>Ruoli e permessi</h2>
        <div class='small-muted'>Unica configurazione dei permessi del gestionale. Le modifiche vengono applicate subito agli accessi.</div>
      </div>
      <div class='page-actions'>
        <a href='/utenti' class='nav-link' style='display:inline-flex;padding:10px 14px;width:auto;'>Utenti</a>
      </div>
    </div>
    <form method='POST' class='card'>
      {csrf_input()}
      <div class='perm-grid'>{''.join(cards)}</div>
      <div class='actions' style='margin-top:16px;'><button>Salva permessi</button></div>
    </form>
    """)


@app.route("/ruoli-permessi")
@login_required
def ruoli_permessi_redirect():
    return redirect("/utenti-permessi")
