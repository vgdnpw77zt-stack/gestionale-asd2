from __future__ import annotations

import csv
import io
from typing import Iterable

from flask import request, send_file

from .core import *


TESSERATI_FIELDS = [
    ("nome", "Nome *"),
    ("cognome", "Cognome *"),
    ("telefono", "Telefono"),
    ("email", "Email"),
    ("corso", "Corso"),
    ("luogo_nascita", "Luogo nascita"),
    ("data_nascita", "Data nascita (GG/MM/AAAA)"),
    ("codice_fiscale", "Codice fiscale"),
    ("residenza", "Residenza"),
    ("documento_identita", "Documento identità"),
    ("certificato_scadenza", "Certificato scadenza (GG/MM/AAAA)"),
]

MINORI_FIELDS = [
    ("nome", "Nome *"),
    ("cognome", "Cognome *"),
    ("genitore", "Genitore / esercente responsabilità *"),
    ("telefono_genitore", "Telefono genitore"),
    ("email_genitore", "Email genitore"),
    ("consenso_firmato", "Consenso firmato (si/no)"),
    ("data_consenso", "Data consenso (GG/MM/AAAA)"),
    ("note_consenso", "Note consenso"),
]

HEADER_ALIASES = {
    "nome": {"nome", "first_name", "name"},
    "cognome": {"cognome", "surname", "last_name", "lastname"},
    "telefono": {"telefono", "telefono_atleta", "cellulare", "phone", "tel"},
    "email": {"email", "mail", "email_atleta"},
    "corso": {"corso", "disciplina", "classe", "livello", "gruppo"},
    "luogo_nascita": {"luogo_nascita", "luogo di nascita", "comune_nascita", "birth_place"},
    "data_nascita": {"data_nascita", "data di nascita", "birth_date", "dob"},
    "codice_fiscale": {"codice_fiscale", "cf", "c.f.", "cod fiscale"},
    "residenza": {"residenza", "indirizzo", "address"},
    "documento_identita": {"documento_identita", "documento", "id_document", "doc_identita"},
    "certificato_scadenza": {"certificato_scadenza", "certificato", "scadenza_certificato", "medical_expiry"},
    "genitore": {"genitore", "tutore", "responsabile", "parent", "guardian"},
    "telefono_genitore": {"telefono_genitore", "telefono genitore", "tel_genitore", "parent_phone"},
    "email_genitore": {"email_genitore", "email genitore", "mail_genitore", "parent_email"},
    "consenso_firmato": {"consenso_firmato", "consenso", "consenso privacy", "signed_consent"},
    "data_consenso": {"data_consenso", "data consenso", "consent_date"},
    "note_consenso": {"note_consenso", "note consenso", "note", "consent_note"},
}

BOOL_TRUE = {"1", "true", "vero", "si", "sì", "yes", "y", "ok", "x"}
BOOL_FALSE = {"0", "false", "falso", "no", "n"}
IMPORT_CACHE_KEY = "_csv_import_preview"


def _slug_header(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", (value or "").strip().lower()).strip("_")


def _normalize_bool(value: str) -> int:
    probe = (value or "").strip().lower()
    if not probe:
        return 0
    if probe in BOOL_TRUE:
        return 1
    if probe in BOOL_FALSE:
        return 0
    return 0


def _read_csv_rows(file_storage) -> tuple[list[str], list[dict]]:
    raw = file_storage.read()
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("latin-1")
    finally:
        try:
            file_storage.stream.seek(0)
        except Exception:
            pass

    if not text.strip():
        raise ValueError("Il file CSV è vuoto.")

    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except Exception:
        dialect = csv.excel
        dialect.delimiter = ";" if sample.count(";") > sample.count(",") else ","

    reader = csv.DictReader(io.StringIO(text), dialect=dialect)
    if not reader.fieldnames:
        raise ValueError("Intestazioni CSV mancanti o non leggibili.")

    headers = [str(h or "").strip() for h in reader.fieldnames]
    rows: list[dict] = []
    for raw_row in reader:
        if not raw_row:
            continue
        clean = {str(k or "").strip(): str(v or "").strip() for k, v in raw_row.items()}
        if not any(clean.values()):
            continue
        rows.append(clean)
    return headers, rows



def _resolve_field_map(headers: Iterable[str], dataset: str) -> dict[str, str | None]:
    normalized = {_slug_header(h): h for h in headers}
    target_fields = [key for key, _ in (TESSERATI_FIELDS if dataset == "tesserati" else MINORI_FIELDS)]
    mapping: dict[str, str | None] = {}
    for field in target_fields:
        mapping[field] = None
        aliases = HEADER_ALIASES.get(field, {field})
        for alias in aliases:
            probe = _slug_header(alias)
            if probe in normalized:
                mapping[field] = normalized[probe]
                break
    return mapping



def _value_from_row(row: dict, mapping: dict[str, str | None], field: str) -> str:
    source = mapping.get(field)
    if not source:
        return ""
    return str(row.get(source, "") or "").strip()



def _find_existing_tesserato(conn, payload: dict) -> sqlite3.Row | None:
    codice_fiscale = payload.get("codice_fiscale", "")
    if codice_fiscale:
        row = conn.execute("SELECT * FROM tesserati WHERE UPPER(COALESCE(codice_fiscale,''))=? LIMIT 1", (codice_fiscale.upper(),)).fetchone()
        if row:
            return row
    if payload.get("nome") and payload.get("cognome") and payload.get("data_nascita"):
        return conn.execute(
            "SELECT * FROM tesserati WHERE LOWER(nome)=LOWER(?) AND LOWER(cognome)=LOWER(?) AND COALESCE(data_nascita,'')=? LIMIT 1",
            (payload["nome"], payload["cognome"], payload["data_nascita"]),
        ).fetchone()
    return None



def _find_existing_minore(conn, payload: dict) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM minori WHERE LOWER(nome)=LOWER(?) AND LOWER(cognome)=LOWER(?) AND LOWER(genitore)=LOWER(?) LIMIT 1",
        (payload.get("nome", ""), payload.get("cognome", ""), payload.get("genitore", "")),
    ).fetchone()



def _validate_tesserato_row(row: dict, mapping: dict[str, str | None]) -> dict:
    nome = require_non_empty(_value_from_row(row, mapping, "nome"), "Nome")
    cognome = require_non_empty(_value_from_row(row, mapping, "cognome"), "Cognome")
    email = normalize_email(_value_from_row(row, mapping, "email"), 140) if _value_from_row(row, mapping, "email") else ""
    data_nascita_raw = _value_from_row(row, mapping, "data_nascita")
    data_nascita = parse_date_input(data_nascita_raw) if data_nascita_raw else ""
    if data_nascita_raw and not data_nascita:
        raise ValueError("Data nascita non valida")
    certificato_raw = _value_from_row(row, mapping, "certificato_scadenza")
    certificato = parse_date_input(certificato_raw) if certificato_raw else ""
    if certificato_raw and not certificato:
        raise ValueError("Certificato scadenza non valido")
    return {
        "nome": nome,
        "cognome": cognome,
        "telefono": truncate(_value_from_row(row, mapping, "telefono"), 40),
        "email": email,
        "corso": truncate(_value_from_row(row, mapping, "corso"), 120),
        "luogo_nascita": truncate(_value_from_row(row, mapping, "luogo_nascita"), 120),
        "data_nascita": data_nascita,
        "codice_fiscale": truncate(_value_from_row(row, mapping, "codice_fiscale").upper(), 32),
        "residenza": truncate(_value_from_row(row, mapping, "residenza"), 200),
        "documento_identita": truncate(_value_from_row(row, mapping, "documento_identita"), 160),
        "certificato_scadenza": certificato,
    }



def _validate_minore_row(row: dict, mapping: dict[str, str | None]) -> dict:
    nome = require_non_empty(_value_from_row(row, mapping, "nome"), "Nome")
    cognome = require_non_empty(_value_from_row(row, mapping, "cognome"), "Cognome")
    genitore = require_non_empty(_value_from_row(row, mapping, "genitore"), "Genitore", 140)
    email = normalize_email(_value_from_row(row, mapping, "email_genitore"), 140) if _value_from_row(row, mapping, "email_genitore") else ""
    data_consenso_raw = _value_from_row(row, mapping, "data_consenso")
    data_consenso = parse_date_input(data_consenso_raw) if data_consenso_raw else ""
    if data_consenso_raw and not data_consenso:
        raise ValueError("Data consenso non valida")
    consenso_firmato = _normalize_bool(_value_from_row(row, mapping, "consenso_firmato"))
    if consenso_firmato and not data_consenso:
        raise ValueError("Se il consenso è firmato serve anche la data consenso")
    return {
        "nome": nome,
        "cognome": cognome,
        "genitore": genitore,
        "telefono_genitore": truncate(_value_from_row(row, mapping, "telefono_genitore"), 40),
        "email_genitore": email,
        "consenso_firmato": consenso_firmato,
        "data_consenso": data_consenso,
        "note_consenso": truncate(_value_from_row(row, mapping, "note_consenso"), 400),
    }



def _build_preview(dataset: str, rows: list[dict], import_mode: str) -> dict:
    mapping = _resolve_field_map(rows[0].keys() if rows else [], dataset)
    required = ["nome", "cognome"] if dataset == "tesserati" else ["nome", "cognome", "genitore"]
    missing_required = [field for field in required if not mapping.get(field)]
    if missing_required:
        raise ValueError("Colonne obbligatorie mancanti nel CSV: " + ", ".join(missing_required))

    preview_rows = []
    stats = {"valid": 0, "errors": 0, "updates": 0, "creates": 0, "skips": 0}
    conn = db()
    try:
        for index, raw_row in enumerate(rows, start=2):
            try:
                payload = _validate_tesserato_row(raw_row, mapping) if dataset == "tesserati" else _validate_minore_row(raw_row, mapping)
                existing = _find_existing_tesserato(conn, payload) if dataset == "tesserati" else _find_existing_minore(conn, payload)
                action = "create"
                if existing:
                    action = "update" if import_mode == "update" else "skip"
                    if action == "update":
                        stats["updates"] += 1
                    else:
                        stats["skips"] += 1
                else:
                    stats["creates"] += 1
                stats["valid"] += 1
                preview_rows.append({
                    "row_number": index,
                    "status": "ok",
                    "action": action,
                    "summary": (payload.get("nome", "") + " " + payload.get("cognome", "")).strip(),
                    "details": payload,
                    "error": "",
                })
            except Exception as exc:
                stats["errors"] += 1
                preview_rows.append({
                    "row_number": index,
                    "status": "error",
                    "action": "error",
                    "summary": f"Riga {index}",
                    "details": {},
                    "error": str(exc),
                })
    finally:
        conn.close()

    return {
        "dataset": dataset,
        "mode": import_mode,
        "mapping": mapping,
        "stats": stats,
        "rows": preview_rows,
    }



def _execute_preview(preview: dict) -> dict:
    dataset = preview.get("dataset")
    import_mode = preview.get("mode")
    results = {"created": 0, "updated": 0, "skipped": 0, "errors": 0}
    conn = db()
    c = conn.cursor()
    try:
        for item in preview.get("rows", []):
            if item.get("status") != "ok":
                results["errors"] += 1
                continue
            payload = item.get("details") or {}
            try:
                if dataset == "tesserati":
                    existing = _find_existing_tesserato(conn, payload)
                    if existing and import_mode != "update":
                        results["skipped"] += 1
                        continue
                    if existing:
                        c.execute(
                            """
                            UPDATE tesserati SET nome=?, cognome=?, telefono=?, corso=?, certificato_scadenza=?,
                            luogo_nascita=?, data_nascita=?, codice_fiscale=?, residenza=?, email=?, documento_identita=?
                            WHERE id=?
                            """,
                            (
                                payload["nome"], payload["cognome"], payload["telefono"], payload["corso"], payload["certificato_scadenza"],
                                payload["luogo_nascita"], payload["data_nascita"], payload["codice_fiscale"], payload["residenza"], payload["email"], payload["documento_identita"],
                                existing["id"],
                            ),
                        )
                        results["updated"] += 1
                    else:
                        c.execute(
                            """
                            INSERT INTO tesserati(nome, cognome, telefono, corso, certificato_scadenza, luogo_nascita, data_nascita, codice_fiscale, residenza, email, documento_identita)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                payload["nome"], payload["cognome"], payload["telefono"], payload["corso"], payload["certificato_scadenza"],
                                payload["luogo_nascita"], payload["data_nascita"], payload["codice_fiscale"], payload["residenza"], payload["email"], payload["documento_identita"],
                            ),
                        )
                        results["created"] += 1
                else:
                    existing = _find_existing_minore(conn, payload)
                    if existing and import_mode != "update":
                        results["skipped"] += 1
                        continue
                    if existing:
                        c.execute(
                            """
                            UPDATE minori SET nome=?, cognome=?, genitore=?, telefono_genitore=?, email_genitore=?, consenso_firmato=?, data_consenso=?, note_consenso=?
                            WHERE id=?
                            """,
                            (
                                payload["nome"], payload["cognome"], payload["genitore"], payload["telefono_genitore"], payload["email_genitore"], payload["consenso_firmato"], payload["data_consenso"], payload["note_consenso"],
                                existing["id"],
                            ),
                        )
                        results["updated"] += 1
                    else:
                        c.execute(
                            """
                            INSERT INTO minori(nome, cognome, genitore, telefono_genitore, email_genitore, consenso_firmato, data_consenso, note_consenso)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                payload["nome"], payload["cognome"], payload["genitore"], payload["telefono_genitore"], payload["email_genitore"], payload["consenso_firmato"], payload["data_consenso"], payload["note_consenso"],
                            ),
                        )
                        results["created"] += 1
            except Exception:
                log_exception("Errore import CSV")
                results["errors"] += 1
        conn.commit()
    finally:
        conn.close()
    return results



def _preview_table(preview: dict | None) -> str:
    if not preview:
        return ""
    rows_html = []
    for item in preview.get("rows", [])[:25]:
        action_label = {
            "create": "Nuovo",
            "update": "Aggiorna",
            "skip": "Salta",
            "error": "Errore",
        }.get(item.get("action"), item.get("action"))
        badge_cls = "valido" if item.get("status") == "ok" else "scaduto"
        details = item.get("details") or {}
        detail_chunks = []
        for key, value in details.items():
            if value:
                detail_chunks.append(f"{e(key)}: {e(format_display_date(value) if 'data' in key or 'certificato' in key else value)}")
        rows_html.append(
            f"<tr><td>{item.get('row_number')}</td><td><strong>{e(item.get('summary') or '-')}</strong></td><td><span class='badge {badge_cls}'>{e(action_label)}</span></td><td>{'<br>'.join(detail_chunks) or '-'}</td><td>{e(item.get('error') or '-')}</td></tr>"
        )
    if len(preview.get("rows", [])) > 25:
        rows_html.append(f"<tr><td colspan='5'><div class='small-muted'>Anteprima limitata alle prime 25 righe su {len(preview.get('rows', []))} totali.</div></td></tr>")
    return "".join(rows_html)


@app.route("/admin/import-csv", methods=["GET", "POST"])
@admin_required
def admin_import_csv():
    preview = session.get(IMPORT_CACHE_KEY)
    if request.method == "POST":
        action = (request.form.get("action") or "preview").strip().lower()
        dataset = (request.form.get("dataset") or "tesserati").strip().lower()
        import_mode = (request.form.get("import_mode") or "skip").strip().lower()
        if dataset not in {"tesserati", "minori"}:
            dataset = "tesserati"
        if import_mode not in {"skip", "update"}:
            import_mode = "skip"

        if action == "download_template":
            fields = TESSERATI_FIELDS if dataset == "tesserati" else MINORI_FIELDS
            output = io.StringIO()
            writer = csv.writer(output, delimiter=';')
            writer.writerow([name for name, _label in fields])
            sample = {
                "tesserati": ["Giulia", "Rossi", "+393331112233", "giulia@example.com", "Cerchio aereo 1", "Roma", "14/05/2012", "RSSGLI12E54H501Z", "Via Roma 10", "CI AB123456", "31/12/2026"],
                "minori": ["Marta", "Bianchi", "Luca Bianchi", "+393339998877", "genitore@example.com", "si", "10/09/2025", "Consenso archiviato"],
            }
            writer.writerow(sample[dataset])
            data = io.BytesIO(output.getvalue().encode("utf-8-sig"))
            data.seek(0)
            return send_file(data, mimetype="text/csv; charset=utf-8", as_attachment=True, download_name=f"template_import_{dataset}.csv")

        if action == "confirm_import":
            if not preview:
                return redirect_with_message("/admin/import-csv", "Nessuna anteprima disponibile da confermare.", "warning")
            results = _execute_preview(preview)
            session.pop(IMPORT_CACHE_KEY, None)
            log_audit(
                "csv_import_confirm",
                details=f"dataset={preview.get('dataset')} created={results['created']} updated={results['updated']} skipped={results['skipped']} errors={results['errors']}",
                entity_type="import_csv",
                status="ok" if results["errors"] == 0 else "warning",
            )
            return redirect_with_message(
                "/admin/import-csv",
                f"Import completato. Creati: {results['created']} • Aggiornati: {results['updated']} • Saltati: {results['skipped']} • Errori: {results['errors']}",
                "success" if results["errors"] == 0 else "warning",
            )

        file_storage = request.files.get("csv_file")
        if not file_storage or not file_storage.filename:
            return redirect_with_message("/admin/import-csv", "Seleziona un file CSV da importare.", "error")
        if not file_storage.filename.lower().endswith(".csv"):
            return redirect_with_message("/admin/import-csv", "Carica un file con estensione .csv.", "error")
        try:
            headers, rows = _read_csv_rows(file_storage)
            preview = _build_preview(dataset, rows, import_mode)
            preview["headers"] = headers
            session[IMPORT_CACHE_KEY] = preview
            log_audit(
                "csv_import_preview",
                details=f"dataset={dataset} rows={len(rows)} valid={preview['stats']['valid']} errors={preview['stats']['errors']}",
                entity_type="import_csv",
                status="ok" if preview["stats"]["errors"] == 0 else "warning",
            )
            return redirect_with_message(
                "/admin/import-csv",
                f"Anteprima pronta. Righe valide: {preview['stats']['valid']} • errori: {preview['stats']['errors']}.",
                "success" if preview["stats"]["errors"] == 0 else "warning",
                dataset=dataset,
                import_mode=import_mode,
            )
        except Exception as exc:
            session.pop(IMPORT_CACHE_KEY, None)
            return redirect_with_message("/admin/import-csv", str(exc), "error", dataset=dataset, import_mode=import_mode)

    dataset = (request.args.get("dataset") or (preview or {}).get("dataset") or "tesserati").strip().lower()
    if dataset not in {"tesserati", "minori"}:
        dataset = "tesserati"
    import_mode = (request.args.get("import_mode") or (preview or {}).get("mode") or "skip").strip().lower()
    if import_mode not in {"skip", "update"}:
        import_mode = "skip"

    stats = (preview or {}).get("stats", {})
    selected_fields = TESSERATI_FIELDS if dataset == "tesserati" else MINORI_FIELDS
    field_list = "".join([f"<li><div><strong>{e(label)}</strong><div class='small-muted'>Chiave CSV consigliata: <code>{e(name)}</code></div></div><span class='pill'>Campo</span></li>" for name, label in selected_fields])

    confirm_box = ""
    if preview:
        confirm_box = f"""
        <div class='card'>
            <div class='table-toolbar'>
                <div>
                    <div class='kicker'>Anteprima import</div>
                    <h3 class='section-title' style='margin-bottom:4px;'>Controllo prima del salvataggio</h3>
                    <div class='small-muted'>Il sistema riconosce duplicati e ti mostra se ogni riga verrà creata, aggiornata o saltata.</div>
                </div>
                <form method='POST' class='inline-form'>
                    {csrf_input()}
                    <input type='hidden' name='action' value='confirm_import'>
                    <button>Conferma import</button>
                </form>
            </div>
            <div class='metric-strip'>
                <div class='metric-box'><div class='label'>Righe valide</div><div class='value'>{stats.get('valid', 0)}</div></div>
                <div class='metric-box'><div class='label'>Nuove</div><div class='value'>{stats.get('creates', 0)}</div></div>
                <div class='metric-box'><div class='label'>Aggiornabili</div><div class='value'>{stats.get('updates', 0)}</div></div>
                <div class='metric-box'><div class='label'>Da saltare</div><div class='value'>{stats.get('skips', 0)}</div></div>
                <div class='metric-box'><div class='label'>Errori</div><div class='value'>{stats.get('errors', 0)}</div></div>
            </div>
            <table>
                <tr><th>Riga</th><th>Record</th><th>Azione</th><th>Dati letti</th><th>Esito</th></tr>
                {_preview_table(preview)}
            </table>
        </div>
        """

    return layout(f"""
    <div class='app-section-hero'>
        <div class='kicker'>Admin import hub</div>
        <h2 class='section-title'>Import CSV tesserati e minori</h2>
        <div class='small-muted'>Pensato per desktop PC/Mac: import massivo, controllo qualità, deduplica e conferma finale in due passaggi. È pensato per lavorare direttamente sul database locale dell'ASD.</div>
    </div>
    <div class='grid-2'>
        <div class='card form-panel card-elevated'>
            <div class='kicker'>Carica CSV</div>
            <h3 class='section-title'>Importazione protetta</h3>
            <form method='POST' enctype='multipart/form-data' class='form-row'>
                {csrf_input()}
                <input type='hidden' name='action' value='preview'>
                <select name='dataset'>
                    <option value='tesserati' {'selected' if dataset == 'tesserati' else ''}>Tesserati / atleti</option>
                    <option value='minori' {'selected' if dataset == 'minori' else ''}>Minori</option>
                </select>
                <select name='import_mode'>
                    <option value='skip' {'selected' if import_mode == 'skip' else ''}>Salta i duplicati</option>
                    <option value='update' {'selected' if import_mode == 'update' else ''}>Aggiorna i duplicati</option>
                </select>
                <input type='file' name='csv_file' accept='.csv,text/csv' required>
                <button>Genera anteprima</button>
            </form>
            <form method='POST' class='inline-form' style='margin-top:12px;'>
                {csrf_input()}
                <input type='hidden' name='action' value='download_template'>
                <input type='hidden' name='dataset' value='{e(dataset)}'>
                <button type='submit'>Scarica template CSV</button>
            </form>
        </div>
        <div class='card'>
            <div class='kicker'>Schema colonne</div>
            <h3 class='section-title'>Campi supportati</h3>
            <ul class='clean-list'>{field_list}</ul>
        </div>
    </div>
    <div class='card'>
        <div class='table-toolbar'>
            <div>
                <div class='kicker'>Regole anti-errori</div>
                <h3 class='section-title' style='margin-bottom:4px;'>Come il sistema decide i duplicati</h3>
                <div class='small-muted'>Tesserati: prima per codice fiscale, altrimenti nome+cognome+data nascita. Minori: nome+cognome+genitore. Le date accettano GG/MM/AAAA, YYYY-MM-DD e varianti comuni.</div>
            </div>
        </div>
        <ul class='clean-list'>
            <li><div><strong>Passo 1: anteprima</strong><div class='small-muted'>Niente scritture immediate: prima controllo righe, campi, duplicati ed errori.</div></div><span class='pill'>Sicuro</span></li>
            <li><div><strong>Passo 2: conferma admin</strong><div class='small-muted'>Il salvataggio parte solo dopo conferma esplicita.</div></div><span class='pill'>Admin only</span></li>
        </ul>
    </div>
    {confirm_box}
    """)
