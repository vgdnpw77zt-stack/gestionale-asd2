
# -*- coding: utf-8 -*-
from __future__ import annotations

import html
import json
import os
import sys
import re
import secrets
import shutil
import sqlite3
import subprocess
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
from urllib.parse import quote, urlparse

from flask import Flask, redirect, request, send_file, session, url_for
from PIL import Image, UnidentifiedImageError
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
import unicodedata

from .license_manager import find_and_validate_license, license_file_path


# ==============================
# CONFIG
# ==============================

APP_DIR = Path(__file__).resolve().parent

# BASE_DIR = risorse dell'app. In PyInstaller usa sys._MEIPASS.
if getattr(sys, "frozen", False):
    BASE_DIR = Path(getattr(sys, "_MEIPASS", Path(sys.executable).resolve().parent))
else:
    BASE_DIR = APP_DIR.parent if (APP_DIR.parent / 'app.py').exists() else APP_DIR

STATIC_DIR = BASE_DIR / "static"
DEFAULT_TENANT_SLUG = os.environ.get("ASD_DEFAULT_TENANT", "default").strip().lower() or "default"

def _runtime_data_dir() -> Path:
    env_dir = os.environ.get("ASD_PRO_DATA_DIR", "").strip()
    if env_dir:
        data_dir = Path(env_dir).expanduser()
    elif getattr(sys, "frozen", False) or sys.platform == "darwin":
        data_dir = Path.home() / "Library" / "Application Support" / "ASD Pro Goldclass"
    else:
        data_dir = Path.home() / ".asd_pro_goldclass"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir


DATA_DIR = _runtime_data_dir()

def get_app_data_dir() -> Path:
   """Directory runtime locale dell'installazione Mac."""
   return DATA_DIR

def _copy_seed_file(src: Path, dest: Path) -> None:
    try:
        if src.exists() and not dest.exists():
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
    except Exception:
        pass

def _copy_seed_dir(src: Path, dest: Path) -> None:
    try:
        if src.exists():
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(src, dest, dirs_exist_ok=True)
    except Exception:
        pass

if DATA_DIR != BASE_DIR:
    _copy_seed_file(BASE_DIR / "config.json", DATA_DIR / "config.json")
    # Produzione: NON copiare DB/licenze/segreti/dati cliente dal bundle al runtime.
    # Il DMG/EXE deve partire vuoto e inizializzare i dati in Application Support / APPDATA.
    # _copy_seed_file(BASE_DIR / "asd.db", DATA_DIR / "asd.db")
    # _copy_seed_file(BASE_DIR / "license.json", DATA_DIR / "license.json")
    # _copy_seed_file(BASE_DIR / ".secret_key", DATA_DIR / ".secret_key")
    _copy_seed_dir(BASE_DIR / "media", DATA_DIR / "media")
    # A.2: non copiare dati demo/storici dal progetto: _copy_seed_dir(BASE_DIR / "tenants", DATA_DIR / "tenants")
    # A.2: non copiare dati demo/storici dal progetto: _copy_seed_dir(BASE_DIR / "pdf", DATA_DIR / "pdf")
    # A.2: non copiare dati demo/storici dal progetto: _copy_seed_dir(BASE_DIR / "backups", DATA_DIR / "backups")

DB_NAME = DATA_DIR / "asd.db"
CONFIG_FILE = DATA_DIR / "config.json"
PDF_DIR = DATA_DIR / "pdf"

def get_pdf_dir(kind: str = "") -> Path:
   path = PDF_DIR / kind if kind else PDF_DIR
   path.mkdir(parents=True, exist_ok=True)
   return path
BACKUP_DIR = DATA_DIR / "backups"
MEDIA_DIR = DATA_DIR / "media"
TEMPLATE_LIBRARY_DIR = MEDIA_DIR / "modelli_asd"
ASD_DOCUMENTS_DIR = MEDIA_DIR / "documenti_asd"
SECRET_FILE = DATA_DIR / ".secret_key"
LOG_DIR = DATA_DIR / "logs"
LOG_FILE = LOG_DIR / "app.log"
TENANTS_DIR = DATA_DIR / "tenants"
TENANTS_REGISTRY_FILE = TENANTS_DIR / "tenants.json"


ALLOWED_IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "webp", "gif"}
ALLOWED_IMAGE_FORMATS = {"PNG", "JPEG", "WEBP", "GIF"}
ALLOWED_DOCUMENT_EXTENSIONS = {"pdf", "png", "jpg", "jpeg", "webp", "gif", "doc", "docx", "xls", "xlsx", "txt"}
PREVIEW_MIME_TYPES = {
   ".pdf": "application/pdf",
   ".png": "image/png",
   ".jpg": "image/jpeg",
   ".jpeg": "image/jpeg",
   ".webp": "image/webp",
   ".gif": "image/gif",
   ".txt": "text/plain; charset=utf-8",
}

DOCUMENT_CATEGORIES = ("Documenti ASD", "Documenti tesserato", "Certificati e certificazioni")
DOCUMENT_TEMPLATE_LABELS = {
   "iscrizione_manleva.docx": "Iscrizione e manleva",
   "privacy_consensi.docx": "Privacy e consensi",
   "liberatoria_immagini_adulto.docx": "Liberatoria immagini adulto",
   "liberatoria_immagini_minore.docx": "Liberatoria immagini minore",
   "certificato_medico.docx": "Richiesta certificato medico",
   "dichiarazione_pagamento.docx": "Dichiarazione pagamento",
   "dote_sport.docx": "Dote Sport",
   "collaboratore_volontario.docx": "Collaboratore volontario",
   "crediti_scolastici.docx": "Crediti scolastici",
   "sponsorizzazione.docx": "Sponsorizzazione",
   "dati_f24.docx": "Dati F24",
   "detrazione_730.docx": "Detrazione 730",
   "manleva_spazi.docx": "Manleva spazi",
   "idoneita_struttura.docx": "Idoneita struttura",
   "accordo_spazi.docx": "Accordo spazi",
   "tutela_minori.docx": "Tutela minori",
}
ACCEPTED_DATE_FORMATS = ["%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%Y/%m/%d"]


DANZA_LEVELS = ["Livello 1", "Livello 2", "Livello 3", "Livello 4", "Livello 5", "Advanced"]
DANZA_TYPES = ["trick", "combo"]

MAX_UPLOAD_MB = 512
MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024

MAX_LOGIN_ATTEMPTS = 7
LOGIN_WINDOW_SECONDS = 15 * 60


app = Flask(
    __name__,
    static_folder=str(STATIC_DIR),
    static_url_path="/static",
    template_folder=str(BASE_DIR / "templates"),
)
app.config.update(
   MAX_CONTENT_LENGTH=MAX_UPLOAD_BYTES,
   SESSION_COOKIE_HTTPONLY=True,
   SESSION_COOKIE_SAMESITE="Lax",
   SESSION_COOKIE_SECURE=os.environ.get("ASD_COOKIE_SECURE", "0") == "1",
   PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
)
app.secret_key = None


# ==============================
# WORKSPACE / TENANT HELPERS
# ==============================
def slugify_tenant(value: str, fallback: str = "tenant") -> str:
   text = re.sub(r"[^a-z0-9]+", "-", (value or "").strip().lower()).strip("-")
   return text or fallback


def get_tenant_root(slug: str | None = None) -> Path:
   resolved = slugify_tenant(slug or DEFAULT_TENANT_SLUG, DEFAULT_TENANT_SLUG)
   return TENANTS_DIR / resolved


def get_tenant_static_prefix(slug: str | None = None) -> str:
   return f"tenants/{slugify_tenant(slug or current_tenant_slug(), DEFAULT_TENANT_SLUG)}"


def get_tenant_static_dir(slug: str | None = None) -> Path:
   # Logo/sfondo caricati dall'utente devono stare in cartella scrivibile, non dentro .app/static.
   path = DATA_DIR / "user_static" / get_tenant_static_prefix(slug)
   path.mkdir(parents=True, exist_ok=True)
   return path


def get_workspace_db_path(slug: str | None = None) -> Path:
   return get_tenant_root(slug) / "asd.db"


def get_workspace_config_path(slug: str | None = None) -> Path:
   return get_tenant_root(slug) / "config.json"


def get_workspace_media_dir(slug: str | None = None) -> Path:
   path = get_tenant_root(slug) / "media"
   path.mkdir(parents=True, exist_ok=True)
   return path


def current_tenant_slug() -> str:
   raw = session.get("tenant_slug") if request else None
   return slugify_tenant(str(raw or os.environ.get("ASD_TENANT", DEFAULT_TENANT_SLUG)), DEFAULT_TENANT_SLUG)


def current_tenant_label() -> str:
   slug = current_tenant_slug()
   try:
       registry = load_tenants_registry()
       info = next((item for item in registry if item.get("slug") == slug), None)
       if info and info.get("name"):
           return str(info.get("name"))
   except Exception:
       pass
   return slug.replace("-", " ").title()


def default_tenants_registry() -> list[dict]:
   return [{
       "slug": DEFAULT_TENANT_SLUG,
       "name": "Nuova ASD",
       "code": "ASD",
       "active": 1,
       "created_at": now_iso_dt(),
   }]


def save_tenants_registry(items: list[dict]) -> None:
   TENANTS_DIR.mkdir(parents=True, exist_ok=True)
   clean = []
   seen = set()
   for row in items:
       slug = slugify_tenant(str(row.get("slug") or ""), DEFAULT_TENANT_SLUG)
       if slug in seen:
           continue
       seen.add(slug)
       clean.append({
           "slug": slug,
           "name": truncate(str(row.get("name") or slug.replace("-", " ").title()), 120),
           "code": truncate(str(row.get("code") or slug.upper()).upper(), 32),
           "active": 1 if int(row.get("active", 1) or 0) == 1 else 0,
           "created_at": str(row.get("created_at") or now_iso_dt()),
       })
   TENANTS_REGISTRY_FILE.write_text(json.dumps(clean or default_tenants_registry(), indent=2, ensure_ascii=False), encoding="utf-8")


def load_tenants_registry() -> list[dict]:
   TENANTS_DIR.mkdir(parents=True, exist_ok=True)
   if not TENANTS_REGISTRY_FILE.exists():
       items = default_tenants_registry()
       save_tenants_registry(items)
       return items
   try:
       items = json.loads(TENANTS_REGISTRY_FILE.read_text(encoding="utf-8"))
   except Exception:
       items = default_tenants_registry()
   if not isinstance(items, list) or not items:
       items = default_tenants_registry()
   save_tenants_registry(items)
   return json.loads(TENANTS_REGISTRY_FILE.read_text(encoding="utf-8"))


def get_tenant_choices(include_inactive: bool = False) -> list[dict]:
   items = load_tenants_registry()
   if include_inactive:
       return items
   return [item for item in items if int(item.get("active", 1) or 0) == 1]


def get_tenant_by_code_or_slug(value: str) -> dict | None:
   probe = (value or "").strip()
   slug = slugify_tenant(probe, "") if probe else ""
   code = probe.upper()
   for item in load_tenants_registry():
       if slug and item.get("slug") == slug:
           return item
       if code and str(item.get("code") or "").upper() == code:
           return item
   return None


def ensure_workspace_dirs(slug: str | None = None) -> Path:
   tenant_root = get_tenant_root(slug)
   tenant_root.mkdir(parents=True, exist_ok=True)
   get_workspace_media_dir(slug)
   (get_workspace_media_dir(slug) / "modelli_asd").mkdir(parents=True, exist_ok=True)
   (get_workspace_media_dir(slug) / "documenti_asd").mkdir(parents=True, exist_ok=True)
   (get_workspace_media_dir(slug) / "tesserati").mkdir(parents=True, exist_ok=True)
   get_tenant_static_dir(slug)
   return tenant_root

def migrate_legacy_installation(slug: str) -> None:
   resolved = slugify_tenant(slug, DEFAULT_TENANT_SLUG)
   tenant_root = ensure_workspace_dirs(resolved)
   target_db = tenant_root / "asd.db"
   target_cfg = tenant_root / "config.json"
   if resolved != DEFAULT_TENANT_SLUG:
       return
   if DB_NAME.exists() and not target_db.exists():
       try:
           shutil.copy2(DB_NAME, target_db)
       except Exception:
           pass
   if CONFIG_FILE.exists() and not target_cfg.exists():
       try:
           shutil.copy2(CONFIG_FILE, target_cfg)
       except Exception:
           pass
   legacy_media = MEDIA_DIR
   tenant_media = tenant_root / "media"
   if legacy_media.exists() and not tenant_media.exists():
       try:
           shutil.copytree(legacy_media, tenant_media)
       except Exception:
           pass


# ==============================
# GENERIC HELPERS
# ==============================
def now() -> datetime:
   return datetime.now()


def now_iso_date() -> str:
   return now().strftime("%Y-%m-%d")


def now_iso_dt() -> str:
   return now().strftime("%Y-%m-%d %H:%M:%S")


def e(value) -> str:
   return html.escape("" if value is None else str(value), quote=True)


def euro(value) -> str:
   try:
       return f"€ {float(value or 0):.2f}"
   except Exception:
       return "€ 0.00"


def parse_float(value, default: float = 0.0) -> float:
   try:
       return float(str(value).strip().replace(",", "."))
   except Exception:
       return default


def parse_int(value, default: int = 0) -> int:
   try:
       return int(str(value).strip())
   except Exception:
       return default


def current_month_year() -> tuple[int, int]:
   dt = now()
   return dt.month, dt.year


def parse_date_input(value: str) -> str:
   if not value:
       return ""
   text = str(value).strip()
   for fmt in ACCEPTED_DATE_FORMATS:
       try:
           return datetime.strptime(text, fmt).strftime("%Y-%m-%d")
       except ValueError:
           continue
   return ""


def require_valid_date(value: str, field_label: str = "data") -> str:
   normalized = parse_date_input(value)
   if not normalized:
       raise ValueError(f"Inserisci {field_label} in un formato valido (GG/MM/AAAA).")
   return normalized


def format_display_date(value: str) -> str:
   if not value:
       return ""
   normalized = parse_date_input(str(value).strip())
   if not normalized:
       return str(value)
   try:
       return datetime.strptime(normalized, "%Y-%m-%d").strftime("%d/%m/%Y")
   except Exception:
       return str(value)


def get_certificato_status(value: str) -> tuple[str, str]:
   normalized = parse_date_input(value or "")
   if not normalized:
       return "mancante", "Mancante"
   try:
       expiry = datetime.strptime(normalized, "%Y-%m-%d").date()
   except Exception:
       return "non_valido", "Data non valida"
   days = (expiry - now().date()).days
   if days < 0:
       return "scaduto", "Scaduto"
   if days <= 30:
       return "in_scadenza", "In scadenza"
   return "valido", "Valido"


def alert_html(message: str, kind: str = "info") -> str:
   colors = {
       "error": ("#fee2e2", "#7f1d1d"),
       "warning": ("#fef3c7", "#78350f"),
       "success": ("#dcfce7", "#14532d"),
       "info": ("#dbeafe", "#1e3a8a"),
   }
   bg, fg = colors.get(kind, colors["info"])
   return (
       "<div class='card' style='background:%s;color:%s;'>"
       "<p style='margin:0;font-weight:700'>%s</p></div>"
   ) % (bg, fg, e(message))


def require_non_empty(value: str, label: str, max_len: int = 120) -> str:
   text = (value or "").strip()
   if not text:
       raise ValueError(f"{label} è obbligatorio.")
   if len(text) > max_len:
       raise ValueError(f"{label} troppo lungo.")
   return text


def truncate(value: str, size: int = 300) -> str:
   text = value or ""
   return text if len(text) <= size else text[:size]


def normalize_email(value: str, max_len: int = 160) -> str:
   text = (value or "").strip()
   if not text:
       return ""
   if len(text) > max_len:
       raise ValueError("Email troppo lunga.")
   if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", text):
       raise ValueError("Email non valida.")
   return text


def normalize_phone_for_whatsapp(value: str) -> str:
   text = re.sub(r"[^0-9+]", "", (value or "").strip())
   if text.startswith("+"):
       return text[1:]
   if text.startswith("00"):
       return text[2:]
   return text


def query_url(base_path: str, **params) -> str:
   pairs = []
   for key, value in params.items():
       if value is None or value == "":
           continue
       pairs.append(f"{quote(str(key))}={quote(str(value))}")
   return base_path if not pairs else f"{base_path}?{'&'.join(pairs)}"


def redirect_with_message(base_path: str, message: str, kind: str = "success", **params):
   clean_params = dict(params)
   clean_params["msg"] = message
   clean_params["kind"] = kind
   return redirect(query_url(base_path, **clean_params))


def get_page_alert_html() -> str:
   try:
       message = request.args.get("msg", "").strip()
       kind = request.args.get("kind", "info").strip() or "info"
   except Exception:
       return ""
   if not message:
       return ""
   if kind not in {"error", "warning", "success", "info"}:
       kind = "info"
   return alert_html(message, kind)


def cleanup_old_files(folder: Path, pattern: str, keep: int = 20) -> None:
   files = sorted(folder.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
   for path in files[keep:]:
       try:
           path.unlink(missing_ok=True)
       except Exception:
           pass


def current_login_attempt_state() -> dict:
   state = session.get("_login_attempts", {"count": 0, "first_ts": 0})
   if not isinstance(state, dict):
       state = {"count": 0, "first_ts": 0}
   now_ts = int(now().timestamp())
   if now_ts - int(state.get("first_ts", 0)) > LOGIN_WINDOW_SECONDS:
       state = {"count": 0, "first_ts": 0}
   return state


def record_login_failure() -> None:
   state = current_login_attempt_state()
   now_ts = int(now().timestamp())
   if state["count"] == 0:
       state["first_ts"] = now_ts
   state["count"] += 1
   session["_login_attempts"] = state


def clear_login_failures() -> None:
   session.pop("_login_attempts", None)


def login_blocked() -> tuple[bool, str]:
   state = current_login_attempt_state()
   if state["count"] < MAX_LOGIN_ATTEMPTS:
       return False, ""
   elapsed = int(now().timestamp()) - int(state.get("first_ts", 0))
   remaining = max(0, LOGIN_WINDOW_SECONDS - elapsed)
   minutes = max(1, remaining // 60)
   return False if remaining == 0 else True, (
       f"Troppi tentativi di accesso. Riprova tra circa {minutes} minuti."
   )


# ==============================
# SECURITY
# ==============================
def get_or_create_secret_key() -> str:
   env_secret = os.environ.get("ASD_SECRET_KEY", "").strip()
   if env_secret:
       return env_secret
   if SECRET_FILE.exists():
       saved = SECRET_FILE.read_text(encoding="utf-8").strip()
       if saved:
           return saved
   generated = secrets.token_hex(32)
   SECRET_FILE.parent.mkdir(parents=True, exist_ok=True)
   SECRET_FILE.write_text(generated, encoding="utf-8")
   return generated


app.secret_key = get_or_create_secret_key()


def setup_logging() -> None:
   try:
       LOG_DIR.mkdir(parents=True, exist_ok=True)
       handler = RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=5, encoding="utf-8")
       handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
       root_logger = logging.getLogger()
       root_logger.setLevel(logging.INFO)
       if not any(isinstance(h, RotatingFileHandler) and getattr(h, 'baseFilename', '') == str(LOG_FILE) for h in root_logger.handlers):
           root_logger.addHandler(handler)
   except Exception:
       pass


def log_exception(message: str) -> None:
   try:
       logging.exception(message)
   except Exception:
       pass


def check_runtime_dependencies() -> list[str]:
   missing = []
   for module_name in ("flask", "docx", "PIL", "reportlab"):
       try:
           __import__(module_name)
       except Exception:
           missing.append(module_name)
   return missing


setup_logging()
missing_deps = check_runtime_dependencies()
if missing_deps:
   logging.warning("Dipendenze mancanti rilevate all'avvio: %s", ", ".join(missing_deps))


def auth() -> bool:
   return bool(session.get("logged"))


def set_current_tenant(slug: str) -> None:
   resolved = slugify_tenant(slug, DEFAULT_TENANT_SLUG)
   session["tenant_slug"] = resolved
   ensure_workspace_ready(resolved)


ROLE_LEVELS = {
   "viewer": 10,
   "operator": 20,
   "manager": 30,
   "admin": 40,
}

ROLE_LABELS = {
   "viewer": "Viewer",
   "operator": "Operatore",
   "manager": "Manager",
   "admin": "Admin",
}

ROLE_DESCRIPTIONS = {
   "viewer": "sola consultazione delle aree consentite",
   "operator": "operatività su tesserati, corsi, documenti e promemoria",
   "manager": "controllo operativo con accesso a incassi, ricevute e contabilità",
   "admin": "governo completo del sistema, impostazioni, utenti e backup",
}

SECTION_LABELS = {
   "dashboard": "Dashboard",
   "tesserati": "Tesserati",
   "corsi": "Corsi",
   "presenze": "Presenze",
   "minori": "Minori",
   "collaboratori": "Collaboratori",
   "pagamenti": "Pagamenti",
   "ricevute": "Ricevute",
   "documenti": "Documenti",
   "fatture": "Fatture",
   "promemoria": "Promemoria",
   "contabilita": "Contabilità",
   "backup": "Backup",
   "settings": "Impostazioni",
   "utenti": "Utenti",
   "danza": "Danza aerea",
}

DEFAULT_ROLE_SECTION_PERMISSIONS = {
   "viewer": {
       "dashboard": True, "tesserati": True, "corsi": True, "presenze": True, "minori": False,
       "collaboratori": False, "pagamenti": False, "ricevute": False, "documenti": True,
       "fatture": False, "promemoria": True, "contabilita": False, "backup": False,
       "settings": False, "utenti": False, "danza": True,
   },
   "operator": {
       "dashboard": True, "tesserati": True, "corsi": True, "presenze": True, "minori": True,
       "collaboratori": False, "pagamenti": False, "ricevute": False, "documenti": True,
       "fatture": False, "promemoria": True, "contabilita": False, "backup": False,
       "settings": False, "utenti": False, "danza": True,
   },
   "manager": {
       "dashboard": True, "tesserati": True, "corsi": True, "presenze": True, "minori": True,
       "collaboratori": True, "pagamenti": True, "ricevute": True, "documenti": True,
       "fatture": True, "promemoria": True, "contabilita": True, "backup": False,
       "settings": False, "utenti": False, "danza": True,
   },
   "admin": {k: True for k in SECTION_LABELS.keys()},
}

PATH_SECTION_MAP = [
   ("/utenti", "utenti"),
   ("/settings", "settings"),
   ("/setup-wizard", "wizard"),
   ("/backup", "backup"),
   ("/contabilita", "contabilita"),
   ("/fatture", "fatture"),
   ("/pagamenti", "pagamenti"),
   ("/ricevute", "ricevute"),
   ("/documenti", "documenti"),
   ("/promemoria", "promemoria"),
   ("/collaboratori", "collaboratori"),
   ("/minori", "minori"),
   ("/presenze", "presenze"),
   ("/corsi", "corsi"),
   ("/tesserati", "tesserati"),
   ("/danza", "danza"),
   ("/", "dashboard"),
]


def current_username() -> str:
   return str(session.get("username") or "")


def current_role() -> str:
   role = str(session.get("role") or "operator").strip().lower()
   return role if role in ROLE_LEVELS else "operator"


def role_label(role: str | None = None) -> str:
   resolved = str(role or current_role() or "operator").strip().lower()
   return ROLE_LABELS.get(resolved, resolved.title())


def role_description(role: str | None = None) -> str:
   resolved = str(role or current_role() or "operator").strip().lower()
   return ROLE_DESCRIPTIONS.get(resolved, "permessi personalizzati")


def has_role(required_role: str) -> bool:
   return ROLE_LEVELS.get(current_role(), 0) >= ROLE_LEVELS.get(str(required_role).strip().lower(), 999)


def is_admin() -> bool:
   return auth() and has_role("admin")


def login_required(view_func):
   @wraps(view_func)
   def wrapper(*args, **kwargs):
       if not auth():
           return redirect("/login")
       return view_func(*args, **kwargs)
   return wrapper


@app.route('/user-media/<path:filename>')
def user_media(filename):
   if not auth():
      return redirect('/login')
   root = (DATA_DIR / "user_static").resolve()
   requested = (root / str(filename).replace("\\", "/")).resolve()
   if requested != root and root not in requested.parents:
      return "File non valido", 403
   if not requested.exists() or not requested.is_file():
      return "File non trovato", 404
   return send_file(requested)


def role_required(required_role: str):
   def decorator(view_func):
       @wraps(view_func)
       def wrapper(*args, **kwargs):
           if not auth():
               return redirect("/login")
           if not has_role(required_role):
               return layout(alert_html("Permessi insufficienti per questa sezione.", "error")), 403
           return view_func(*args, **kwargs)
       return wrapper
   return decorator


def admin_required(view_func):
   return role_required("admin")(view_func)


def manager_required(view_func):
   return role_required("manager")(view_func)


def operator_required(view_func):
   return role_required("operator")(view_func)


def get_role_section_permissions(role: str | None = None) -> dict:
   resolved = str(role or current_role() or "operator").strip().lower()
   cfg = load_config()
   stored = cfg.get("permissions", {}) if isinstance(cfg.get("permissions"), dict) else {}
   role_data = stored.get(resolved, {}) if isinstance(stored.get(resolved), dict) else {}
   default_map = DEFAULT_ROLE_SECTION_PERMISSIONS.get(resolved, DEFAULT_ROLE_SECTION_PERMISSIONS["operator"])
   merged = {}
   for section in SECTION_LABELS:
       merged[section] = bool(role_data.get(section, default_map.get(section, False)))
   return merged


def can_access_section(section: str, role: str | None = None) -> bool:
   section_key = str(section or "").strip().lower()
   if not section_key:
       return False
   if str(role or current_role()).strip().lower() == "admin":
       return True
   return bool(get_role_section_permissions(role).get(section_key, False))


def resolve_section_from_path(path: str) -> str:
   normalized = (path or "/").strip() or "/"
   for prefix, section in PATH_SECTION_MAP:
       if prefix == "/":
           if normalized == "/":
               return section
           continue
       if normalized == prefix or normalized.startswith(prefix + "/"):
           return section
   return "dashboard"


def wizard_required() -> bool:
   cfg = load_config()
   return str(cfg.get("setup_completed", "0")) != "1"



def current_license_status() -> tuple[bool, dict | str, Path]:
   # Licenza cliente nel runtime; bypass sviluppatore solo in sorgente non congelato.
   return find_and_validate_license(DATA_DIR, app_base_dir=BASE_DIR)


def is_advanced_mode() -> bool:
   return bool(session.get("advanced_mode", False))


def details_block(title: str, body: str) -> str:
   if not is_advanced_mode():
       return ""
   safe_title = e(title or "Dettagli")
   return (
       "<details class='details-box' style='margin-top:12px;'>"
       f"<summary>{safe_title}</summary>"
       f"<div class='small-muted' style='margin-top:10px;white-space:pre-wrap;'>{body}</div>"
       "</details>"
   )


def license_required_redirect(path: str):
   ok, payload, _ = current_license_status()
   if ok:
       return None
   # Evita loop tra /licenza e /setup-wizard quando mancano sia licenza sia setup iniziale.
   # Le due pagine devono restare sempre raggiungibili dall'admin loggato.
   allowed_prefixes = ("/login", "/licenza", "/setup-wizard", "/logout", "/static", "/favicon.ico")
   if any((path or "").startswith(prefix) for prefix in allowed_prefixes):
       return None
   message = str(payload)
   if not auth():
       return None
   if has_role("admin"):
       return redirect_with_message("/licenza", "Licenza non caricata o non valida. Controlla il file licenza da questa sezione.", "warning")
   return layout(alert_html("Licenza non disponibile per questo account. Contatta l'amministratore.", "error") + details_block("Dettagli tecnici", e(message))), 403


def get_license_banner_html() -> str:
   ok, payload, path = current_license_status()
   if ok:
       return ""
   details = f"Posizione file: {e(str(path))}\nMessaggio: {e(str(payload))}"
   return alert_html(
       "Licenza non caricata. Apri la sezione Licenza per installare il file licenza di questa copia.",
       "warning",
   ) + details_block("Mostra dettagli", details)


def log_audit(action: str, details: str = "", entity_type: str = "", entity_id: str = "", status: str = "ok") -> None:
   """Compatibilità con il vecchio codice; il desktop locale non conserva audit operativi."""
   return None


def csrf_token() -> str:
   token = session.get("_csrf_token")
   if not token:
       token = secrets.token_urlsafe(32)
       session["_csrf_token"] = token
   return token


def csrf_input() -> str:
   return f'<input type="hidden" name="csrf_token" value="{e(csrf_token())}">'


@app.route("/toggle-advanced")
@login_required
def toggle_advanced_mode():
   session["advanced_mode"] = not is_advanced_mode()
   return redirect(request.referrer or "/")


@app.before_request
def protect_post_requests():
   if request.method != "POST":
       return None
   if request.endpoint == "static":
       return None
   sent = request.form.get("csrf_token", "")
   expected = session.get("_csrf_token", "")
   if not sent or not expected or not secrets.compare_digest(sent, expected):
       return (
           layout(
               alert_html(
                   "Sessione non valida o token di sicurezza mancante. Ricarica la pagina e riprova.",
                   "error",
               )
           ),
           400,
       )
   return None


@app.before_request
def enforce_section_permissions_and_wizard():
   if request.endpoint == "static":
       return None
   path = request.path or "/"
   if path.startswith("/login"):
       return None
   license_redirect = license_required_redirect(path)
   if license_redirect is not None:
       return license_redirect
   if not auth():
       return None
   if path.startswith("/setup-wizard"):
       if not has_role("admin"):
           return layout(alert_html("Solo un amministratore può completare il wizard iniziale.", "error")), 403
       return None
   if wizard_required() and has_role("admin"):
       # Lascia accessibili anche la pagina licenza e il logout per evitare redirect circolari.
       allowed_prefixes = ("/setup-wizard", "/licenza", "/logout")
       if not any(path.startswith(prefix) for prefix in allowed_prefixes):
           return redirect_with_message("/setup-wizard", "Completa prima il wizard iniziale del cliente.", "warning")
   section = resolve_section_from_path(path)
   if not can_access_section(section):
       try:
           log_audit("section_access_denied", details=f"sezione={section} path={path}", entity_type="security", status="denied")
       except Exception:
           pass
       return layout(alert_html("Permessi insufficienti per questa sezione.", "error")), 403
   return None


@app.after_request
def apply_security_headers(response):
   response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
   response.headers.setdefault("X-Content-Type-Options", "nosniff")
   response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
   response.headers.setdefault("Cache-Control", "no-store")
   response.headers.setdefault("Permissions-Policy", "geolocation=(), microphone=(), camera=()")
   return response


from werkzeug.exceptions import HTTPException

@app.errorhandler(Exception)
def handle_unexpected_error(exc):
   if isinstance(exc, HTTPException):
       return exc
   log_exception("Errore non gestito")
   return layout(alert_html("Si è verificato un errore interno. Controlla il log applicativo per i dettagli.", "error")), 500


# ==============================
# FILE / MEDIA HELPERS
# ==============================
def allowed_image(filename: str) -> bool:
   if not filename or "." not in filename:
       return False
   return filename.rsplit(".", 1)[1].lower() in ALLOWED_IMAGE_EXTENSIONS


def validate_image(file_storage) -> None:
   try:
       current_pos = file_storage.stream.tell()
   except Exception:
       current_pos = 0
   try:
       Image.MAX_IMAGE_PIXELS = 25_000_000
       image = Image.open(file_storage.stream)
       image.verify()
       file_storage.stream.seek(0)
       image = Image.open(file_storage.stream)
       if image.format not in ALLOWED_IMAGE_FORMATS:
           raise ValueError("Formato immagine non supportato.")
       width, height = image.size
       if width <= 0 or height <= 0 or width * height > 25_000_000:
           raise ValueError("Immagine troppo grande o non valida.")
   except (UnidentifiedImageError, OSError, ValueError):
       raise ValueError("Il file caricato non è un'immagine valida o supportata.")
   finally:
       try:
           file_storage.stream.seek(current_pos)
       except Exception:
           try:
               file_storage.stream.seek(0)
           except Exception:
               pass


def _prefix_subdir(prefix: str) -> Path:
   base = get_tenant_static_dir()
   if prefix == "collaboratori":
       return base / "collaboratori"
   if prefix == "danza":
       return base / "danza"
   return base


def _clean_file_stem(value: str, fallback: str = "file", max_len: int = 64) -> str:
   raw = str(value or "").strip()
   if not raw:
       return fallback
   normalized = unicodedata.normalize("NFKD", raw)
   ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
   ascii_text = re.sub(r"[^A-Za-z0-9._ -]+", "", ascii_text)
   ascii_text = ascii_text.replace(" ", "_")
   ascii_text = re.sub(r"_+", "_", ascii_text).strip("._-")
   if not ascii_text:
       return fallback
   return ascii_text[:max_len].strip("._-") or fallback


def make_unique_storage_name(target_dir: Path, original_filename: str, fallback_stem: str = "file", preferred_ext: str = "") -> str:
   safe_original = secure_filename(Path(str(original_filename or "")).name)
   stem = Path(safe_original).stem
   ext = (Path(safe_original).suffix.lower() or preferred_ext or "").strip()
   if ext and not ext.startswith("."):
       ext = f".{ext}"
   clean_stem = _clean_file_stem(stem, fallback=fallback_stem)
   candidate = f"{clean_stem}{ext}"
   if not (target_dir / candidate).exists():
       return candidate
   index = 2
   while True:
       candidate = f"{clean_stem}_{index}{ext}"
       if not (target_dir / candidate).exists():
           return candidate
       index += 1


def display_filename(value: str, max_stem: int = 34) -> str:
   name = Path(str(value or "")).name
   if not name:
       return "-"
   stem = Path(name).stem
   ext = Path(name).suffix
   if len(stem) <= max_stem:
       return name
   return f"{stem[:max_stem-1]}…{ext}"


def sanitize_folder_name(value: str, fallback: str = "cartella") -> str:
   raw = str(value or "").strip()
   if not raw:
       return ""
   normalized = unicodedata.normalize("NFKD", raw)
   ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
   ascii_text = re.sub(r"[^A-Za-z0-9 _-]+", "", ascii_text)
   ascii_text = re.sub(r"\s+", " ", ascii_text).strip(" ._-")
   ascii_text = ascii_text.replace(" ", "_")
   ascii_text = re.sub(r"_+", "_", ascii_text)
   return ascii_text[:80].strip("._-") or fallback


def secure_relative_media_path(*parts: str) -> str:
   cleaned = []
   for part in parts:
       piece = str(part or "").replace("\\", "/").strip("/")
       if not piece:
           continue
       if piece in {".", ".."}:
           continue
       piece = "/".join(seg for seg in piece.split("/") if seg not in {"", ".", ".."})
       if piece:
           cleaned.append(piece)
   return "/".join(cleaned)


def get_asd_named_folder(folder_name: str) -> Path:
   folder = sanitize_folder_name(folder_name, "cartella")
   target = get_asd_media_dir() / folder
   target.mkdir(parents=True, exist_ok=True)
   return target


def get_minor_status_from_birthdate(data_nascita: str) -> tuple[bool, int | None]:
   normalized = parse_date_input(data_nascita or "")
   if not normalized:
       return False, None
   try:
       born = datetime.strptime(normalized, "%Y-%m-%d").date()
   except ValueError:
       return False, None
   today = now().date()
   age = today.year - born.year - ((today.month, today.day) < (born.month, born.day))
   return age < 18, age


def upsert_minore_from_tesserato(cursor, tesserato_row: dict, parent_payload: dict | None = None) -> tuple[bool, str]:
   payload = parent_payload or {}
   is_minor, age = get_minor_status_from_birthdate(str(tesserato_row.get("data_nascita") or ""))
   existing = cursor.execute("SELECT id FROM minori WHERE tesserato_id=?", (int(tesserato_row.get("id") or 0),)).fetchone()
   if not is_minor:
       if existing:
           cursor.execute("DELETE FROM minori WHERE tesserato_id=?", (int(tesserato_row.get("id") or 0),))
           return False, "Scheda minore rimossa: il tesserato risulta maggiorenne."
       return False, ""

   existing_full = cursor.execute("SELECT * FROM minori WHERE tesserato_id=?", (int(tesserato_row.get("id") or 0),)).fetchone()
   genitore = truncate(str(payload.get("genitore") or (existing_full["genitore"] if existing_full else "")).strip(), 140)
   telefono_genitore = truncate(str(payload.get("telefono_genitore") or (existing_full["telefono_genitore"] if existing_full else "")).strip(), 40)
   email_genitore = normalize_email(str(payload.get("email_genitore") or (existing_full["email_genitore"] if existing_full else "")).strip(), 140)
   consenso_value = payload.get("consenso_firmato")
   consenso_firmato = (1 if int(existing_full["consenso_firmato"] or 0) == 1 else 0) if consenso_value in (None, "") and existing_full is not None else (1 if str(consenso_value or "0") == "1" else 0)
   raw_data_consenso = str(payload.get("data_consenso") or (existing_full["data_consenso"] if existing_full else "")).strip()
   data_consenso = parse_date_input(raw_data_consenso) if raw_data_consenso else ""
   note_consenso = truncate(str(payload.get("note_consenso") or (existing_full["note_consenso"] if existing_full else "")).strip(), 400)

   if not genitore:
       raise ValueError("Il tesserato risulta minorenne: inserisci il nominativo del genitore o tutore.")
   if not telefono_genitore and not email_genitore:
       raise ValueError("Per un minorenne inserisci almeno telefono o email del genitore.")
   if consenso_firmato and not data_consenso:
       raise ValueError("Se il consenso del genitore è firmato, inserisci anche la data del consenso.")

   params = (
       int(tesserato_row.get("id") or 0),
       truncate(str(tesserato_row.get("nome") or "").strip(), 120),
       truncate(str(tesserato_row.get("cognome") or "").strip(), 120),
       genitore,
       telefono_genitore,
       email_genitore,
       consenso_firmato,
       data_consenso,
       note_consenso,
   )
   if existing:
       cursor.execute(
           """
           UPDATE minori
           SET nome=?, cognome=?, genitore=?, telefono_genitore=?, email_genitore=?,
               consenso_firmato=?, data_consenso=?, note_consenso=?
           WHERE tesserato_id=?
           """,
           (params[1], params[2], params[3], params[4], params[5], params[6], params[7], params[8], params[0]),
       )
       return True, f"Scheda minore aggiornata automaticamente ({age} anni)."
   cursor.execute(
       """
       INSERT INTO minori(
           tesserato_id, nome, cognome, genitore, telefono_genitore, email_genitore, consenso_firmato, data_consenso, note_consenso
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
       """,
       params,
   )
   return True, f"Scheda minore creata automaticamente ({age} anni)."


def save_uploaded_image(file_storage, prefix: str) -> str:
   if not file_storage or not file_storage.filename:
       return ""
   if not allowed_image(file_storage.filename):
       raise ValueError("Formato immagine non supportato.")
   validate_image(file_storage)
   filename = secure_filename(file_storage.filename)
   ext = filename.rsplit(".", 1)[1].lower()
   save_dir = _prefix_subdir(prefix)
   save_dir.mkdir(parents=True, exist_ok=True)
   unique_name = make_unique_storage_name(save_dir, filename, fallback_stem=prefix, preferred_ext=f'.{ext}')
   save_path = save_dir / unique_name
   file_storage.save(save_path)
   prefix_path = get_tenant_static_prefix()
   if prefix == "collaboratori":
       return f"{prefix_path}/collaboratori/{unique_name}"
   if prefix == "danza":
       return f"{prefix_path}/danza/{unique_name}"
   return f"{prefix_path}/{unique_name}"


def resolve_user_static_path(relative_path: str) -> Path | None:
   """Risolvi in sicurezza un asset caricato dall'utente nel runtime tenant."""
   if not relative_path:
       return None
   try:
       safe_rel = Path(str(relative_path).replace("\\", "/")).as_posix().lstrip("/")
       root = (DATA_DIR / "user_static").resolve()
       candidate = (root / safe_rel).resolve()
       if candidate == root or root not in candidate.parents:
           return None
       return candidate
   except Exception:
       return None


def delete_uploaded_image(relative_path: str) -> None:
   path = resolve_user_static_path(relative_path)
   try:
       if path and path.exists() and path.is_file():
           path.unlink(missing_ok=True)
   except Exception:
       pass


def allowed_document(filename: str) -> bool:
   if not filename or "." not in filename:
       return False
   return filename.rsplit(".", 1)[1].lower() in ALLOWED_DOCUMENT_EXTENSIONS


def get_tesserato_media_dir(tesserato_id: int) -> Path:
   path = get_workspace_media_dir() / "tesserati" / str(tesserato_id)
   path.mkdir(parents=True, exist_ok=True)
   return path


def get_template_library_dir() -> Path:
   path = get_workspace_media_dir() / "modelli_asd"
   path.mkdir(parents=True, exist_ok=True)
   bootstrap_template_library(path)
   return path


def get_asd_media_dir() -> Path:
   path = get_workspace_media_dir() / "documenti_asd"
   path.mkdir(parents=True, exist_ok=True)
   return path


def bootstrap_template_library(target_dir: Path) -> None:
   """Sincronizza la libreria modelli per tenant senza creare doppioni.
   I file canonici hanno nomi semplici snake_case; eventuali vecchi modelli
   con nomi storici/resti di patch vengono rimossi dalla sola cartella modelli.
   """
   target_dir.mkdir(parents=True, exist_ok=True)
   source_dir = TEMPLATE_LIBRARY_DIR
   canonical = set(DOCUMENT_TEMPLATE_LABELS.keys())

   for old in list(target_dir.iterdir()):
       if old.is_file() and old.suffix.lower() == ".docx" and old.name not in canonical:
           try:
               old.unlink()
           except Exception:
               pass

   if not source_dir.exists():
       return

   for name in canonical:
       src = source_dir / name
       if not src.exists() or not src.is_file():
           continue
       dest = target_dir / name
       try:
           if (not dest.exists()) or (src.stat().st_mtime > dest.stat().st_mtime) or (src.stat().st_size != dest.stat().st_size):
               shutil.copy2(src, dest)
       except Exception:
           pass


def list_template_library_files() -> list[dict]:
   library = []
   template_dir = get_template_library_dir()
   canonical_order = list(DOCUMENT_TEMPLATE_LABELS.keys())
   existing = {p.name: p for p in template_dir.iterdir() if p.is_file() and p.suffix.lower() == ".docx" and not p.name.startswith(("~$", "."))}
   for name in canonical_order:
       path = existing.get(name)
       if not path:
           continue
       label = DOCUMENT_TEMPLATE_LABELS.get(path.name, path.stem.replace("_", " "))
       library.append({
           "filename": path.name,
           "label": label,
           "size_kb": max(1, int(round(path.stat().st_size / 1024))),
       })
   return library


def get_template_library_path(filename: str) -> Path:
   # Accetta solo il nome file, mantiene i nomi canonici e blocca path traversal.
   raw_name = Path(str(filename).replace("\\", "/")).name
   if raw_name not in DOCUMENT_TEMPLATE_LABELS:
       candidate = secure_filename(raw_name)
       if candidate in DOCUMENT_TEMPLATE_LABELS:
           raw_name = candidate
       else:
           raise ValueError("Modello ASD non riconosciuto o non più valido.")
   return (get_template_library_dir() / raw_name).resolve()


def copy_template_to_tesserato(template_filename: str, tesserato_id: int) -> tuple[str, str, str]:
   src = get_template_library_path(template_filename)
   template_root = get_template_library_dir().resolve()
   if template_root not in src.parents or not src.exists():
       raise ValueError("Modello ASD non trovato.")
   dest_dir = get_tesserato_media_dir(tesserato_id)
   ext = src.suffix.lower() or ".docx"
   dest_name = make_unique_storage_name(dest_dir, src.name, fallback_stem="modello", preferred_ext=ext)
   dest_path = dest_dir / dest_name
   shutil.copy2(src, dest_path)
   relative = str(Path("tesserati") / str(tesserato_id) / dest_name).replace("\\", "/")
   label = DOCUMENT_TEMPLATE_LABELS.get(src.name, src.stem.replace("_", " "))
   return relative, src.name, label


def save_uploaded_document(file_storage, tesserato_id: int) -> tuple[str, str]:
   if not file_storage or not file_storage.filename:
       raise ValueError("Seleziona un file da caricare.")
   if not allowed_document(file_storage.filename):
       raise ValueError("Formato documento non supportato.")
   original = secure_filename(file_storage.filename)
   ext = original.rsplit(".", 1)[1].lower()
   save_dir = get_tesserato_media_dir(tesserato_id)
   safe_name = make_unique_storage_name(save_dir, original, fallback_stem="documento", preferred_ext=f'.{ext}')
   save_path = save_dir / safe_name
   file_storage.save(save_path)
   relative = str(Path("tesserati") / str(tesserato_id) / safe_name)
   return relative.replace("\\", "/"), original


def delete_media_file(relative_path: str) -> None:
   if not relative_path:
       return
   try:
       safe_rel = Path(str(relative_path).replace("\\", "/")).as_posix().lstrip("/")
       abs_path = (get_workspace_media_dir() / safe_rel).resolve()
       media_root = get_workspace_media_dir().resolve()
       if media_root in abs_path.parents or abs_path == media_root:
           if abs_path.exists() and abs_path.is_file():
               abs_path.unlink(missing_ok=True)
   except Exception:
       pass


def document_abs_path(relative_path: str) -> Path:
   safe_rel = Path(str(relative_path).replace("\\", "/")).as_posix().lstrip("/")
   return (get_workspace_media_dir() / safe_rel).resolve()


def document_status_info(data_scadenza: str) -> tuple[str, str]:
   normalized = parse_date_input(data_scadenza or "")
   if not normalized:
       return "mancante", "Nessuna scadenza"
   try:
       expiry = datetime.strptime(normalized, "%Y-%m-%d").date()
   except Exception:
       return "non_valido", "Data non valida"
   days = (expiry - now().date()).days
   if days < 0:
       return "scaduto", "Scaduto"
   if days <= 30:
       return "in_scadenza", "In scadenza"
   return "valido", "Valido"



def danza_placeholder_data_uri(label: str = "Danza Aerea") -> str:
   from urllib.parse import quote as url_quote
   svg = f"""
   <svg xmlns="http://www.w3.org/2000/svg" width="800" height="500">
       <defs>
           <linearGradient id="g" x1="0" x2="1" y1="0" y2="1">
               <stop offset="0%" stop-color="#0f172a"/>
               <stop offset="100%" stop-color="#111827"/>
           </linearGradient>
       </defs>
       <rect width="100%" height="100%" fill="url(#g)"/>
       <rect x="20" y="20" width="760" height="460" rx="24" fill="#111827" stroke="#38bdf8" stroke-width="3"/>
       <text x="50%" y="46%" dominant-baseline="middle" text-anchor="middle"
             font-family="Arial, sans-serif" font-size="38" fill="#e5e7eb">Danza Aerea</text>
       <text x="50%" y="58%" dominant-baseline="middle" text-anchor="middle"
             font-family="Arial, sans-serif" font-size="22" fill="#93c5fd">{html.escape(label)}</text>
   </svg>
   """.strip()
   return "data:image/svg+xml;utf8," + url_quote(svg)


def resolve_brand_asset_path(name: str) -> Path | None:
   """Restituisce il percorso reale di un logo/sfondo, tenant prima del bundle."""
   raw = str(name or "").replace("\\", "/").lstrip("/")
   if not raw:
       return None
   user = resolve_user_static_path(raw)
   if user and user.exists() and user.is_file():
       return user
   candidate = (STATIC_DIR / raw).resolve()
   static_root = STATIC_DIR.resolve()
   if (candidate == static_root or static_root not in candidate.parents) or not candidate.exists() or not candidate.is_file():
       return None
   return candidate


def file_url(name: str) -> str:
   if not name:
      return ""
   safe_name = str(name).replace("\\", "/").lstrip("/")
   user_path = DATA_DIR / "user_static" / safe_name
   if user_path.exists():
      version = int(user_path.stat().st_mtime)
      return f"/user-media/{safe_name}?v={version}"
   path = STATIC_DIR / safe_name
   version = int(path.stat().st_mtime) if path.exists() else 0
   return f"/static/{safe_name}?v={version}"


# ==============================
# CONFIG HELPERS
# ==============================
def find_libreoffice_executable() -> str:
   for candidate in ("libreoffice", "soffice"):
       found = shutil.which(candidate)
       if found:
           return found
   return ""


def preview_pdf_cache_path(source_path: Path) -> Path:
   return source_path.with_name(f"{source_path.stem}.preview.pdf")


def resolve_document_preview_path(path: Path) -> tuple[Path, str]:
   ext = path.suffix.lower()
   if ext in PREVIEW_MIME_TYPES:
       return path, PREVIEW_MIME_TYPES[ext]

   if ext not in {".doc", ".docx"}:
       raise ValueError("Anteprima non disponibile per questo tipo di file. Usa Scarica.")

   office_exec = find_libreoffice_executable()
   if not office_exec:
       raise ValueError("Anteprima DOC/DOCX non disponibile: installa LibreOffice oppure usa Scarica.")

   preview_pdf = preview_pdf_cache_path(path)
   try:
       if preview_pdf.exists() and preview_pdf.stat().st_mtime >= path.stat().st_mtime:
           return preview_pdf, "application/pdf"
   except Exception:
       pass

   try:
       subprocess.run(
           [
               office_exec,
               "--headless",
               "--convert-to",
               "pdf",
               "--outdir",
               str(path.parent),
               str(path),
           ],
           check=True,
           stdout=subprocess.DEVNULL,
           stderr=subprocess.DEVNULL,
           timeout=45,
       )
   except Exception as exc:
       raise ValueError("Conversione anteprima DOC/DOCX non riuscita. Puoi comunque scaricare il file.") from exc

   generated_pdf = path.with_suffix(".pdf")
   if generated_pdf.exists():
       try:
           if generated_pdf != preview_pdf:
               if preview_pdf.exists():
                   preview_pdf.unlink(missing_ok=True)
               generated_pdf.replace(preview_pdf)
       except Exception:
           preview_pdf = generated_pdf

   if preview_pdf.exists():
       return preview_pdf, "application/pdf"

   if generated_pdf.exists():
       return generated_pdf, "application/pdf"

   raise ValueError("Anteprima PDF non generata. Usa Scarica.")

def save_config(cfg: dict) -> None:
   """Salva la configurazione del workspace corrente in modo difensivo.

   In alcune installazioni desktop locali la cartella tenants/default può non
   esistere ancora quando Flask entra nei before_request (licenza/wizard/layout).
   Senza questa mkdir preventiva qualunque pagina, compresa /pagamenti, può
   finire in errore interno prima ancora di arrivare alla route reale.
   """
   STATIC_DIR.mkdir(parents=True, exist_ok=True)
   TENANTS_DIR.mkdir(parents=True, exist_ok=True)
   config_path = get_workspace_config_path()
   config_path.parent.mkdir(parents=True, exist_ok=True)
   config_path.write_text(json.dumps(cfg, indent=4, ensure_ascii=False), encoding="utf-8")


def load_config() -> dict:
   default = {
       "nome_asd": "ASD PRO SYSTEM",
       "firma": "Daniele De Angelis",
       "logo": "",
       "background": "",
       "iban": "",
       "fatturapa": {
           "cedente_nome": "",
           "cedente_piva": "",
           "cedente_cf": "",
           "regime_fiscale": "RF01",
           "cedente_indirizzo": "",
           "cedente_cap": "",
           "cedente_comune": "",
           "cedente_provincia": "",
           "cedente_nazione": "IT",
           "cedente_pec": "",
           "cedente_telefono": "",
           "codice_destinatario_default": "0000000",
           "iva_default": "0.00",
           "natura_default": "N2.2",
           "esigibilita_iva": "I"
       },
       "mail": {
           "enabled": "0",
       },
       "whatsapp": {
           "enabled": "1",
           "template_reminder": "Ciao {nome}, ti ricordiamo la quota {periodo} per {asd}. Importo: € {importo}.",
           "template_confirmed": "Ciao {nome}, abbiamo registrato il pagamento di € {importo}. Grazie.",
       },
       "branding": {
           "app_name": "Asd Pro System",
           "suite_label": "ASD Pro Manager",
           "login_title": "Accesso area riservata",
           "login_subtitle": "Gestione professionale ASD con ruoli distinti, branding personalizzabile e archivio documentale centralizzato.",
       },
       "permissions": {role: dict(perms) for role, perms in DEFAULT_ROLE_SECTION_PERMISSIONS.items()},
       "setup_completed": "0",
       "documenti": {
           "denominazione": "",
           "cf": "",
           "piva": "",
           "sede_indirizzo": "",
           "sede_cap": "",
           "sede_comune": "",
           "sede_provincia": "",
           "telefono": "",
           "email": "",
           "pec": "",
           "affiliazione": "",
           "numero_affiliazione": "",
           "presidente": "",
           "referente_privacy": "",
           "luogo_firma": "",
           "foro_competente": "",
           "iban": "",
           "sito_web": "",
           "note_legali": "",
       },
   }
   config_path = get_workspace_config_path()
   config_path.parent.mkdir(parents=True, exist_ok=True)
   if not config_path.exists():
       save_config(default)
       return default.copy()
   try:
       cfg = json.loads(config_path.read_text(encoding="utf-8"))
   except Exception:
       cfg = default.copy()

   for key, value in default.items():
       cfg.setdefault(key, value)

   # Desktop locale: nessuna configurazione di servizi online/API.
   if isinstance(cfg.get("mail"), dict):
       for obsolete in ("smtp_host", "smtp_port", "smtp_user", "smtp_password", "use_ssl", "use_tls", "reply_to"):
           cfg["mail"].pop(obsolete, None)
   if isinstance(cfg.get("whatsapp"), dict):
       for obsolete in ("provider", "business_number", "api_token", "auto_enabled", "auto_send_receipt"):
           cfg["whatsapp"].pop(obsolete, None)

   if not isinstance(cfg.get("fatturapa"), dict):
       cfg["fatturapa"] = {}
   for key, value in default["fatturapa"].items():
       cfg["fatturapa"].setdefault(key, value)

   if not isinstance(cfg.get("mail"), dict):
       cfg["mail"] = {}
   for key, value in default["mail"].items():
       cfg["mail"].setdefault(key, value)

   if not isinstance(cfg.get("whatsapp"), dict):
       cfg["whatsapp"] = {}
   for key, value in default["whatsapp"].items():
       cfg["whatsapp"].setdefault(key, value)

   if not isinstance(cfg.get("branding"), dict):
       cfg["branding"] = {}
   for key, value in default["branding"].items():
       cfg["branding"].setdefault(key, value)

   if not isinstance(cfg.get("documenti"), dict):
       cfg["documenti"] = {}
   for key, value in default["documenti"].items():
       cfg["documenti"].setdefault(key, value)

   return cfg


# ==============================
# DATABASE
# ==============================
def db():
   ensure_workspace_ready(current_tenant_slug())
   conn = sqlite3.connect(get_workspace_db_path(), timeout=10)
   conn.row_factory = sqlite3.Row
   conn.execute("PRAGMA foreign_keys = ON")
   return conn


def ensure_column(cursor, table_name: str, column_name: str, column_sql: str) -> None:
   cols = [r[1] for r in cursor.execute(f"PRAGMA table_info({table_name})").fetchall()]
   if column_name not in cols:
       cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_sql}")


def dedupe_before_unique_indexes(cursor) -> None:
   duplicates = cursor.execute(
       """
       SELECT tesserato_id, mese, anno, causale, MIN(id) AS keep_id
       FROM pagamenti
       GROUP BY tesserato_id, mese, anno, causale
       HAVING COUNT(*) > 1
       """
   ).fetchall()
   for dup in duplicates:
       cursor.execute(
           "DELETE FROM pagamenti WHERE tesserato_id=? AND mese=? AND anno=? AND causale=? AND id<>?",
           (dup["tesserato_id"], dup["mese"], dup["anno"], dup["causale"], dup["keep_id"]),
       )

   duplicates = cursor.execute(
       """
       SELECT tesserato_id, corso_id, data, MIN(id) AS keep_id
       FROM prenotazioni
       GROUP BY tesserato_id, corso_id, data
       HAVING COUNT(*) > 1
       """
   ).fetchall()
   for dup in duplicates:
       cursor.execute(
           "DELETE FROM prenotazioni WHERE tesserato_id=? AND corso_id=? AND data=? AND id<>?",
           (dup["tesserato_id"], dup["corso_id"], dup["data"], dup["keep_id"]),
       )

   duplicates_ore = cursor.execute(
       """
       SELECT collaboratore_id, data, MIN(id) AS keep_id
       FROM ore_collaboratori
       GROUP BY collaboratore_id, data
       HAVING COUNT(*) > 1
       """
   ).fetchall()
   for dup in duplicates_ore:
       total_ore = cursor.execute(
           """
           SELECT COALESCE(SUM(ore), 0)
           FROM ore_collaboratori
           WHERE collaboratore_id=? AND data=?
           """,
           (dup["collaboratore_id"], dup["data"]),
       ).fetchone()[0]
       cursor.execute("UPDATE ore_collaboratori SET ore=? WHERE id=?", (float(total_ore or 0), dup["keep_id"]))
       cursor.execute(
           """
           DELETE FROM ore_collaboratori
           WHERE collaboratore_id=? AND data=? AND id<>?
           """,
           (dup["collaboratore_id"], dup["data"], dup["keep_id"]),
       )


def seed_default_danza(cursor) -> None:
   count = cursor.execute("SELECT COUNT(*) FROM danza_elementi").fetchone()[0]
   if count:
       return
   now_str = now_iso_dt()
   sample_rows = [
       ("trick", "Livello 1", "Salita Base", "Salita introduttiva per acquisire confidenza con l'attrezzo.", "", "", "", "Grip e linea del corpo", "Tenuta mani e attivazione addome", "Respira, spingi con i piedi e non tirare solo di braccia.", "Spalle chiuse, slancio eccessivo", "Usare sempre materasso e assistenza nelle prime prove.", 1, 1, now_str, now_str),
       ("trick", "Livello 1", "Seat", "Posizione seduta stabile per pause e transizioni.", "", "", "", "Controllo del bacino", "Salita base", "Blocca bene il tessuto / attrezzo prima di scaricare peso.", "Seduta troppo alta o troppo bassa", "Verificare sempre il punto di contatto.", 2, 1, now_str, now_str),
       ("combo", "Livello 2", "Salita + Seat + Discesa", "Combo semplice per fluidità e controllo.", "Salita base → Seat → Discesa controllata", "", "", "Fluidità e ritmo", "Salita base, seat", "Conta mentalmente i passaggi e rallenta l'uscita.", "Fermarsi a metà transizione", "Non accelerare la discesa.", 10, 1, now_str, now_str),
       ("trick", "Livello 3", "Invert Base", "Prima inversione controllata con focus su core.", "", "", "", "Forza addominale", "Tenuta sospesa e compressioni", "Inizia con regressioni e spotter.", "Chiudere il collo, perdere hollow", "Provare solo se il prerequisito è davvero acquisito.", 20, 1, now_str, now_str),
       ("combo", "Advanced", "Flow Spin Advanced", "Sequenza scenica avanzata con spin e uscita pulita.", "Entrata spin → rotazione → hold → uscita", "", "", "Timing e orientamento", "Spin base, invert, controllo dinamico", "Studia il ritmo e i punti di sguardo.", "Perdere orientamento", "Progressione solo con tecnica consolidata.", 100, 1, now_str, now_str),
   ]
   cursor.executemany(
       """
       INSERT INTO danza_elementi(
           tipo, livello, nome, descrizione, sequenza, immagine, video_url,
           focus, prerequisiti, consigli, errori_comuni, nota_sicurezza,
           ordine, attivo, created_at, updated_at
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       """,
       sample_rows,
   )


def init_db_for_path(db_path: Path, tenant_slug: str | None = None) -> None:
   db_path = Path(db_path)
   db_path.parent.mkdir(parents=True, exist_ok=True)
   conn = sqlite3.connect(str(db_path), timeout=10)
   conn.row_factory = sqlite3.Row
   conn.execute("PRAGMA foreign_keys = ON")
   c = conn.cursor()
   try:

      c.execute("""CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT NOT NULL, role TEXT DEFAULT 'operator', active INTEGER DEFAULT 1, created_at TEXT, updated_at TEXT)""")
      c.execute("""CREATE TABLE IF NOT EXISTS tesserati (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, cognome TEXT NOT NULL, telefono TEXT, corso TEXT, certificato_scadenza TEXT)""")
      c.execute("""CREATE TABLE IF NOT EXISTS pagamenti (id INTEGER PRIMARY KEY AUTOINCREMENT, tesserato_id INTEGER NOT NULL, mese INTEGER NOT NULL, anno INTEGER NOT NULL, importo REAL NOT NULL DEFAULT 0, data TEXT, causale TEXT NOT NULL DEFAULT 'mensile', FOREIGN KEY (tesserato_id) REFERENCES tesserati(id) ON DELETE CASCADE)""")
      c.execute("""CREATE TABLE IF NOT EXISTS ricevute (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, descrizione TEXT NOT NULL, importo REAL NOT NULL DEFAULT 0, data TEXT, pagamento_id INTEGER, pdf_filename TEXT)""")
      c.execute("""CREATE TABLE IF NOT EXISTS movimenti (id INTEGER PRIMARY KEY AUTOINCREMENT, tipo TEXT NOT NULL, categoria TEXT, descrizione TEXT, importo REAL NOT NULL DEFAULT 0, data TEXT, pagamento_id INTEGER, auto_generato INTEGER DEFAULT 0)""")
      c.execute("""CREATE TABLE IF NOT EXISTS minori (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, cognome TEXT NOT NULL, genitore TEXT NOT NULL)""")
      c.execute("""CREATE TABLE IF NOT EXISTS corsi (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, descrizione TEXT, orario TEXT, max_iscritti INTEGER DEFAULT 0)""")
      c.execute("""CREATE TABLE IF NOT EXISTS prenotazioni (id INTEGER PRIMARY KEY AUTOINCREMENT, tesserato_id INTEGER NOT NULL, corso_id INTEGER NOT NULL, data TEXT NOT NULL, FOREIGN KEY (tesserato_id) REFERENCES tesserati(id) ON DELETE CASCADE, FOREIGN KEY (corso_id) REFERENCES corsi(id) ON DELETE CASCADE)""")
      c.execute("""CREATE TABLE IF NOT EXISTS collaboratori (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, cognome TEXT NOT NULL, foto TEXT, minor INTEGER DEFAULT 0, paga_oraria REAL DEFAULT 10.0)""")
      c.execute("""CREATE TABLE IF NOT EXISTS ore_collaboratori (id INTEGER PRIMARY KEY AUTOINCREMENT, collaboratore_id INTEGER NOT NULL, data TEXT NOT NULL, ore REAL NOT NULL DEFAULT 0, FOREIGN KEY (collaboratore_id) REFERENCES collaboratori(id) ON DELETE CASCADE)""")
      c.execute("""CREATE TABLE IF NOT EXISTS danza_elementi (id INTEGER PRIMARY KEY AUTOINCREMENT, tipo TEXT NOT NULL, livello TEXT NOT NULL, nome TEXT NOT NULL, descrizione TEXT, sequenza TEXT, immagine TEXT, video_url TEXT, focus TEXT, prerequisiti TEXT, consigli TEXT, errori_comuni TEXT, nota_sicurezza TEXT, ordine INTEGER DEFAULT 0, attivo INTEGER DEFAULT 1, created_at TEXT, updated_at TEXT)""")
      c.execute("""CREATE TABLE IF NOT EXISTS fatture (id INTEGER PRIMARY KEY AUTOINCREMENT, numero INTEGER NOT NULL, anno INTEGER NOT NULL, cliente_nome TEXT NOT NULL, cliente_cf TEXT, cliente_piva TEXT, cliente_email TEXT, cliente_indirizzo TEXT, descrizione TEXT NOT NULL, importo REAL NOT NULL DEFAULT 0, data TEXT NOT NULL, stato TEXT NOT NULL DEFAULT 'bozza', bollo INTEGER NOT NULL DEFAULT 0, xml_path TEXT, pdf_path TEXT, provider TEXT, external_id TEXT, data_invio TEXT, esito TEXT)""")
      c.execute("""CREATE TABLE IF NOT EXISTS documenti (id INTEGER PRIMARY KEY AUTOINCREMENT, tesserato_id INTEGER NOT NULL, titolo TEXT NOT NULL, categoria TEXT NOT NULL, filename TEXT NOT NULL, original_filename TEXT NOT NULL, data_caricamento TEXT, data_scadenza TEXT, note TEXT, visibile INTEGER DEFAULT 1, tipo_template TEXT, FOREIGN KEY (tesserato_id) REFERENCES tesserati(id) ON DELETE CASCADE)""")
      c.execute("""CREATE TABLE IF NOT EXISTS collaboratori_ricevute (id INTEGER PRIMARY KEY AUTOINCREMENT, collaboratore_id INTEGER NOT NULL, mese INTEGER NOT NULL, anno INTEGER NOT NULL, totale_ore REAL NOT NULL DEFAULT 0, paga_oraria REAL NOT NULL DEFAULT 0, totale_compenso REAL NOT NULL DEFAULT 0, data_generazione TEXT, filename TEXT NOT NULL, movimento_id INTEGER, FOREIGN KEY (collaboratore_id) REFERENCES collaboratori(id) ON DELETE CASCADE)""")
      c.execute("""CREATE TABLE IF NOT EXISTS collaboratori_liquidazioni (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          collaboratore_id INTEGER NOT NULL,
          mese INTEGER NOT NULL,
          anno INTEGER NOT NULL,
          data_pagamento TEXT,
          compenso_lordo REAL NOT NULL DEFAULT 0,
          franchigia_inps_precedente REAL NOT NULL DEFAULT 0,
          imponibile_inps_ivS REAL NOT NULL DEFAULT 0,
          imponibile_inps_assistenziale REAL NOT NULL DEFAULT 0,
          contributo_inps_totale REAL NOT NULL DEFAULT 0,
          quota_inps_asd REAL NOT NULL DEFAULT 0,
          quota_inps_collaboratore REAL NOT NULL DEFAULT 0,
          imponibile_fiscale REAL NOT NULL DEFAULT 0,
          ritenuta_irpef REAL NOT NULL DEFAULT 0,
          netto_pagato REAL NOT NULL DEFAULT 0,
          tipo_rapporto TEXT NOT NULL DEFAULT 'sportivo_co.co.co',
          copertura_previdenziale TEXT NOT NULL DEFAULT 'nessuna',
          tipo_rapporto_inps TEXT,
          codice_attivita_inps TEXT,
          stato TEXT NOT NULL DEFAULT 'bozza',
          note TEXT,
          created_at TEXT,
          updated_at TEXT,
          FOREIGN KEY (collaboratore_id) REFERENCES collaboratori(id) ON DELETE CASCADE
      )""")
      c.execute("""CREATE TABLE IF NOT EXISTS f24_sportivi (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          mese INTEGER NOT NULL,
          anno INTEGER NOT NULL,
          data_scadenza TEXT,
          codice_tributo TEXT NOT NULL,
          sezione TEXT NOT NULL DEFAULT 'INPS',
          causale TEXT,
          codice_sede TEXT,
          matricola_inps TEXT,
          periodo_da TEXT,
          periodo_a TEXT,
          importo REAL NOT NULL DEFAULT 0,
          descrizione TEXT,
          stato TEXT NOT NULL DEFAULT 'da_pagare',
          created_at TEXT
      )""")
      c.execute("""CREATE TABLE IF NOT EXISTS presenze (id INTEGER PRIMARY KEY AUTOINCREMENT, tesserato_id INTEGER NOT NULL, corso_id INTEGER NOT NULL, data TEXT NOT NULL, stato TEXT NOT NULL DEFAULT 'presente', note TEXT, created_at TEXT, updated_at TEXT, FOREIGN KEY (tesserato_id) REFERENCES tesserati(id) ON DELETE CASCADE, FOREIGN KEY (corso_id) REFERENCES corsi(id) ON DELETE CASCADE)""")
      c.execute("""CREATE TABLE IF NOT EXISTS packages (id INTEGER PRIMARY KEY AUTOINCREMENT, tesserato_id INTEGER NOT NULL, tipo TEXT NOT NULL DEFAULT 'Pacchetto ingressi', ingressi_totali INTEGER NOT NULL DEFAULT 0, ingressi_residui INTEGER NOT NULL DEFAULT 0, data_acquisto TEXT, scadenza TEXT, certificato_richiesto INTEGER DEFAULT 1, attivo INTEGER DEFAULT 1, note TEXT, created_at TEXT, updated_at TEXT, FOREIGN KEY (tesserato_id) REFERENCES tesserati(id) ON DELETE CASCADE)""")
      c.execute("""CREATE TABLE IF NOT EXISTS package_usages (id INTEGER PRIMARY KEY AUTOINCREMENT, package_id INTEGER NOT NULL, tesserato_id INTEGER NOT NULL, presenza_id INTEGER, corso_id INTEGER, data_presenza TEXT NOT NULL, qty INTEGER NOT NULL DEFAULT 1, created_at TEXT, FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE CASCADE, FOREIGN KEY (tesserato_id) REFERENCES tesserati(id) ON DELETE CASCADE)""")
      c.execute("""CREATE TABLE IF NOT EXISTS operational_task_state (id INTEGER PRIMARY KEY AUTOINCREMENT, task_key TEXT NOT NULL UNIQUE, status TEXT NOT NULL DEFAULT 'open', note TEXT, last_action TEXT, created_at TEXT, updated_at TEXT)""")

      ensure_column(c, "fatture", "cliente_codice_destinatario", "cliente_codice_destinatario TEXT")
      ensure_column(c, "fatture", "cliente_pec", "cliente_pec TEXT")
      ensure_column(c, "fatture", "cliente_cap", "cliente_cap TEXT")
      ensure_column(c, "fatture", "cliente_comune", "cliente_comune TEXT")
      ensure_column(c, "fatture", "cliente_provincia", "cliente_provincia TEXT")
      ensure_column(c, "fatture", "cliente_nazione", "cliente_nazione TEXT")
      ensure_column(c, "fatture", "tipo_documento", "tipo_documento TEXT NOT NULL DEFAULT 'TD01'")
      ensure_column(c, "fatture", "aliquota_iva", "aliquota_iva REAL NOT NULL DEFAULT 0")
      ensure_column(c, "fatture", "natura", "natura TEXT")
      ensure_column(c, "fatture", "imponibile", "imponibile REAL NOT NULL DEFAULT 0")
      ensure_column(c, "fatture", "imposta", "imposta REAL NOT NULL DEFAULT 0")
      ensure_column(c, "fatture", "totale_documento", "totale_documento REAL NOT NULL DEFAULT 0")
      ensure_column(c, "fatture", "fattura_tipo", "fattura_tipo TEXT NOT NULL DEFAULT 'elettronica'")

      ensure_column(c, "pagamenti", "data", "data TEXT")
      ensure_column(c, "pagamenti", "causale", "causale TEXT NOT NULL DEFAULT 'mensile'")
      ensure_column(c, "pagamenti", "due_date", "due_date TEXT")
      ensure_column(c, "pagamenti", "paid_at", "paid_at TEXT")
      ensure_column(c, "pagamenti", "metodo_pagamento", "metodo_pagamento TEXT DEFAULT ''")
      ensure_column(c, "ricevute", "data", "data TEXT")
      ensure_column(c, "ricevute", "pagamento_id", "pagamento_id INTEGER")
      ensure_column(c, "ricevute", "pdf_filename", "pdf_filename TEXT")
      ensure_column(c, "ricevute", "metodo_pagamento", "metodo_pagamento TEXT DEFAULT ''")
      ensure_column(c, "movimenti", "data", "data TEXT")
      ensure_column(c, "movimenti", "pagamento_id", "pagamento_id INTEGER")
      ensure_column(c, "movimenti", "auto_generato", "auto_generato INTEGER DEFAULT 0")
      ensure_column(c, "users", "role", "role TEXT DEFAULT 'operator'")
      ensure_column(c, "users", "active", "active INTEGER DEFAULT 1")
      ensure_column(c, "users", "full_name", "full_name TEXT DEFAULT ''")
      ensure_column(c, "users", "email", "email TEXT DEFAULT ''")
      ensure_column(c, "users", "must_change_password", "must_change_password INTEGER DEFAULT 0")
      ensure_column(c, "users", "last_login_at", "last_login_at TEXT")
      ensure_column(c, "users", "created_at", "created_at TEXT")
      ensure_column(c, "users", "updated_at", "updated_at TEXT")

      ensure_column(c, "danza_elementi", "tipo", "tipo TEXT NOT NULL DEFAULT 'trick'")
      ensure_column(c, "danza_elementi", "livello", "livello TEXT NOT NULL DEFAULT 'Livello 1'")
      ensure_column(c, "danza_elementi", "nome", "nome TEXT NOT NULL DEFAULT ''")
      ensure_column(c, "danza_elementi", "descrizione", "descrizione TEXT")
      ensure_column(c, "danza_elementi", "sequenza", "sequenza TEXT")
      ensure_column(c, "danza_elementi", "immagine", "immagine TEXT")
      ensure_column(c, "danza_elementi", "video_url", "video_url TEXT")
      ensure_column(c, "danza_elementi", "focus", "focus TEXT")
      ensure_column(c, "danza_elementi", "prerequisiti", "prerequisiti TEXT")
      ensure_column(c, "danza_elementi", "consigli", "consigli TEXT")
      ensure_column(c, "danza_elementi", "errori_comuni", "errori_comuni TEXT")
      ensure_column(c, "danza_elementi", "nota_sicurezza", "nota_sicurezza TEXT")
      ensure_column(c, "danza_elementi", "ordine", "ordine INTEGER DEFAULT 0")
      ensure_column(c, "danza_elementi", "attivo", "attivo INTEGER DEFAULT 1")
      ensure_column(c, "danza_elementi", "created_at", "created_at TEXT")
      ensure_column(c, "danza_elementi", "updated_at", "updated_at TEXT")

      ensure_column(c, "minori", "telefono_genitore", "telefono_genitore TEXT")
      ensure_column(c, "minori", "email_genitore", "email_genitore TEXT")
      ensure_column(c, "minori", "consenso_firmato", "consenso_firmato INTEGER DEFAULT 0")
      ensure_column(c, "minori", "data_consenso", "data_consenso TEXT")
      ensure_column(c, "tesserati", "luogo_nascita", "luogo_nascita TEXT")
      ensure_column(c, "tesserati", "data_nascita", "data_nascita TEXT")
      ensure_column(c, "tesserati", "codice_fiscale", "codice_fiscale TEXT")
      ensure_column(c, "tesserati", "residenza", "residenza TEXT")
      ensure_column(c, "tesserati", "email", "email TEXT")
      ensure_column(c, "tesserati", "documento_identita", "documento_identita TEXT")
      ensure_column(c, "tesserati", "tesseramento_pagato", "tesseramento_pagato INTEGER DEFAULT 0")
      ensure_column(c, "tesserati", "attivo", "attivo INTEGER DEFAULT 1")
      ensure_column(c, "tesserati", "stato", "stato TEXT DEFAULT 'attivo'")
      ensure_column(c, "minori", "tesserato_id", "tesserato_id INTEGER")
      ensure_column(c, "minori", "telefono_genitore", "telefono_genitore TEXT")
      ensure_column(c, "minori", "email_genitore", "email_genitore TEXT")
      ensure_column(c, "minori", "consenso_firmato", "consenso_firmato INTEGER DEFAULT 0")
      ensure_column(c, "minori", "data_consenso", "data_consenso TEXT")
      ensure_column(c, "minori", "note_consenso", "note_consenso TEXT")
      ensure_column(c, "documenti", "cartella", "cartella TEXT")

      ensure_column(c, "collaboratori", "telefono", "telefono TEXT")
      ensure_column(c, "collaboratori", "email", "email TEXT")
      ensure_column(c, "collaboratori", "data_nascita", "data_nascita TEXT")
      ensure_column(c, "collaboratori", "codice_fiscale", "codice_fiscale TEXT")
      ensure_column(c, "collaboratori", "ruolo", "ruolo TEXT")
      ensure_column(c, "collaboratori", "data_inizio", "data_inizio TEXT")
      ensure_column(c, "collaboratori", "attivo", "attivo INTEGER DEFAULT 1")
      ensure_column(c, "collaboratori", "note", "note TEXT")
      ensure_column(c, "collaboratori", "tipo_rapporto", "tipo_rapporto TEXT DEFAULT 'sportivo_co.co.co'")
      ensure_column(c, "collaboratori", "copertura_previdenziale", "copertura_previdenziale TEXT DEFAULT 'nessuna'")
      ensure_column(c, "collaboratori", "franchigia_inps_precedente", "franchigia_inps_precedente REAL DEFAULT 0")
      ensure_column(c, "collaboratori", "compensi_sportivi_esterni_anno", "compensi_sportivi_esterni_anno REAL DEFAULT 0")
      ensure_column(c, "collaboratori", "attivita_inps_codice", "attivita_inps_codice TEXT DEFAULT '22'")
      ensure_column(c, "collaboratori", "codice_inps_sede", "codice_inps_sede TEXT")
      ensure_column(c, "collaboratori", "matricola_inps", "matricola_inps TEXT")
      ensure_column(c, "collaboratori", "contratto_firmato", "contratto_firmato INTEGER DEFAULT 0")
      ensure_column(c, "collaboratori", "rasd_stato", "rasd_stato TEXT DEFAULT 'da_verificare'")
      ensure_column(c, "collaboratori", "rasd_data_comunicazione", "rasd_data_comunicazione TEXT")
      ensure_column(c, "collaboratori", "uniemens_stato", "uniemens_stato TEXT DEFAULT 'da_verificare'")
      ensure_column(c, "collaboratori", "data_fine", "data_fine TEXT")
      ensure_column(c, "ore_collaboratori", "mese", "mese INTEGER")
      ensure_column(c, "ore_collaboratori", "anno", "anno INTEGER")
      ensure_column(c, "ore_collaboratori", "liquidato", "liquidato INTEGER DEFAULT 0")

      dedupe_before_unique_indexes(c)

      c.execute("DROP INDEX IF EXISTS idx_pagamenti_unique")
      c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username)")
      c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_pagamenti_unique_v2 ON pagamenti(tesserato_id, mese, anno, causale)")
      c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_prenotazioni_unique ON prenotazioni(tesserato_id, corso_id, data)")
      c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_ricevute_pagamento_unique ON ricevute(pagamento_id)")
      c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_movimenti_pagamento_unique ON movimenti(pagamento_id)")
      c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_fatture_numero_anno ON fatture(numero, anno)")
      c.execute("CREATE INDEX IF NOT EXISTS idx_documenti_tesserato ON documenti(tesserato_id)")
      c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_minori_tesserato_id ON minori(tesserato_id) WHERE tesserato_id IS NOT NULL")
      c.execute("CREATE INDEX IF NOT EXISTS idx_collaboratori_ricevute_collab ON collaboratori_ricevute(collaboratore_id, anno, mese)")
      c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_collaboratori_liquidazione ON collaboratori_liquidazioni(collaboratore_id, anno, mese)")
      c.execute("CREATE INDEX IF NOT EXISTS idx_f24_sportivi_periodo ON f24_sportivi(anno, mese, sezione, codice_tributo)")
      c.execute("""CREATE UNIQUE INDEX IF NOT EXISTS idx_ore_collaboratori_unique_day ON ore_collaboratori(collaboratore_id, data)""")
      c.execute("""CREATE INDEX IF NOT EXISTS idx_ore_collaboratori_collab_data ON ore_collaboratori(collaboratore_id, data)""")
      c.execute("CREATE INDEX IF NOT EXISTS idx_danza_livello ON danza_elementi(livello)")
      c.execute("CREATE INDEX IF NOT EXISTS idx_danza_tipo ON danza_elementi(tipo)")
      c.execute("CREATE INDEX IF NOT EXISTS idx_danza_attivo_ordine ON danza_elementi(attivo, ordine, id)")
      c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_presenze_unique ON presenze(tesserato_id, corso_id, data)")
      c.execute("CREATE INDEX IF NOT EXISTS idx_presenze_data_corso ON presenze(data, corso_id)")
      c.execute("CREATE INDEX IF NOT EXISTS idx_packages_tesserato_attivo ON packages(tesserato_id, attivo)")
      c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_package_usage_unique ON package_usages(tesserato_id, corso_id, data_presenza)")

      admin = c.execute("SELECT id, password, role, active FROM users WHERE username=?", ("admin",)).fetchone()
      default_admin_password = os.environ.get("ASD_ADMIN_PASSWORD", "").strip() or "admin"
      now_str = now_iso_dt()
      if not admin:
          c.execute(
              "INSERT INTO users(username, password, role, active, must_change_password, created_at, updated_at) VALUES (?, ?, ?, 1, 1, ?, ?)",
              ("admin", generate_password_hash(default_admin_password), "admin", now_str, now_str),
          )
      else:
          pwd = admin["password"] or ""
          if not (pwd.startswith("pbkdf2:") or pwd.startswith("scrypt:")):
              c.execute("UPDATE users SET password=? WHERE id=?", (generate_password_hash(pwd), admin["id"]))
          c.execute(
              "UPDATE users SET role='admin', active=1, updated_at=? WHERE id=?",
              (now_str, admin["id"]),
          )
          # Se il solo account iniziale è ancora sulla password standard,
          # obbliga il cambio al primo accesso. Non tocca password personalizzate.
          if default_admin_password == "admin" and check_password_hash(admin["password"] or "", "admin"):
              c.execute("UPDATE users SET must_change_password=1 WHERE id=?", (admin["id"],))

      seed_default_danza(c)
      get_template_library_dir()
      conn.commit()
   finally:
      conn.close()



def ensure_workspace_ready(slug: str | None = None) -> None:
   resolved = slugify_tenant(slug or DEFAULT_TENANT_SLUG, DEFAULT_TENANT_SLUG)
   ensure_workspace_dirs(resolved)
   migrate_legacy_installation(resolved)
   init_db_for_path(get_workspace_db_path(resolved), resolved)
   cfg_path = get_workspace_config_path(resolved)
   if not cfg_path.exists():
       _old = None
       try:
           if request:
               _old = session.get("tenant_slug")
               session["tenant_slug"] = resolved
       except Exception:
           _old = None
       save_config(load_config())
       try:
           if request and _old is not None:
               session["tenant_slug"] = _old
       except Exception:
           pass


init_db = ensure_workspace_ready
ensure_workspace_ready(DEFAULT_TENANT_SLUG)


# ==============================
# UI HELPERS
# ==============================
def number_input(name: str, value="", placeholder="", step="1", min_value=None, width="180px"):
   attrs = ['type="number"', f'name="{e(name)}"', f'placeholder="{e(placeholder)}"', f'step="{e(step)}"', f'style="min-width:{width};"']
   if value != "":
       attrs.append(f'value="{e(value)}"')
   if min_value is not None:
       attrs.append(f'min="{e(min_value)}"')
   return f"<input {' '.join(attrs)}>"


def sidebar_logout_form() -> str:
   user_label = e(str(session.get("display_name") or session.get("username") or "Utente"))
   role_badge = e(role_label())
   return f"""
   <div class="card soft" style="padding:12px 14px;margin-top:14px;">
       <div style="font-size:12px;color:var(--text-dim);text-transform:uppercase;letter-spacing:.08em;">Sessione attiva</div><div class='small-muted' style='margin-top:4px;'>Workspace locale</div>
       <div style="font-weight:900;margin-top:4px;">{user_label}</div>
       <div class="small-muted">Ruolo: {role_badge}</div>
       <div class="actions" style="margin-top:10px;">
           <a href="/profilo" class="nav-link" style="padding:10px 12px;">Profilo</a>
       </div>
   </div>
   <form method="POST" action="/logout" style="margin:10px 0 0 0;">
       {csrf_input()}
       <button style="width:100%;text-align:left;background:rgba(255,255,255,.04);color:var(--text-light);border:1px solid transparent;box-shadow:none;font-weight:800;">↩ Logout</button>
   </form>
   """






def layout(content: str) -> str:
   cfg = load_config()
   branding_cfg = cfg.get("branding", {}) if isinstance(cfg.get("branding"), dict) else {}
   def _theme_hex(value: str, fallback: str) -> str:
       value = str(value or "").strip()
       if re.match(r"^#[0-9a-fA-F]{6}$", value):
           return value
       return fallback
   tenant_accent = _theme_hex(branding_cfg.get("accent_color") or cfg.get("accent_color"), "#38bdf8")
   tenant_accent_2 = _theme_hex(branding_cfg.get("accent_color_2") or cfg.get("accent_color_2"), "#22c55e")
   tenant_warning = _theme_hex(branding_cfg.get("warning_color") or cfg.get("warning_color"), "#facc15")
   tenant_title_theme = (
       "<style id='tenant-title-theme'>"
       f":root{{--tenant-accent:{tenant_accent};--tenant-accent-2:{tenant_accent_2};--tenant-warning:{tenant_warning};}}"
       "</style>"
   )
   status_summary = get_page_status_summary() if auth() else {"tone": "ok", "label": "", "detail": ""}
   bg_css = "background:#09111f;"
   if cfg.get("background"):
       bg_css = (
           "background-image:"
           "linear-gradient(rgba(4, 10, 18, .70), rgba(4, 10, 18, .78)),"
           f"url('{file_url(cfg['background'])}');"
           "background-size: cover;"
           "background-position: center;"
           "background-attachment: fixed;"
       )

   logo_html = ""
   sidebar_logo = cfg.get("logo") or "default_asd_logo.png"
   if sidebar_logo:
       logo_html = (
           f"<img src='{file_url(sidebar_logo)}' onerror=\"this.style.display='none'\" "
           "class='a5-brand-logo' style='width:100%;max-width:172px;border-radius:22px;margin-bottom:14px;border:1px solid rgba(56,189,248,.18);box-shadow:0 12px 32px rgba(0,0,0,.26);background:rgba(7,12,22,.55);padding:10px;'>"
       )

   current_path = (request.path or "/").rstrip("/") or "/"

   def menu_icon(icon_key: str) -> str:
       icons = {
           "dashboard": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 13.5 12 5l9 8.5"/><path d="M5.5 11.5V20h13V11.5"/><path d="M9.5 20v-5h5v5"/></svg>',
           "users": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M16.5 19a4.5 4.5 0 0 0-9 0"/><circle cx="12" cy="8" r="3.25"/><path d="M18.5 17.5a3.5 3.5 0 0 1 2.5-5.5"/><path d="M3 12a3.5 3.5 0 0 1 2.5 5.5"/></svg>',
           "calendar": '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M7.5 3.5v3"/><path d="M16.5 3.5v3"/><path d="M3.5 9.5h17"/></svg>',
           "check_circle": '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="m8.5 12 2.3 2.3 4.7-4.8"/></svg>',
           "shield_user": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.5 18.5 6v5.3c0 4.1-2.4 6.9-6.5 9.2C7.9 18.2 5.5 15.4 5.5 11.3V6Z"/><circle cx="12" cy="9.2" r="2.1"/><path d="M8.8 15.6a4.1 4.1 0 0 1 6.4 0"/></svg>',
           "teacher": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8.2 12 4l8 4.2-8 4.1-8-4.1Z"/><path d="M8 10.5v3.3c0 1.8 1.8 3.2 4 3.2s4-1.4 4-3.2v-3.3"/><path d="M19 9v4.5"/><path d="M18 14.8a1 1 0 1 0 2 0 1 1 0 0 0-2 0Z"/></svg>',
           "receipt": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3.5h10v17l-2-1.3-2 1.3-2-1.3-2 1.3-2-1.3-2 1.3v-17Z"/><path d="M9 8.5h6"/><path d="M9 12h6"/><path d="M9 15.5h4"/></svg>',
           "card": '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="6" width="17" height="12" rx="2.5"/><path d="M3.5 10h17"/><path d="M7.5 14.5h3"/></svg>',
           "globe": '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M3.8 12h16.4"/><path d="M12 3.5a13 13 0 0 1 0 17"/><path d="M12 3.5a13 13 0 0 0 0 17"/></svg>',
           "doc": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3.5h6l4 4V20.5H8a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2Z"/><path d="M14 3.5v4h4"/><path d="M9.5 12h5"/><path d="M9.5 15.5h5"/></svg>',
           "bolt": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M13.5 3.5 7.5 12h4l-1 8.5 6-9h-4l1-8Z"/></svg>',
           "bell": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 15.5h11l-1.3-1.6a4.9 4.9 0 0 1-1.2-3.1V10a3 3 0 1 0-6 0v.8c0 1.1-.4 2.2-1.2 3.1Z"/><path d="M10 18.5a2.2 2.2 0 0 0 4 0"/></svg>',
           "chart": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 18.5h15"/><path d="M7.5 15.5v-3.8"/><path d="M12 15.5V8"/><path d="M16.5 15.5v-5.5"/><path d="m6.8 10.2 4-3.2 3.3 2.4 3.1-3.3"/></svg>',
           "database": '<svg viewBox="0 0 24 24" aria-hidden="true"><ellipse cx="12" cy="6.5" rx="6.5" ry="2.8"/><path d="M5.5 6.5v5c0 1.6 2.9 2.8 6.5 2.8s6.5-1.2 6.5-2.8v-5"/><path d="M5.5 11.5v5c0 1.6 2.9 2.8 6.5 2.8s6.5-1.2 6.5-2.8v-5"/></svg>',
           "settings": '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M12 4.5v2.2"/><path d="M12 17.3v2.2"/><path d="M4.5 12h2.2"/><path d="M17.3 12h2.2"/><path d="m6.7 6.7 1.6 1.6"/><path d="m15.7 15.7 1.6 1.6"/><path d="m15.7 8.3 1.6-1.6"/><path d="m6.7 17.3 1.6-1.6"/></svg>',
           "user": '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.2"/><path d="M6.5 18.5a5.5 5.5 0 0 1 11 0"/></svg>',
           "ring": '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="7.5"/><path d="M12 4.5v3"/><path d="M18.5 12h-3"/><path d="M15.8 6.2 14 8"/></svg>',
           "target": '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="7.5"/><circle cx="12" cy="12" r="3.2"/><path d="M12 2.8v2.6"/><path d="M21.2 12h-2.6"/></svg>',
       }
       return icons.get(icon_key, icons["doc"])

   def nav_link(
       href: str,
       label: str,
       icon: str,
       aliases: tuple[str, ...] = (),
       tier: str = "standard",
       title: str = "",
       badge: str = "",
   ) -> str:
       normalized_href = href.rstrip("/") or "/"
       normalized_aliases = {(a.rstrip("/") or "/") for a in aliases}
       is_active = current_path == normalized_href or current_path in normalized_aliases
       safe_tier = tier if tier in {"primary", "secondary", "technical", "money", "standard"} else "standard"
       cls = f"nav-link nav-{safe_tier}" + (" active" if is_active else "")
       hint = title or label
       badge_html = ""
       return (
           f"<a href='{href}' class='{cls}' title='{e(hint)}' aria-label='{e(label + ' - ' + hint if hint != label else label)}' data-tooltip='{e(hint)}'>"
           f"<span class='nav-icon'>{menu_icon(icon)}</span>"
           f"<span class='nav-copy'><span class='nav-label'>{e(label)}</span>{badge_html}</span>"
           "</a>"
       )

   def nav_dropdown(title: str, icon: str, children_html: str, section_key: str = "") -> str:
       if not children_html.strip():
           return ""
       active = " open active" if " active" in children_html else ""
       key_attr = f" data-section='{e(section_key)}'" if section_key else ""
       return (
           f"<details class='nav-dropdown{active}' open{key_attr}>"
           f"<summary><span class='nav-icon'>{menu_icon(icon)}</span>"
           f"<span class='nav-copy'><span class='nav-label'>{e(title)}</span></span>"
           "<span class='nav-chevron'>⌄</span></summary>"
           f"<div class='nav-sub'>{children_html}</div>"
           "</details>"
       )

   style_block = """
<style>
:root {
   --bg-card: rgba(10,18,32,0.84);
   --bg-card-soft: rgba(15,23,42,0.68);
   --bg-sidebar: rgba(7,12,22,0.92);
   --bg-input: rgba(248,250,252,0.98);
   --text-dark: #0f172a;
   --text-light: #e8f0ff;
   --text-soft: rgba(232,240,255,.72);
   --text-dim: rgba(232,240,255,.56);
   --accent: #38bdf8;
   --accent-2: #60a5fa;
   --accent-3: #22d3ee;
   --danger: #ef4444;
   --danger-dark: #dc2626;
   --success: #16a34a;
   --border: rgba(148,163,184,.18);
   --shadow: 0 18px 50px rgba(0,0,0,.28);
   --shadow-soft: 0 10px 28px rgba(0,0,0,.18);
   --radius: 20px;
}
* { box-sizing:border-box; }
html { scroll-behavior:smooth; }
body {
   margin:0;
   font-family: Inter, Arial, Helvetica, sans-serif;
   color:var(--text-light);
   letter-spacing:.01em;
""" + bg_css + """
}
a { color:#96e0ff; text-decoration:none; transition:.18s ease; }
a:hover { color:#d7f4ff; }
.overlay {
   min-height:100vh;
   background:
      radial-gradient(circle at top right, rgba(56,189,248,.10), transparent 28%),
      radial-gradient(circle at top left, rgba(96,165,250,.08), transparent 26%),
      linear-gradient(180deg, rgba(1,6,14,.18), rgba(1,6,14,.36));
}
.shell { display:flex; min-height:100vh; }
.sidebar {
   width:304px;
   position:fixed;
   top:0;
   left:0;
   height:100vh;
   padding:22px 18px 20px;
   overflow:auto;
   scrollbar-width:thin;
   background:
      radial-gradient(circle at 50% -8%, rgba(56,189,248,.12), transparent 34%),
      linear-gradient(180deg, rgba(15,23,42,.98), rgba(7,12,22,.95));
   border-right:1px solid rgba(255,255,255,.06);
   backdrop-filter: blur(18px);
   box-shadow: inset -1px 0 0 rgba(255,255,255,.03), 18px 0 36px rgba(0,0,0,.18);
}
.sidebar::after{
   content:'';
   position:sticky;
   display:block;
   left:14px;
   right:14px;
   bottom:0;
   height:1px;
   margin-top:16px;
   background:linear-gradient(90deg, rgba(56,189,248,0), rgba(56,189,248,.72), rgba(56,189,248,0));
   box-shadow:0 0 14px rgba(56,189,248,.22);
   opacity:.92;
}
.sidebar h2 {
   margin:0 0 4px 0;
   font-size:1.18rem;
   letter-spacing:.15px;
   line-height:1.22;
}
.sidebar .sidebar-subtitle{font-size:12px;color:var(--text-dim);margin-bottom:18px;line-height:1.5;max-width:242px;}
.sidebar .nav-group { display:flex; flex-direction:column; gap:8px; }
.sidebar-logo-shell{
   width:100%;
   display:flex;
   align-items:center;
   justify-content:center;
   padding:14px 12px;
   margin-bottom:16px;
   border-radius:24px;
   border:1px solid rgba(56,189,248,.18);
   background:linear-gradient(180deg, rgba(9,16,29,.86), rgba(6,13,24,.72));
   box-shadow:0 18px 38px rgba(0,0,0,.30), inset 0 1px 0 rgba(255,255,255,.05);
}
.sidebar-logo-img{
   width:100%;
   max-width:196px;
   height:auto;
   display:block;
   border-radius:18px;
}
.menu-section {
   margin:20px 8px 6px;
   font-size:10px;
   font-weight:900;
   letter-spacing:.18em;
   text-transform:uppercase;
   color:#8fdcff;
   opacity:.95;
}
.nav-link, .sidebar form button {
   min-height:54px;
   display:flex;
   align-items:center;
   gap:11px;
   padding:11px 13px;
   color:var(--text-light);
   text-decoration:none;
   border-radius:14px;
   background:rgba(255,255,255,.035);
   border:1px solid transparent;
   transition:transform .18s ease, background .18s ease, border-color .18s ease, box-shadow .18s ease, color .18s ease;
   font-size:14px;
   font-family:inherit;
   position:relative;
   overflow:hidden;
}
.nav-link::after, .sidebar form button::after {
   content:'';
   position:absolute;
   left:0;
   right:0;
   bottom:0;
   height:1px;
   background:linear-gradient(90deg, rgba(56,189,248,0), rgba(56,189,248,.52) 18%, rgba(125,211,252,.94) 50%, rgba(56,189,248,.52) 82%, rgba(56,189,248,0));
   opacity:0;
   transform:scaleX(.86);
   transition:opacity .18s ease, transform .18s ease;
}
.nav-link:hover, .sidebar form button:hover {
   transform:translateX(3px);
   background:rgba(255,255,255,.05);
   border-color:rgba(56,189,248,.20);
   color:white;
   box-shadow:0 14px 26px rgba(0,0,0,.18);
}
.nav-link:hover::after, .sidebar form button:hover::after {
   opacity:.9;
   transform:scaleX(1);
}

.nav-link.active {
   background:linear-gradient(90deg, rgba(56,189,248,.16), rgba(56,189,248,.04), transparent);
   border-color:rgba(96,165,250,.28);
   border-left:3px solid #38bdf8;
   color:white;
   box-shadow:0 14px 26px rgba(56,189,248,.12);
}
.nav-link.active::after {
   opacity:1;
   transform:scaleX(1);
   background:linear-gradient(90deg, rgba(56,189,248,0), rgba(56,189,248,.74) 18%, rgba(125,211,252,1) 50%, rgba(56,189,248,.74) 82%, rgba(56,189,248,0));
   box-shadow:0 0 12px rgba(56,189,248,.24);
}

.nav-icon {
   width:32px;
   height:32px;
   display:inline-flex;
   align-items:center;
   justify-content:center;
   text-align:center;
   flex:0 0 32px;
   font-size:15px;
   color:rgba(255,255,255,.75);
   border-radius:12px;
   background:linear-gradient(180deg, rgba(255,255,255,.08), rgba(255,255,255,.03));
   border:1px solid rgba(255,255,255,.10);
   box-shadow:inset 0 1px 0 rgba(255,255,255,.06), 0 8px 18px rgba(0,0,0,.18);
}
.nav-link.active .nav-icon {
   background:linear-gradient(180deg, rgba(56,189,248,.28), rgba(96,165,250,.14));
   border-color:rgba(96,165,250,.35);
   color:#38bdf8;
}
.nav-icon svg {
   width:17px;
   height:17px;
   stroke:currentColor;
   fill:none;
   stroke-width:1.5;
   stroke-linecap:round;
   stroke-linejoin:round;
}
.nav-label { flex:1; font-weight:760; letter-spacing:.01em; }
.nav-badge {
   min-width:20px;
   padding:2px 7px;
   border-radius:999px;
   background:rgba(239,68,68,.18);
   border:1px solid rgba(239,68,68,.24);
   color:#fecaca;
   font-size:11px;
   font-weight:800;
   text-align:center;
}

.overlay{animation:fadeApp .36s ease;}
.content {
   margin-left:304px;
   padding:28px 28px 28px;
   width:calc(100% - 304px);
}
.card, .stat-card, .hero-panel, .list-shell, .drawer-card, .card-elevated {
   animation:fadeCard .42s ease both;
}
@keyframes fadeApp {
   from { opacity:0; transform:scale(.996); }
   to { opacity:1; transform:scale(1); }
}
@keyframes fadeCard {
   from { opacity:0; transform:translateY(8px); }
   to { opacity:1; transform:translateY(0); }
}
.page-head {
   display:flex;
   flex-wrap:wrap;
   gap:18px;
   align-items:center;
   justify-content:space-between;
   margin-bottom:20px;
}
.card {
   background:linear-gradient(180deg, rgba(12,20,35,.82), rgba(10,18,32,.76));
   border:1px solid var(--border);
   backdrop-filter: blur(14px);
   padding:20px;
   border-radius:var(--radius);
   margin-bottom:18px;
   box-shadow: var(--shadow);
}
.card.soft { background:linear-gradient(180deg, rgba(15,23,42,.72), rgba(15,23,42,.60)); }
.grid-2 {
   display:grid;
   grid-template-columns: repeat(2, minmax(0, 1fr));
   gap:18px;
}
.stats-grid {
   display:grid;
   grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
   gap:18px;
}
.stat-card {
   min-height:132px;
   position:relative;
   padding:18px;
   border-radius:18px;
   background:linear-gradient(180deg, rgba(18,27,46,.92), rgba(11,18,32,.85));
   border:1px solid rgba(96,165,250,.14);
   box-shadow: var(--shadow-soft);
   transition:transform .18s ease, border-color .18s ease, box-shadow .18s ease;
}
.stat-card:hover{transform:translateY(-1px);border-color:rgba(96,165,250,.20);}
.stat-card.kpi-primary{background:linear-gradient(180deg, rgba(10,18,34,.96), rgba(7,14,26,.88));}
.stat-card.kpi-critical{background:linear-gradient(180deg, rgba(28,12,18,.92), rgba(12,12,22,.86));}
.stat-card .label {
   max-width:85%; font-size:.94rem; color:var(--text-soft); }
.stat-card .value { margin-top:8px; font-size:1.9rem; font-weight:900; line-height:1; }
.stat-card .status-dot{position:absolute;top:16px;right:16px;width:10px;height:10px;border-radius:50%;background:transparent;box-shadow:none;} 
.stat-card.alert-red .status-dot{background:#ef4444;box-shadow:0 0 14px rgba(239,68,68,.8);} 
.stat-card.alert-yellow .status-dot{background:#facc15;box-shadow:0 0 14px rgba(250,204,21,.7);} 
.stat-card.alert-green .status-dot{background:#22c55e;box-shadow:0 0 12px rgba(34,197,94,.5);} 
.stat-card.alert-red{border-color:rgba(239,68,68,.28);} 
.stat-card.alert-yellow{border-color:rgba(250,204,21,.24);} 
.stat-card.alert-green{border-color:rgba(34,197,94,.22);}
.stat-card-featured{min-height:146px;padding:24px 22px 20px;}
.stat-card.stat-main{min-height:172px;padding:26px 24px 22px;background:linear-gradient(180deg, rgba(13,24,44,.98), rgba(7,15,30,.88));border-color:rgba(56,189,248,.26);box-shadow:0 22px 44px rgba(0,0,0,.24), 0 0 0 1px rgba(56,189,248,.08) inset;}
.stat-card.stat-main .value{font-size:2.35rem;}
.stat-card.stat-main .label{font-size:.8rem;letter-spacing:.12em;}
.stat-card.stat-main .stat-meta{margin-top:12px;}
.stats-grid-featured{grid-template-columns:repeat(4,minmax(0,1fr));margin-bottom:12px;}
.stats-grid-secondary{grid-template-columns:repeat(5,minmax(0,1fr));}
.stat-meta{max-width:90%;}
.card-alerts{border-color:rgba(56,189,248,.14);}
.card-automation{background:linear-gradient(180deg, rgba(10,22,38,.92), rgba(8,18,30,.86));}
.hero-banner-dashboard{padding-bottom:24px;}
.form-row { display:flex; flex-wrap:wrap; gap:12px; align-items:flex-end; }
.form-col { display:flex; flex-direction:column; gap:6px; min-width:200px; }
input, button, select, textarea {
   padding:12px 13px;
   border-radius:14px;
   border:none;
   font-size:14px;
   font-family:inherit;
}
input, select, textarea {
   min-width:180px;
   background:var(--bg-input);
   color:var(--text-dark);
   border:1px solid rgba(15,23,42,.10);
   box-shadow: inset 0 1px 1px rgba(255,255,255,.35);
}
input:focus, select:focus, textarea:focus {
   outline:none;
   border-color:rgba(56,189,248,.55);
   box-shadow:0 0 0 4px rgba(56,189,248,.12);
}
textarea { min-height:110px; width:min(760px, 100%); resize:vertical; }
button {
   background:linear-gradient(180deg, var(--accent), var(--accent-2));
   color:#06111d;
   cursor:pointer;
   font-weight:900;
   border:1px solid rgba(255,255,255,.14);
   box-shadow:0 12px 28px rgba(56,189,248,.22);
   transition:.18s ease;
}
button:hover { transform:translateY(-1px); filter:brightness(1.04); box-shadow:0 10px 24px rgba(0,0,0,.28); }
button.danger {
   background:linear-gradient(180deg, var(--danger), var(--danger-dark));
   color:white;
   box-shadow:0 12px 28px rgba(239,68,68,.22);
}
table {
   width:100%;
   border-collapse:separate;
   border-spacing:0;
   margin-top:12px;
   overflow:hidden;
   border-radius:16px;
   background:rgba(2,6,14,.24);
   border:1px solid rgba(255,255,255,.08);
}
thead th, th {
   background:rgba(255,255,255,.05);
   font-size:12px;
   text-transform:uppercase;
   letter-spacing:.07em;
   color:#bfeaff;
}
tbody tr { transition:background .16s ease; }
tbody tr:hover { background:rgba(255,255,255,.035); }
td, th {
   border-bottom:1px solid rgba(255,255,255,.06);
   padding:12px 11px;
   text-align:left;
   vertical-align:top;
}
tr:last-child td { border-bottom:none; }
.small-muted { color:var(--text-soft); font-size:14px; }
.badge, .pill {
   display:inline-block;
   padding:6px 10px;
   border-radius:999px;
   font-size:11px;
   font-weight:900;
   background:#334155;
   color:#f8fafc;
   letter-spacing:.03em;
}
.badge-dot{
   display:inline-block;
   width:10px;height:10px;border-radius:50%;
   margin-right:8px;vertical-align:middle;
}
.dot-red{background:#ef4444; box-shadow:0 0 12px rgba(239,68,68,.85);}
.dot-yellow{background:#facc15; box-shadow:0 0 12px rgba(250,204,21,.70);}
.dot-green{background:#22c55e; box-shadow:0 0 10px rgba(34,197,94,.45);}
.live-alert{
   display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:14px;
   border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.04);margin-bottom:10px;
}
.live-alert.red{border-color:rgba(239,68,68,.38); background:rgba(127,29,29,.22);}
.live-alert.yellow{border-color:rgba(250,204,21,.30); background:rgba(120,53,15,.18);}
.live-alert.green{border-color:rgba(34,197,94,.28); background:rgba(20,83,45,.18);}
.badge.valido { background:#14532d; color:#dcfce7; }
.badge.scaduto { background:#7f1d1d; color:#fee2e2; }
.badge.in_scadenza { background:#78350f; color:#fef3c7; }
.badge.mancante, .badge.non_valido { background:#374151; color:#f3f4f6; }
.inline-form { display:inline; margin:0; }
.actions { display:flex; flex-wrap:wrap; gap:8px; align-items:center; }
.section-title { margin:0 0 10px 0; font-size:1.24rem; font-weight:900; }
hr {
   border:none;
   border-top:1px solid rgba(255,255,255,.10);
   margin:18px 0;
   width:100%;
}
.footer-note { color:var(--text-dim); font-size:13px; }
.empty-state {
   padding:28px;
   text-align:center;
   border-radius:18px;
   border:1px dashed rgba(255,255,255,.14);
   background:linear-gradient(180deg, rgba(255,255,255,.035), rgba(255,255,255,.02));
   color:rgba(232,240,255,.62);
   box-shadow:inset 0 1px 0 rgba(255,255,255,.03);
}
.empty-state strong{display:block;color:#e8f0ff;font-size:1rem;margin-bottom:6px;}
.kicker {
   color:#9ddcff;
   text-transform:uppercase;
   letter-spacing:.15em;
   font-size:.74rem;
   font-weight:900;
   margin-bottom:4px;
}
.thumb-60 {
   width:60px; height:60px; object-fit:cover; border-radius:12px; background:#0f172a;
   border:1px solid rgba(255,255,255,.08);
}
.hero-banner {
   position:relative;
   padding:28px;
   border-radius:24px;
   margin-bottom:20px;
   background:linear-gradient(135deg, rgba(56,189,248,.18), rgba(96,165,250,.10), rgba(15,23,42,.88));
   border:1px solid rgba(96,165,250,.28);
   box-shadow:var(--shadow);
}
.hero-title { margin:0 0 8px 0; font-size:2.2rem; font-weight:900; }
.hero-subtitle { max-width:760px; color:var(--text-soft); line-height:1.5; }
.quick-grid {
   display:grid;
   grid-template-columns:repeat(auto-fit,minmax(210px,1fr));
   gap:14px;
   margin-top:18px;
}
.quick-link {
   display:flex;
   flex-direction:column;
   gap:6px;
   padding:16px;
   border-radius:18px;
   background:rgba(255,255,255,.05);
   border:1px solid rgba(255,255,255,.08);
   box-shadow:var(--shadow-soft);
}
.quick-link:hover {
   transform:translateY(-2px);
   background:rgba(56,189,248,.14);
   border-color:rgba(56,189,248,.22);
}
.panel-grid {
   display:grid;
   grid-template-columns:repeat(2, minmax(0, 1fr));
   gap:18px;
}
.list-card { min-height:100%; }
.list-head {
   display:flex;
   gap:12px;
   align-items:center;
   justify-content:space-between;
   margin-bottom:10px;
}
.clean-list {
   list-style:none;
   padding:0;
   margin:0;
   display:flex;
   flex-direction:column;
   gap:10px;
}
.clean-list li {
   display:flex;
   align-items:center;
   justify-content:space-between;
   gap:14px;
   padding:14px 16px;
   border-radius:16px;
   background:rgba(255,255,255,.03);
   border:1px solid rgba(255,255,255,.06);
}
.value-euro { background:rgba(34,197,94,.18); color:#dcfce7; }

.app-section-hero {
   position:relative;
   overflow:hidden;
   padding:24px 24px 22px;
   border-radius:24px;
   margin-bottom:18px;
   background:linear-gradient(135deg, rgba(56,189,248,.12), rgba(96,165,250,.08), rgba(15,23,42,.82));
   border:1px solid rgba(96,165,250,.18);
   box-shadow:var(--shadow);
}
.app-section-hero .section-title{font-size:1.5rem;margin-bottom:6px;}
.metric-strip{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:18px;}
.metric-strip .metric-box{padding:16px 18px;border-radius:18px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);}
.metric-strip .metric-box .label{font-size:12px;color:var(--text-dim);text-transform:uppercase;letter-spacing:.08em;font-weight:800;}
.metric-strip .metric-box .value{margin-top:8px;font-size:1.5rem;font-weight:900;line-height:1;}
.table-toolbar{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;margin-bottom:14px;}
.table-toolbar .small-muted{max-width:760px;}
.form-panel{background:linear-gradient(180deg, rgba(255,255,255,.035), rgba(255,255,255,.025));border:1px solid rgba(255,255,255,.07);border-radius:18px;padding:16px;}

.file-chip{
   display:inline-flex;
   align-items:center;
   max-width:280px;
   padding:7px 10px;
   border-radius:999px;
   background:rgba(255,255,255,.06);
   border:1px solid rgba(255,255,255,.08);
   color:var(--text-light);
   font-size:13px;
   font-weight:700;
   white-space:nowrap;
   overflow:hidden;
   text-overflow:ellipsis;
}
.page-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px;}

.quick-link{position:relative;overflow:hidden;}
.quick-link strong{font-size:1rem;}
.quick-link::after{content:"";position:absolute;inset:auto -20% -40% auto;width:140px;height:140px;background:radial-gradient(circle, rgba(56,189,248,.22), rgba(56,189,248,0) 65%);pointer-events:none;transition:transform .22s ease, opacity .22s ease;opacity:.75;transform:scale(.92);}
.quick-link:hover::after{opacity:1;transform:scale(1.08);}
.quick-link:hover strong{color:#e6f7ff;}
.cta-primary,.cta-secondary,.filter-chip{display:inline-flex;align-items:center;gap:8px;padding:11px 15px;border-radius:14px;font-weight:900;line-height:1;text-decoration:none;border:1px solid rgba(255,255,255,.1);}
.cta-primary{background:linear-gradient(180deg, rgba(56,189,248,.96), rgba(14,165,233,.85));color:#06111d;box-shadow:0 12px 26px rgba(56,189,248,.28);}
.cta-primary:hover{transform:translateY(-1px);filter:brightness(1.03);}
.cta-secondary{background:rgba(255,255,255,.04);color:#eef7ff;box-shadow:0 0 0 1px rgba(56,189,248,.16), 0 0 18px rgba(56,189,248,.12) inset;}
.cta-secondary:hover{background:rgba(56,189,248,.10);border-color:rgba(56,189,248,.26);}
.filter-chip{background:rgba(255,255,255,.04);color:#d7e9ff;border-color:rgba(255,255,255,.08);box-shadow:none;cursor:default;}
.inline-guide{margin-top:12px;padding:12px 14px;border-radius:16px;background:linear-gradient(180deg, rgba(255,255,255,.04), rgba(255,255,255,.025));border:1px solid rgba(255,255,255,.08);}
.inline-guide strong{display:block;margin-bottom:6px;}
.inline-guide ol{margin:0 0 0 18px;padding:0;display:flex;flex-direction:column;gap:4px;color:var(--text-soft);}
.inline-guide p{margin:6px 0 0 0;color:var(--text-dim);font-size:13px;}
.message-box{min-width:280px;max-width:460px;white-space:pre-wrap;line-height:1.45;padding:12px 14px;border-radius:14px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.07);color:#e9f1ff;}
.status-badges{display:flex;flex-wrap:wrap;gap:6px;}
.badge.badge-soft{background:rgba(255,255,255,.07);color:#eef7ff;}
.table-fixed{table-layout:fixed;}
.table-fixed td,.table-fixed th{word-wrap:break-word;}
.tab-switch{display:flex;flex-wrap:wrap;gap:10px;margin:8px 0 14px 0;}
.tab-switch a{display:inline-flex;align-items:center;gap:8px;padding:10px 14px;border-radius:14px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);font-weight:800;}
.tab-switch a.active{background:linear-gradient(180deg, rgba(56,189,248,.16), rgba(56,189,248,.08));border-color:rgba(56,189,248,.30);color:#dff6ff;box-shadow:0 0 0 1px rgba(56,189,248,.14) inset;}
.toolbar-actions{display:flex;flex-wrap:wrap;gap:10px;align-items:center;}
.section-stack{display:flex;flex-direction:column;gap:18px;}
.info-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;}
.info-card{padding:16px 18px;border-radius:18px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.08);}
.info-card strong{display:block;margin-bottom:6px;}
.table-note{margin-top:8px;font-size:12px;color:var(--text-dim);}
.form-hint{display:block;margin-top:6px;font-size:12px;color:var(--text-dim);line-height:1.55;}
.card-elevated{background:linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,.025));border:1px solid rgba(255,255,255,.08);box-shadow:var(--shadow-soft);} 
.compact-help{font-size:12px;color:var(--text-dim);line-height:1.55;}

.card-grid-3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;}
@media (max-width: 1100px) { .card-grid-3{grid-template-columns:1fr;} }
.global-status-wrap{margin-bottom:14px;}
.global-status-bar{height:6px;border-radius:999px;background:rgba(255,255,255,.06);overflow:hidden;border:1px solid rgba(255,255,255,.08);box-shadow:inset 0 1px 0 rgba(255,255,255,.04);}
.global-status-bar > span{display:block;height:100%;width:100%;}
.global-status-bar.ok > span{background:linear-gradient(90deg, rgba(34,197,94,0), rgba(16,185,129,.36) 18%, rgba(5,46,22,.92) 50%, rgba(16,185,129,.36) 82%, rgba(34,197,94,0));box-shadow:0 0 18px rgba(34,197,94,.28);}
.global-status-bar.warning > span{background:linear-gradient(90deg, rgba(250,204,21,0), rgba(245,158,11,.34) 18%, rgba(69,26,3,.92) 50%, rgba(245,158,11,.34) 82%, rgba(250,204,21,0));box-shadow:0 0 18px rgba(250,204,21,.24);}
.global-status-bar.error > span{background:linear-gradient(90deg, rgba(239,68,68,0), rgba(220,38,38,.34) 18%, rgba(69,10,10,.95) 50%, rgba(220,38,38,.34) 82%, rgba(239,68,68,0));box-shadow:0 0 18px rgba(239,68,68,.28);}
.global-status-meta{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-top:8px;font-size:12px;color:var(--text-dim);}
.global-status-badge{display:inline-flex;align-items:center;gap:8px;padding:6px 10px;border-radius:999px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06);color:var(--text-soft);font-weight:800;}
.global-status-badge.ok{border-color:rgba(34,197,94,.22);color:#dcfce7;background:rgba(20,83,45,.18);}
.global-status-badge.warning{border-color:rgba(250,204,21,.22);color:#fef3c7;background:rgba(120,53,15,.18);}
.global-status-badge.error{border-color:rgba(239,68,68,.22);color:#fee2e2;background:rgba(127,29,29,.20);}
.drawer-shell{position:fixed;inset:0;display:none;z-index:1200;}
.drawer-shell.open{display:block;}
.drawer-backdrop{position:absolute;inset:0;background:rgba(2,6,14,.58);backdrop-filter:blur(6px);}
.drawer-panel{position:absolute;top:0;right:0;height:100%;width:min(920px,96vw);padding:20px 20px 28px;background:linear-gradient(180deg, rgba(9,16,29,.98), rgba(6,13,24,.96));border-left:1px solid rgba(255,255,255,.08);box-shadow:-24px 0 46px rgba(0,0,0,.35);overflow:auto;}
.drawer-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:14px;}
.drawer-head .section-title{margin-bottom:4px;}
.drawer-close{display:inline-flex;align-items:center;justify-content:center;min-width:42px;height:42px;border-radius:14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);color:#fff;font-size:22px;font-weight:700;}
.drawer-close:hover{background:rgba(255,255,255,.08);}
.compact-grid{display:grid;grid-template-columns:2fr 1fr 1fr;gap:18px;align-items:start;}
.compact-stat-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;}
.mini-card{padding:16px 18px;border-radius:18px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.08);}
.table-row-ok{background:linear-gradient(90deg, rgba(34,197,94,.08), transparent 28%);}
.table-row-warning{background:linear-gradient(90deg, rgba(250,204,21,.10), transparent 28%);}
.table-row-error{background:linear-gradient(90deg, rgba(239,68,68,.11), transparent 32%);}
@media (max-width: 1280px){.compact-grid{grid-template-columns:1fr;}.compact-stat-grid{grid-template-columns:repeat(2,minmax(0,1fr));}.drawer-panel{width:min(980px,100vw);}}
@media (max-width: 820px){.compact-stat-grid{grid-template-columns:1fr;}.drawer-panel{padding:16px 14px 24px;}}

@media (max-width: 1024px) {
   .sidebar {
      position:relative;
      width:100%;
      height:auto;
      border-right:none;
      border-bottom:1px solid rgba(255,255,255,.08);
   }
   .shell { display:block; }
   .content { width:100%; margin-left:0; }
}
@media (max-width: 1100px) {
   .stats-grid-featured{grid-template-columns:repeat(2,minmax(0,1fr));}
   .stats-grid-secondary{grid-template-columns:repeat(3,minmax(0,1fr));}
}
@media (max-width: 740px) {
   .stats-grid-featured,.stats-grid-secondary{grid-template-columns:1fr;}
   .grid-2, .panel-grid { grid-template-columns: 1fr; }
   .content { padding:16px; }
   .card, .hero-banner { padding:16px; border-radius:18px; }
   table { display:block; overflow-x:auto; }
   .hero-title { font-size:1.7rem; }
}
.sidebar-brand{position:sticky;top:0;padding-bottom:12px;margin-bottom:10px;background:linear-gradient(180deg, rgba(15,23,42,.98), rgba(15,23,42,.88), rgba(15,23,42,0));z-index:3;}
.sidebar-brand::after{content:'';display:block;height:1px;margin-top:12px;background:linear-gradient(90deg, rgba(56,189,248,0), rgba(56,189,248,.76), rgba(56,189,248,0));box-shadow:0 0 12px rgba(56,189,248,.18);}
.sidebar-brand .kicker{margin-bottom:6px;}
.brand-chip{display:inline-flex;align-items:center;gap:9px;padding:7px 12px;border-radius:999px;background:rgba(56,189,248,.10);border:1px solid rgba(56,189,248,.16);color:#c5efff;font-size:11px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;margin-bottom:12px;}
.brand-chip-icon{width:18px;height:18px;display:inline-flex;align-items:center;justify-content:center;color:#d9f6ff;}
.brand-chip-icon svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
.help-fab{position:fixed;right:26px;bottom:26px;z-index:1300;width:54px;height:54px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:900;color:#06111d;background:linear-gradient(180deg, #7dd3fc, #38bdf8);border:1px solid rgba(255,255,255,.24);box-shadow:0 18px 32px rgba(0,0,0,.28),0 0 0 1px rgba(56,189,248,.12) inset, 0 0 22px rgba(56,189,248,.18);cursor:pointer;transition:transform .16s ease, filter .16s ease, box-shadow .16s ease;}
.help-fab:hover{transform:translateY(-2px);filter:brightness(1.03);box-shadow:0 18px 32px rgba(0,0,0,.28),0 0 0 1px rgba(56,189,248,.12) inset, 0 0 28px rgba(56,189,248,.24);}
.tutorial-overlay{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(2,6,14,.72);backdrop-filter:blur(8px);z-index:1400;padding:20px;}
.tutorial-overlay.open{display:flex;}
.tutorial-box{width:min(760px, 96vw);max-height:86vh;overflow:auto;padding:24px;border-radius:24px;background:linear-gradient(180deg, rgba(9,16,29,.98), rgba(6,13,24,.96));border:1px solid rgba(255,255,255,.10);box-shadow:0 28px 60px rgba(0,0,0,.36);}
.tutorial-head{display:flex;gap:16px;align-items:flex-start;justify-content:space-between;margin-bottom:14px;}
.tutorial-close{min-width:42px;height:42px;border-radius:14px;font-size:22px;line-height:1;padding:0;background:rgba(255,255,255,.06);color:#fff;border:1px solid rgba(255,255,255,.08);box-shadow:none;}
.tutorial-close:hover{background:rgba(255,255,255,.10);}
.tutorial-steps{list-style:none;padding:0;margin:14px 0;display:flex;flex-direction:column;gap:12px;}
.tutorial-steps li{padding:14px 16px;border-radius:16px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);}
.tutorial-steps li strong{display:block;margin-bottom:6px;color:#fff;}
.tutorial-hide-toggle{display:flex;align-items:center;gap:10px;margin-top:10px;color:var(--text-soft);font-size:14px;}
.tutorial-hide-toggle input{min-width:auto;}
.tutorial-actions{display:flex;justify-content:flex-end;margin-top:18px;}
.stat-card.is-clickable{cursor:pointer;text-decoration:none;color:var(--text-light);display:block;}
.stat-card.is-clickable:hover{transform:translateY(-2px);border-color:rgba(96,165,250,.28);box-shadow:0 16px 30px rgba(0,0,0,.22);color:var(--text-light);}

/* ===== V5 CTA / PREMIUM ACTION SYSTEM ===== */
.quick-icon{font-size:1.25rem;line-height:1;filter:drop-shadow(0 0 8px rgba(56,189,248,.28));}
.quick-link.cta-primary{background:linear-gradient(135deg, rgba(56,189,248,.28), rgba(14,165,233,.16), rgba(15,23,42,.78));border-color:rgba(56,189,248,.42);box-shadow:0 0 0 1px rgba(56,189,248,.18) inset,0 18px 44px rgba(14,165,233,.13);}
.quick-link.cta-secondary{background:linear-gradient(135deg, rgba(255,255,255,.065), rgba(255,255,255,.035));border-color:rgba(255,255,255,.12);}
.quick-link.cta-primary:hover,.quick-link.cta-secondary:hover{transform:translateY(-3px);border-color:rgba(56,189,248,.44);box-shadow:0 0 0 1px rgba(56,189,248,.20) inset,0 0 28px rgba(56,189,248,.20),0 20px 46px rgba(0,0,0,.24);}
.page-actions .cta-primary,.toolbar-actions .cta-primary,button.cta-primary{background:linear-gradient(135deg,#67d8ff,#21a9f6 48%,#0e75d9);color:#06111d;border:1px solid rgba(180,235,255,.72);box-shadow:0 0 0 1px rgba(255,255,255,.18) inset,0 0 24px rgba(56,189,248,.32),0 16px 34px rgba(14,165,233,.20);}
.page-actions .cta-secondary,.toolbar-actions .cta-secondary,a.cta-secondary{border-color:rgba(125,211,252,.28);background:rgba(56,189,248,.075);box-shadow:0 0 0 1px rgba(56,189,248,.10) inset,0 0 18px rgba(56,189,248,.10);}
.page-actions .filter-chip{opacity:.92;background:rgba(148,163,184,.14);border-color:rgba(148,163,184,.24);color:#dbeafe;}
button.cta-primary{cursor:pointer;}
.actions .cta-secondary{padding:8px 11px;border-radius:12px;}
.status-badges .badge,.badge.badge-soft{font-size:11px;letter-spacing:.04em;}
.receipt-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center;}

/* ===== V7 SIDEBAR PULITA / PRODUCT NAV ===== */
.sidebar{width:310px;padding-left:18px;padding-right:18px;}
.sidebar .nav-group{gap:6px;}
.menu-section{display:flex;align-items:center;gap:10px;margin:24px 8px 10px;padding-top:7px;color:rgba(191,234,255,.84);font-size:10px;font-weight:950;letter-spacing:.22em;text-transform:uppercase;}
.menu-section::before{content:'';width:22px;height:1px;background:linear-gradient(90deg, rgba(56,189,248,.80), rgba(56,189,248,0));box-shadow:0 0 10px rgba(56,189,248,.22);}
.nav-link{isolation:isolate;min-height:48px;padding:10px 12px;border-radius:18px;}
.nav-link .nav-copy{display:flex;align-items:center;gap:8px;min-width:0;flex:1;}
.nav-link .nav-label{white-space:normal;line-height:1.18;}
.nav-mini-badge{display:none!important;}
.nav-link.nav-primary{min-height:54px;background:linear-gradient(135deg, rgba(255,255,255,.060), rgba(255,255,255,.030));border-color:rgba(148,163,184,.16);box-shadow:inset 0 1px 0 rgba(255,255,255,.055);}
.nav-link.nav-primary .nav-icon{background:rgba(56,189,248,.12);border-color:rgba(125,211,252,.22);color:#dff8ff;}
.nav-link.nav-primary .nav-label{font-size:14.5px;font-weight:900;color:#f8fdff;}
.nav-link.nav-money{min-height:58px;background:linear-gradient(135deg, rgba(56,189,248,.20), rgba(59,130,246,.11), rgba(255,255,255,.035));border:1px solid rgba(56,189,248,.34);box-shadow:0 0 0 1px rgba(56,189,248,.08) inset,0 14px 34px rgba(14,165,233,.13);}
.nav-link.nav-money .nav-icon{background:linear-gradient(180deg, rgba(56,189,248,.25), rgba(96,165,250,.12));border-color:rgba(125,211,252,.36);color:#e7fbff;box-shadow:0 0 16px rgba(56,189,248,.13);}
.nav-link.nav-money .nav-label{font-size:14.5px;font-weight:950;color:#ffffff;}
.nav-link.nav-secondary{background:rgba(255,255,255,.035);border-color:rgba(255,255,255,.045);}
.nav-link.nav-secondary .nav-label{font-weight:780;color:rgba(238,246,255,.90);}
.nav-link.nav-technical{min-height:43px;padding:8px 11px;background:rgba(255,255,255,.018);border-color:rgba(255,255,255,.020);opacity:.78;}
.nav-link.nav-technical .nav-icon{width:28px;height:28px;border-radius:11px;opacity:.72;}
.nav-link.nav-technical .nav-label{font-size:13px;font-weight:700;color:rgba(232,240,255,.68);}
.nav-link:hover{background:linear-gradient(135deg, rgba(56,189,248,.13), rgba(255,255,255,.040));border-color:rgba(125,211,252,.24);transform:translateX(2px);box-shadow:0 10px 26px rgba(0,0,0,.16),0 0 18px rgba(56,189,248,.06);}
.nav-link.nav-technical:hover{opacity:1;}
.nav-link.active{transform:translateX(2px);border-color:rgba(56,189,248,.35);background:linear-gradient(90deg, rgba(56,189,248,.18), rgba(96,165,250,.07), rgba(255,255,255,.025));box-shadow:0 0 0 1px rgba(56,189,248,.10) inset,0 16px 34px rgba(14,165,233,.10);}
.nav-link.active::before{content:'';position:absolute;left:-8px;top:11px;bottom:11px;width:3px;border-radius:999px;background:#38bdf8;box-shadow:0 0 14px rgba(56,189,248,.72);}
.nav-link.nav-money.active{background:linear-gradient(90deg, rgba(56,189,248,.26), rgba(59,130,246,.10), rgba(255,255,255,.025));box-shadow:0 0 0 1px rgba(56,189,248,.16) inset,0 18px 38px rgba(14,165,233,.16);}
.nav-link[data-tooltip]::before{content:attr(data-tooltip);position:absolute;left:calc(100% + 10px);top:50%;transform:translateY(-50%) translateX(-4px);width:228px;padding:10px 12px;border-radius:14px;background:rgba(5,12,24,.98);border:1px solid rgba(125,211,252,.16);color:#e6f7ff;font-size:12px;font-weight:650;line-height:1.35;letter-spacing:.01em;box-shadow:0 18px 42px rgba(0,0,0,.34),0 0 20px rgba(56,189,248,.08);opacity:0;pointer-events:none;z-index:50;transition:opacity .14s ease, transform .14s ease;white-space:normal;}
.nav-link[data-tooltip]:hover::before{opacity:1;transform:translateY(-50%) translateX(0);}

.nav-accordion{gap:10px;}
.nav-dropdown{border:1px solid rgba(148,163,184,.12);border-radius:20px;background:rgba(255,255,255,.026);overflow:hidden;box-shadow:inset 0 1px 0 rgba(255,255,255,.04);}
.nav-dropdown[open]{background:linear-gradient(135deg, rgba(15,23,42,.78), rgba(8,13,25,.70));border-color:rgba(56,189,248,.16);}
.nav-dropdown>summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:12px;padding:12px 12px;min-height:50px;color:#f8fdff;font-weight:950;letter-spacing:.02em;user-select:none;}
.nav-dropdown>summary::-webkit-details-marker{display:none;}
.nav-dropdown.active>summary{background:linear-gradient(90deg, rgba(56,189,248,.16), rgba(96,165,250,.06), transparent);}
.nav-dropdown.active{box-shadow:0 0 0 1px rgba(56,189,248,.08) inset,0 12px 30px rgba(14,165,233,.08);}
.nav-chevron{margin-left:auto;font-size:18px;color:#7dd3fc;transition:transform .16s ease;}
.nav-dropdown[open] .nav-chevron{transform:rotate(180deg);}
.nav-sub{display:flex;flex-direction:column;gap:7px;padding:0 9px 10px 9px;}
.nav-sub .nav-link{min-height:42px;border-radius:15px;padding:9px 10px;margin-left:8px;background:rgba(255,255,255,.020);}
.nav-sub .nav-link .nav-icon{width:30px;height:30px;border-radius:12px;}
.nav-sub .nav-link .nav-label{font-size:13.4px;}
.nav-sub .nav-link.active{background:linear-gradient(90deg, rgba(56,189,248,.24), rgba(96,165,250,.08), rgba(255,255,255,.03));border-color:rgba(56,189,248,.42);box-shadow:0 0 0 1px rgba(56,189,248,.13) inset,0 0 22px rgba(56,189,248,.12);}
.nav-sub .nav-link.active .nav-label{color:white;text-shadow:0 0 12px rgba(125,211,252,.45);}
.nav-sub .nav-link.active .nav-icon{box-shadow:0 0 16px rgba(56,189,248,.24);}

@media (max-width: 860px){.nav-link[data-tooltip]::before{display:none}.sidebar{width:100%;}}

/* A8.2 fix reale: azioni alert compatte. Desktop in riga, wrap solo su schermi piccoli. */
.a8-actions-nowrap{display:flex;align-items:center;justify-content:flex-end;gap:8px;flex-wrap:nowrap;min-width:360px}
.a8-actions-nowrap .a2-btn,.a8-actions-nowrap form,.a8-actions-nowrap button{white-space:nowrap;flex:0 0 auto}
@media (max-width: 1180px){.a8-actions-nowrap{min-width:0;flex-wrap:wrap;justify-content:flex-start}}
</style>
"""
   return (
       "<!DOCTYPE html>"
       "<html lang='it'>"
       "<head>"
       "<meta charset='utf-8'>"
       "<meta name='viewport' content='width=device-width, initial-scale=1'>"
       f"<title>{e(cfg.get('branding', {}).get('app_name') or cfg['nome_asd'])}</title>"
       + style_block + tenant_title_theme +
       "<link rel='stylesheet' href='/static/goldclass/goldclass.css?v=27M'><link rel='stylesheet' href='/static/enterprise/enterprise.css?v=27M'><link rel='stylesheet' href='/static/ui/system.css?v=a15-task-orbit'></head><body><div class='overlay'><div class='shell'>"
       "<aside class='sidebar' id='app-sidebar'>"
       "<div class='sidebar-brand'>"
       + logo_html +
       f"<div class='brand-chip'><span class='brand-chip-icon'><svg viewBox='0 0 24 24' aria-hidden='true'><path d='M4 13.5 9.2 18.2 20 5.8'/><path d='M12 20a8 8 0 1 0-8-8'/></svg></span><span>{e(cfg.get('branding', {}).get('suite_label') or 'ASD Pro Manager')}</span></div>"
       f"<h2 class='sidebar-asd-name'><span>{e(cfg['nome_asd'])}</span><span class='a11-title-orbit sidebar-orbit' aria-hidden='true'><i></i><i></i><i></i></span></h2><div class='small-muted' style='margin-top:6px;'>ASD attiva: <b>{e(current_tenant_label())}</b></div>"
       f"<div class='sidebar-subtitle'>{e(cfg.get('branding', {}).get('login_subtitle') or 'Cruscotto premium per operatività, flussi, documenti e controllo giornaliero dell’ASD.')}</div>"
       + ("<div class='brand-chip' style='margin-top:10px;background:rgba(255,152,0,.16);border-color:rgba(255,152,0,.35);'><span class='brand-chip-icon'>★</span><span>Modalità sviluppo attiva</span></div>" if (isinstance(current_license_status()[1], dict) and current_license_status()[1].get('developer_bypass')) else "")
       + "</div>"
       "<div class='nav-group nav-accordion'>"
       + nav_link('/', 'Dashboard', 'dashboard', tier='primary', title='Panoramica operativa: scadenze, incassi, tesserati e azioni rapide.')
       + nav_dropdown('Persone', 'users',
           ((nav_link('/tesserati', 'Tesserati', 'users', tier='primary', title='Anagrafiche, iscrizioni, pacchetti, certificati e documenti collegati.') if can_access_section('tesserati') else '')
           + (nav_link('/minori', 'Minori', 'shield_user', tier='secondary', title='Gestione minorenni, genitori, consensi e tutela documentale.') if can_access_section('minori') else '')
           + (nav_link('/collaboratori', 'Collaboratori', 'teacher', aliases=('/collaboratori/ricevute', '/ricevute-collaboratori'), tier='primary', title='Schede collaboratori, ore mensili, compensi e ricevute collaboratore.') if can_access_section('collaboratori') else '')),
           'persone')
       + nav_dropdown('Attività', 'calendar',
           ((nav_link('/corsi', 'Corsi & Presenze', 'calendar', aliases=('/presenze',), tier='primary', title='Corsi, lezioni, presenze e scarico pacchetti ingressi.') if (can_access_section('corsi') or can_access_section('presenze')) else '')
           + (nav_link('/danza', 'Danza aerea', 'ring', tier='money', title='Archivio tecnico di danza aerea, livelli e contenuti.') if can_access_section('danza') else '')
           + (nav_link('/danza/admin', 'Archivio tecnico', 'target', tier='secondary', title='Gestione archivio trick, combo, livelli, link video e contenuti didattici.') if can_access_section('danza') and has_role('admin') else '')),
           'attivita')
       + nav_dropdown('Economico', 'card',
           ((nav_link('/pagamenti', 'Pagamenti', 'card', aliases=('/promemoria', '/comunicazioni', '/promemoria/whatsapp'), tier='money', title='Quote, ricevute e controllo incassi.') if can_access_section('pagamenti') else '')
           + (nav_link('/comunicazioni', 'Comunicazioni', 'mail', aliases=('/promemoria/whatsapp',), tier='secondary', title='Prepara messaggi con Mail e WhatsApp del Mac.') if can_access_section('promemoria') else '')
           + (nav_link('/ricevute', 'Ricevute tesserati', 'receipt', tier='secondary', title='Archivio e generazione ricevute per tesserati e pagamenti.') if can_access_section('ricevute') else '')
           + (nav_link('/fatture', 'Fatture', 'bolt', aliases=('/fatture', '/fatture/nuova'), tier='secondary', title='Fatture locali, PDF/XML e archivio documenti.') if can_access_section('fatture') else '')
           + (nav_link('/contabilita', 'Contabilità', 'chart', tier='secondary', title='Riepilogo economico, movimenti, entrate, uscite e controllo contabile.') if can_access_section('contabilita') else '')),
           'economico')
       + nav_dropdown('Documenti', 'doc',
           ((nav_link('/documenti', 'Archivio documenti', 'doc', aliases=('/documenti', '/documenti/asd'), tier='secondary', title='Modelli DOCX, documenti ASD, certificati e archivio allegati.') if can_access_section('documenti') else '')),
           'documenti')
       + nav_dropdown('Amministrazione', 'settings',
           ((nav_link('/settings', 'Impostazioni ASD', 'settings', tier='secondary', title='Dati ASD, preferenze, branding e configurazioni generali.') if can_access_section('settings') else '')
           + (nav_link('/backup', 'Backup', 'database', tier='secondary', title='Backup, ripristino e sicurezza dei dati.') if can_access_section('backup') else '')
           + (nav_link('/utenti', 'Utenti', 'user', tier='secondary', title='Utenti che possono usare il gestionale.') if can_access_section('utenti') else '')
           + (nav_link('/tenants', 'Gestione ASD', 'building', tier='secondary', title='Crea, importa e gestisci le ASD locali.') if has_role('admin') else '')),
           'amministrazione')
       + (sidebar_logout_form() if auth() else "")
       + "</div></aside>"
       + "<main class='content'>"
       + (f"<div class='global-status-wrap'><div class='global-status-bar {e(status_summary.get('tone','ok'))}'><span></span></div><div class='global-status-meta'><span class='global-status-badge {e(status_summary.get('tone','ok'))}'><span class='badge-dot dot-{'green' if status_summary.get('tone')=='ok' else ('yellow' if status_summary.get('tone')=='warning' else 'red')}'></span>{e(status_summary.get('label',''))}</span><span>{e(status_summary.get('detail',''))}</span></div></div>" if auth() else "")
       + get_page_alert_html()
       + get_license_banner_html()
       + content
       + "<hr>"
       + f"<div class='footer-note'>{e(cfg.get('branding', {}).get('app_name') or cfg['nome_asd'])} • referente: {e(cfg['firma'])}</div>"
       + "<div class='footer-note'><b>Programma sviluppato da Daniele De Angelis</b></div>"
       + '</main></div></div><script src=\'/static/ui/system.js?v=desktop1\'></script><script>\n(function(){\nfunction closeA16(){var m=document.getElementById(\'a16QuickModal\');if(!m)return;m.classList.remove(\'open\');var f=m.querySelector(\'iframe\');if(f)f.src=\'about:blank\';}\ndocument.addEventListener(\'click\',function(ev){var a=ev.target.closest(\'a.a16-modal-link\');if(!a)return;if(ev.metaKey||ev.ctrlKey||ev.shiftKey||ev.altKey)return;ev.preventDefault();var m=document.getElementById(\'a16QuickModal\');if(!m){m=document.createElement(\'div\');m.id=\'a16QuickModal\';m.className=\'a16-modal\';m.innerHTML=\'<div class="a16-modal-backdrop" data-a16-close="1"></div><section class="a16-modal-card"><header><div><span class="a3-eyebrow">Azione rapida</span><h3></h3><p></p></div><button type="button" class="a16-modal-close" data-a16-close="1">×</button></header><iframe title="Azione rapida"></iframe><footer><a class="pro-cta strong a16-open-full" href="#">Apri pagina completa</a></footer></section>\';document.body.appendChild(m);}m.querySelector(\'h3\').textContent=a.dataset.modalTitle||a.textContent.trim()||\'Azione rapida\';m.querySelector(\'p\').textContent=a.dataset.modalText||\'Completa l’azione senza perdere il contesto della dashboard.\';m.querySelector(\'iframe\').src=a.href;m.querySelector(\'.a16-open-full\').href=a.href;m.classList.add(\'open\');});\ndocument.addEventListener(\'click\',function(ev){if(ev.target.closest(\'[data-a16-close]\'))closeA16();});\ndocument.addEventListener(\'keydown\',function(ev){if(ev.key===\'Escape\')closeA16();});\n})();\n</script></body></html>'
   )


@app.errorhandler(500)
def handle_500(_err):
   return layout(alert_html("Si è verificato un problema. Ricarica la pagina e riprova.", "error")), 500


@app.errorhandler(413)
def too_large(_err):
   return layout(alert_html(f"File troppo grande. Limite massimo: {MAX_UPLOAD_MB} MB.", "error")), 413


# ==============================
# COMMON DATA HELPERS
# ==============================
def get_non_pagati_rows():
   conn = db()
   c = conn.cursor()
   mese, anno = current_month_year()
   rows = c.execute(
       """
       SELECT t.id, t.nome, t.cognome, t.telefono, t.data_nascita, m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato, m.data_consenso
       FROM tesserati t
       LEFT JOIN minori m ON m.tesserato_id = t.id
       WHERE t.id NOT IN (
           SELECT tesserato_id FROM pagamenti WHERE mese=? AND anno=? AND causale='mensile'
       )
       ORDER BY t.cognome, t.nome
       """,
       (mese, anno),
   ).fetchall()
   conn.close()
   return rows


def get_missing_iscrizione_rows(year: int | None = None):
   conn = db()
   c = conn.cursor()
   target_year = int(year or now().year)
   rows = c.execute(
       """
       SELECT t.id, t.nome, t.cognome, t.telefono, t.data_nascita, m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato, m.data_consenso
       FROM tesserati t
       LEFT JOIN minori m ON m.tesserato_id = t.id
       WHERE t.id NOT IN (
           SELECT tesserato_id FROM pagamenti WHERE anno=? AND causale='iscrizione'
       )
       ORDER BY t.cognome, t.nome
       """,
       (target_year,),
   ).fetchall()
   conn.close()
   return rows


def get_missing_certificato_count() -> int:
   conn = db()
   c = conn.cursor()
   count = c.execute("SELECT COUNT(*) FROM tesserati WHERE TRIM(COALESCE(certificato_scadenza, ''))='' ").fetchone()[0]
   conn.close()
   return int(count or 0)


def get_minor_alert_count() -> int:
   conn = db()
   c = conn.cursor()
   rows = c.execute(
       """
       SELECT t.data_nascita, m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato
       FROM tesserati t
       LEFT JOIN minori m ON m.tesserato_id = t.id
       ORDER BY t.id
       """
   ).fetchall()
   conn.close()
   count = 0
   for r in rows:
       is_minor, _age = get_minor_status_from_birthdate(r["data_nascita"] or "")
       if not is_minor:
           continue
       has_parent = bool((r["genitore"] or "").strip())
       has_contact = bool((r["telefono_genitore"] or "").strip() or (r["email_genitore"] or "").strip())
       consent_ok = int(r["consenso_firmato"] or 0) == 1
       if not (has_parent and has_contact and consent_ok):
           count += 1
   return count


def get_global_status_summary() -> dict:
   missing_cert = get_missing_certificato_count()
   expired_cert = get_scaduti_count()
   expiring_cert = get_in_scadenza_count()
   minor_alerts = get_minor_alert_count()
   missing_tesseramenti = len(get_missing_iscrizione_rows(now().year))
   problems = int(missing_cert or 0) + int(expired_cert or 0) + int(minor_alerts or 0) + int(missing_tesseramenti or 0)
   warnings = int(expiring_cert or 0)
   if problems > 0:
       tone = 'error'
       label = f'{problems} criticità aperte'
       detail = 'Tesseramenti, certificati mancanti/scaduti o tutela minori incompleta.'
   elif warnings > 0:
       tone = 'warning'
       label = f'{warnings} verifiche da controllare'
       detail = 'Sono presenti scadenze o elementi da monitorare.'
   else:
       tone = 'ok'
       label = 'Archivio in ordine'
       detail = 'Nessuna criticità aperta nelle aree presidiate.'
   return {
       'tone': tone,
       'label': label,
       'detail': detail,
       'missing_cert': missing_cert,
       'expired_cert': expired_cert,
       'expiring_cert': expiring_cert,
       'minor_alerts': minor_alerts,
       'missing_tesseramenti': missing_tesseramenti,
   }


def get_page_status_summary() -> dict:
   path = (request.path or '/').rstrip('/') or '/'
   if path == '/':
       return get_global_status_summary()

   if path.startswith('/pagamenti'):
       try:
           conn = db()
           c = conn.cursor()
           mese, anno = current_month_year()
           non_pagati = c.execute("SELECT COUNT(*) FROM tesserati t WHERE t.id NOT IN (SELECT tesserato_id FROM pagamenti WHERE mese=? AND anno=? AND causale='mensile')", (mese, anno)).fetchone()[0] or 0
           iscrizioni = c.execute("SELECT COUNT(*) FROM tesserati t WHERE t.id NOT IN (SELECT tesserato_id FROM pagamenti WHERE anno=? AND causale='iscrizione')", (now().year,)).fetchone()[0] or 0
           rows = c.execute("SELECT t.data_nascita, m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato FROM tesserati t LEFT JOIN minori m ON m.tesserato_id = t.id").fetchall()
           conn.close()
           minor_alerts = 0
           for r in rows:
               is_minor, _age = get_minor_status_from_birthdate(r['data_nascita'] or '')
               if not is_minor:
                   continue
               has_parent = bool((r['genitore'] or '').strip())
               has_contact = bool((r['telefono_genitore'] or '').strip() or (r['email_genitore'] or '').strip())
               consent_ok = int(r['consenso_firmato'] or 0) == 1
               if not (has_parent and has_contact and consent_ok):
                   minor_alerts += 1
           problems = int(non_pagati) + int(iscrizioni) + int(minor_alerts)
           if problems > 0:
               return {'tone':'error','label':f'{problems} criticità aperte','detail':'Quote mancanti, iscrizioni da chiudere o tutela minori da completare.'}
           return {'tone':'ok','label':'Incassi sotto controllo','detail':'Nessuna criticità aperta nella sezione pagamenti.'}
       except Exception:
           return {'tone':'ok','label':'Sezione pagamenti','detail':'Controllo stato pagina non disponibile.'}

   if path.startswith('/minori'):
       try:
           conn = db()
           c = conn.cursor()
           linked_rows = c.execute("""
               SELECT t.id AS tesserato_id_link, t.nome, t.cognome, t.data_nascita, t.certificato_scadenza,
                      m.id, m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato, m.data_consenso, m.note_consenso
               FROM tesserati t
               LEFT JOIN minori m ON m.tesserato_id = t.id
               ORDER BY t.cognome, t.nome
           """).fetchall()
           severe = 0
           warnings = 0
           for r in linked_rows:
               is_minor, _ = get_minor_status_from_birthdate(r['data_nascita'] or '')
               if not is_minor:
                   continue
               cert_key, _ = get_certificato_status(r['certificato_scadenza'] or '')
               cert_problem = cert_key in {'mancante', 'scaduto'}
               cert_warning = cert_key == 'in_scadenza'
               has_parent = bool((r['genitore'] or '').strip())
               has_contact = bool((r['telefono_genitore'] or '').strip() or (r['email_genitore'] or '').strip())
               consent_ok = int(r['consenso_firmato'] or 0) == 1
               guardian_problem = not (has_parent and has_contact and consent_ok)
               if cert_problem and guardian_problem:
                   severe += 1
               elif cert_problem or guardian_problem or cert_warning:
                   warnings += 1
           conn.close()
           if severe > 0:
               return {'tone':'error','label':f'{severe} criticità minori','detail':'Sono presenti minori con certificato critico e consenso/tutela da completare.'}
           if warnings > 0:
               return {'tone':'warning','label':f'{warnings} verifiche minori','detail':'Sono presenti minori con una singola criticità o certificato in scadenza.'}
           return {'tone':'ok','label':'Tutela minori in ordine','detail':'Nessuna criticità aperta nella sezione minori.'}
       except Exception:
           return {'tone':'ok','label':'Sezione minori','detail':'Controllo stato pagina non disponibile.'}

   if path.startswith('/tesserati'):
       try:
           conn = db()
           c = conn.cursor()
           rows = c.execute("SELECT t.data_nascita, t.certificato_scadenza, m.genitore, m.telefono_genitore, m.email_genitore, m.consenso_firmato FROM tesserati t LEFT JOIN minori m ON m.tesserato_id = t.id").fetchall()
           conn.close()
           severe = 0
           warnings = 0
           for r in rows:
               cert_key, _ = get_certificato_status(r['certificato_scadenza'] or '')
               is_minor, _ = get_minor_status_from_birthdate(r['data_nascita'] or '')
               guardian_problem = False
               if is_minor:
                   has_parent = bool((r['genitore'] or '').strip())
                   has_contact = bool((r['telefono_genitore'] or '').strip() or (r['email_genitore'] or '').strip())
                   consent_ok = int(r['consenso_firmato'] or 0) == 1
                   guardian_problem = not (has_parent and has_contact and consent_ok)
               if cert_key in {'mancante', 'scaduto'} or guardian_problem:
                   severe += 1
               elif cert_key == 'in_scadenza':
                   warnings += 1
           if severe > 0:
               return {'tone':'error','label':f'{severe} criticità archivio','detail':'Certificati mancanti/scaduti o tutela minori incompleta.'}
           if warnings > 0:
               return {'tone':'warning','label':f'{warnings} verifiche da controllare','detail':'Sono presenti certificati in scadenza nella sezione tesserati.'}
           return {'tone':'ok','label':'Archivio tesserati in ordine','detail':'Nessuna criticità aperta nella sezione tesserati.'}
       except Exception:
           return {'tone':'ok','label':'Sezione tesserati','detail':'Controllo stato pagina non disponibile.'}

   return {'tone':'ok','label':'Sezione in ordine','detail':'Nessuna criticità aperta in questa pagina.'}


def get_scaduti_count() -> int:
   conn = db()
   c = conn.cursor()
   rows = c.execute("SELECT certificato_scadenza FROM tesserati").fetchall()
   conn.close()
   today = now().date()
   count = 0
   for r in rows:
       normalized = parse_date_input(r["certificato_scadenza"] or "")
       try:
           if normalized and datetime.strptime(normalized, "%Y-%m-%d").date() < today:
               count += 1
       except Exception:
           continue
   return count


def get_in_scadenza_count(days_threshold: int = 30) -> int:
   conn = db()
   c = conn.cursor()
   rows = c.execute("SELECT certificato_scadenza FROM tesserati").fetchall()
   conn.close()
   today = now().date()
   count = 0
   for r in rows:
       normalized = parse_date_input(r["certificato_scadenza"] or "")
       try:
           if not normalized:
               continue
           expiry = datetime.strptime(normalized, "%Y-%m-%d").date()
           days = (expiry - today).days
           if 0 <= days <= days_threshold:
               count += 1
       except Exception:
           continue
   return count


def get_today_courses_count() -> int:
   conn = db()
   c = conn.cursor()
   today = now_iso_date()
   count = c.execute("SELECT COUNT(DISTINCT corso_id) FROM presenze WHERE data=?", (today,)).fetchone()[0]
   conn.close()
   return int(count or 0)


def get_today_presenze_count() -> int:
   conn = db()
   c = conn.cursor()
   today = now_iso_date()
   count = c.execute("SELECT COUNT(*) FROM presenze WHERE data=? AND stato='presente'", (today,)).fetchone()[0]
   conn.close()
   return int(count or 0)


def get_today_assenti_count() -> int:
   conn = db()
   c = conn.cursor()
   today = now_iso_date()
   count = c.execute("SELECT COUNT(*) FROM presenze WHERE data=? AND stato='assente'", (today,)).fetchone()[0]
   conn.close()
   return int(count or 0)


PAYMENT_CAUSALI = {
   "iscrizione": "Quota iscrizione",
   "mensile": "Quota mensile",
}


def normalize_payment_causale(value: str) -> str:
   text = (value or "mensile").strip().lower()
   return text if text in PAYMENT_CAUSALI else "mensile"


def payment_description(causale: str, mese: int, anno: int) -> str:
   causale = normalize_payment_causale(causale)
   if causale == "iscrizione":
       return f"Quota iscrizione {anno}"
   return f"Quota mensile {mese:02d}/{anno}"


def ensure_payment_artifacts(cursor, pagamento_id: int) -> None:
   pagamento = cursor.execute(
       """
       SELECT p.id, p.tesserato_id, p.mese, p.anno, p.importo, p.data, p.causale,
              p.metodo_pagamento, t.nome, t.cognome, t.codice_fiscale,
              m.genitore
       FROM pagamenti p
       JOIN tesserati t ON t.id = p.tesserato_id
       LEFT JOIN minori m ON m.tesserato_id = t.id
       WHERE p.id=?
       """,
       (pagamento_id,),
   ).fetchone()
   if not pagamento:
       raise ValueError("Pagamento non trovato.")

   causale = normalize_payment_causale(pagamento["causale"])
   nome_completo = f"{pagamento['nome']} {pagamento['cognome']}"
   descrizione = payment_description(causale, int(pagamento["mese"]), int(pagamento["anno"]))
   data_pagamento = pagamento["data"] or now_iso_date()
   categoria = PAYMENT_CAUSALI.get(causale, "Pagamento")

   cursor.execute(
       """
       INSERT INTO ricevute(nome, descrizione, importo, data, pagamento_id, pdf_filename, metodo_pagamento)
       VALUES (?, ?, ?, ?, ?, NULL, ?)
       ON CONFLICT(pagamento_id) DO UPDATE SET
           nome=excluded.nome,
           descrizione=excluded.descrizione,
           importo=excluded.importo,
           data=excluded.data,
           metodo_pagamento=excluded.metodo_pagamento
       """,
       (nome_completo, descrizione, float(pagamento["importo"] or 0), data_pagamento, pagamento_id, (pagamento["metodo_pagamento"] or "")), 
   )

   cursor.execute(
       """
       INSERT INTO movimenti(tipo, categoria, descrizione, importo, data, pagamento_id, auto_generato)
       VALUES ('entrata', ?, ?, ?, ?, ?, 1)
       ON CONFLICT(pagamento_id) DO UPDATE SET
           tipo='entrata',
           categoria=excluded.categoria,
           descrizione=excluded.descrizione,
           importo=excluded.importo,
           data=excluded.data,
           auto_generato=1
       """,
       (categoria, f"{descrizione} - {nome_completo}", float(pagamento["importo"] or 0), data_pagamento, pagamento_id),
   )




def get_active_package(cursor, tesserato_id: int):
   return cursor.execute(
       "SELECT * FROM packages WHERE tesserato_id=? AND attivo=1 ORDER BY id DESC LIMIT 1",
       (tesserato_id,),
   ).fetchone()


def get_package_summary(cursor, tesserato_id: int) -> dict:
   row = get_active_package(cursor, tesserato_id)
   if not row:
       return {"tipo": "", "ingressi_totali": 0, "ingressi_residui": 0, "scadenza": "", "data_acquisto": "", "note": "", "certificato_richiesto": "No"}
   return {
       "tipo": row["tipo"] or "",
       "ingressi_totali": int(row["ingressi_totali"] or 0),
       "ingressi_residui": int(row["ingressi_residui"] or 0),
       "scadenza": row["scadenza"] or "",
       "data_acquisto": row["data_acquisto"] or "",
       "note": row["note"] or "",
       "certificato_richiesto": "Sì" if int(row["certificato_richiesto"] or 0) == 1 else "No",
   }


def reconcile_package_usages(cursor, corso_id: int, data_presenza: str, present_ids: set[int] | list[int] | tuple[int, ...]) -> None:
   present_set = {int(x) for x in (present_ids or set()) if int(x) > 0}
   rows = cursor.execute("SELECT * FROM package_usages WHERE corso_id=? AND data_presenza=?", (corso_id, data_presenza)).fetchall()
   existing_by_tesserato = {int(r["tesserato_id"]): r for r in rows}
   for tesserato_id, usage in existing_by_tesserato.items():
       if tesserato_id in present_set:
           continue
       package_row = cursor.execute("SELECT * FROM packages WHERE id=?", (int(usage["package_id"]),)).fetchone()
       if package_row:
           restored = min(int(package_row["ingressi_totali"] or 0), int(package_row["ingressi_residui"] or 0) + int(usage["qty"] or 1))
           cursor.execute("UPDATE packages SET ingressi_residui=?, updated_at=? WHERE id=?", (restored, now_iso_dt(), int(package_row["id"])))
       cursor.execute("DELETE FROM package_usages WHERE id=?", (int(usage["id"]),))
   for tesserato_id in sorted(present_set):
       if tesserato_id in existing_by_tesserato:
           continue
       package_row = get_active_package(cursor, tesserato_id)
       if not package_row:
           continue
       scadenza = str(package_row["scadenza"] or "")
       if scadenza:
           try:
               if datetime.strptime(scadenza, "%Y-%m-%d").date() < datetime.strptime(str(data_presenza), "%Y-%m-%d").date():
                   continue
           except Exception:
               pass
       residui = int(package_row["ingressi_residui"] or 0)
       if residui <= 0:
           continue
       presenza = cursor.execute(
           "SELECT id FROM presenze WHERE tesserato_id=? AND corso_id=? AND data=? ORDER BY id DESC LIMIT 1",
           (tesserato_id, corso_id, data_presenza),
       ).fetchone()
       cursor.execute("UPDATE packages SET ingressi_residui=?, updated_at=? WHERE id=?", (residui - 1, now_iso_dt(), int(package_row["id"])))
       cursor.execute(
           """
           INSERT OR IGNORE INTO package_usages(package_id, tesserato_id, presenza_id, corso_id, data_presenza, qty, created_at)
           VALUES (?, ?, ?, ?, ?, 1, ?)
           """,
           (int(package_row["id"]), tesserato_id, int(presenza["id"]) if presenza else None, corso_id, data_presenza, now_iso_dt()),
       )

def build_payment_pdf_by_receipt_row(ricevuta_row) -> Path:
   cfg = load_config()
   PDF_DIR.mkdir(parents=True, exist_ok=True)
   if ricevuta_row["pdf_filename"]:
       existing = PDF_DIR / str(ricevuta_row["pdf_filename"])
       if existing.exists():
           return existing

   file_path = PDF_DIR / f"ricevuta_{now().strftime('%Y%m%d_%H%M%S_%f')}.pdf"
   pdf = canvas.Canvas(str(file_path), pagesize=A4)
   width, height = A4
   y = height - 60

   logo_path = resolve_brand_asset_path(cfg.get("logo")) if cfg.get("logo") else None
   if logo_path and logo_path.exists():
       try:
           logo = ImageReader(str(logo_path))
           pdf.drawImage(logo, 40, y - 40, width=90, height=90, preserveAspectRatio=True, mask="auto")
       except Exception:
           pass

   pdf.setFont("Helvetica-Bold", 18)
   pdf.drawString(150, y + 20, str(cfg.get("nome_asd", "ASD"))[:60])
   pdf.setFont("Helvetica", 10)
   pdf.drawString(150, y, f"IBAN: {cfg.get('iban', '')}")
   pdf.setLineWidth(1)
   pdf.line(40, y - 55, width - 40, y - 55)
   pdf.setFont("Helvetica-Bold", 16)
   pdf.drawString(40, y - 90, "RICEVUTA")
   pdf.setFont("Helvetica", 12)
   pdf.drawString(40, y - 130, f"Nome: {truncate(ricevuta_row['nome'], 70)}")
   pdf.drawString(40, y - 160, f"Descrizione: {truncate(ricevuta_row['descrizione'], 80)}")
   pdf.drawString(40, y - 190, f"Importo: {euro(ricevuta_row['importo'])}")
   pdf.drawString(40, y - 220, f"Data: {format_display_date(ricevuta_row['data']) or now().strftime('%d/%m/%Y')}")
   pdf.rect(width - 190, y - 210, 130, 45)
   pdf.setFont("Helvetica-Bold", 14)
   pdf.drawString(width - 175, y - 183, f"Totale: {euro(ricevuta_row['importo'])}")
   pdf.setFont("Helvetica", 10)
   pdf.drawString(40, 70, f"Firma ASD: {cfg.get('firma', '')}")
   pdf.drawString(40, 45, str(cfg.get("nome_asd", "ASD"))[:80])
   pdf.save()
   return file_path

# ==============================
# A.7 OPERATIONAL AUTOMATION ENGINE
# ==============================
def _table_columns(conn, table_name: str) -> set[str]:
    try:
        return {str(r[1]) for r in conn.execute(f"PRAGMA table_info({table_name})").fetchall()}
    except Exception:
        return set()

def _has_table(conn, table_name: str) -> bool:
    try:
        return conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table_name,)).fetchone() is not None
    except Exception:
        return False

def _ensure_operational_task_state(conn) -> None:
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS operational_task_state (id INTEGER PRIMARY KEY AUTOINCREMENT, task_key TEXT NOT NULL UNIQUE, status TEXT NOT NULL DEFAULT 'open', note TEXT, last_action TEXT, created_at TEXT, updated_at TEXT)""")
        conn.commit()
    except Exception:
        pass

def _row_get(row, key: str, default=""):
    try:
        if row is None:
            return default
        if hasattr(row, "keys") and key in row.keys():
            value = row[key]
            return default if value is None else value
        if isinstance(row, dict):
            return row.get(key, default)
    except Exception:
        pass
    return default

def _full_name(row) -> str:
    return (f"{str(_row_get(row,'cognome','') or '').strip()} {str(_row_get(row,'nome','') or '').strip()}".strip() or "Tesserato")

def _safe_task_fragment(value) -> str:
    raw = str(value or "").lower().strip()
    raw = re.sub(r"[^a-z0-9_:-]+", "-", raw)
    return raw.strip("-")[:90] or "task"

def _task_key(category: str, tesserato_id: int | str = "", month=None, year=None, extra: str = "") -> str:
    cur_m, cur_y = current_month_year()
    m = parse_int(month, cur_m)
    y = parse_int(year, cur_y)
    return f"{_safe_task_fragment(category)}:{str(tesserato_id or '0')}:{int(m):02d}:{int(y)}:{_safe_task_fragment(extra)}"

def _get_task_state_map(conn) -> dict:
    out = {}
    try:
        _ensure_operational_task_state(conn)
        for r in conn.execute("SELECT task_key, status, note, last_action, updated_at FROM operational_task_state").fetchall():
            out[str(r["task_key"])] = dict(r)
    except Exception:
        pass
    return out

def set_operational_task_status(task_key: str, status: str = "in_lavorazione", note: str = "", action: str = "") -> bool:
    task_key = str(task_key or "").strip()
    if not task_key:
        return False
    allowed = {"open", "in_lavorazione", "posticipato", "archiviato"}
    status = status if status in allowed else "in_lavorazione"
    conn = db()
    try:
        _ensure_operational_task_state(conn)
        now_s = now_iso_dt()
        conn.execute("""
            INSERT INTO operational_task_state(task_key, status, note, last_action, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(task_key) DO UPDATE SET status=excluded.status, note=excluded.note, last_action=excluded.last_action, updated_at=excluded.updated_at
        """, (task_key, status, truncate(note or "", 400), truncate(action or status, 80), now_s, now_s))
        conn.commit()
        return True
    except Exception as exc:
        try: log_exception(f"set_operational_task_status: {exc}")
        except Exception: pass
        return False
    finally:
        try: conn.close()
        except Exception: pass

def _alert(severity, category, title, person_name, description, primary_label, primary_url, secondary_label=None, secondary_url=None, meta=None, task_key="", next_step=""):
    meta = meta or {}
    tid = meta.get("tesserato_id", "")
    key = task_key or _task_key(category, tid, meta.get("month"), meta.get("year"), title)
    return {"severity": severity, "category": category, "title": title, "person_name": person_name, "description": description, "primary_action_label": primary_label, "primary_action_url": primary_url, "secondary_action_label": secondary_label or "", "secondary_action_url": secondary_url or "", "task_key": key, "next_step": next_step or primary_label, "status": "open", "state_note": "", "last_action": "", "meta": meta}

def _payment_exists_for_month(conn, tesserato_id: int, month: int, year: int) -> bool:
    if not _has_table(conn, "pagamenti"):
        return False
    cols = _table_columns(conn, "pagamenti")
    try:
        if {"tesserato_id", "mese", "anno"}.issubset(cols):
            if "causale" in cols:
                row = conn.execute("SELECT id FROM pagamenti WHERE tesserato_id=? AND mese=? AND anno=? AND LOWER(COALESCE(causale,'mensile')) IN ('mensile','quota','quota mensile') LIMIT 1", (tesserato_id, month, year)).fetchone()
            else:
                row = conn.execute("SELECT id FROM pagamenti WHERE tesserato_id=? AND mese=? AND anno=? LIMIT 1", (tesserato_id, month, year)).fetchone()
            return bool(row)
    except Exception:
        return False
    return False

def _registration_payment_exists(conn, tesserato_id: int, year: int) -> bool:
    """Quota tesseramento/iscrizione annuale: obbligatoria e bloccante."""
    if not _has_table(conn, "pagamenti"):
        return False
    cols = _table_columns(conn, "pagamenti")
    try:
        if {"tesserato_id", "anno"}.issubset(cols):
            if "causale" in cols:
                row = conn.execute(
                    """SELECT id FROM pagamenti
                       WHERE tesserato_id=? AND anno=?
                         AND LOWER(COALESCE(causale,'')) IN ('iscrizione','tesseramento','quota iscrizione','quota tesseramento')
                       LIMIT 1""",
                    (tesserato_id, year),
                ).fetchone()
            else:
                row = None
            return bool(row)
    except Exception:
        return False
    return False


def _minor_guardian_row(conn, tesserato_row):
    if not _has_table(conn, "minori"):
        return None
    cols = _table_columns(conn, "minori")
    try:
        tid = int(_row_get(tesserato_row, "id", 0) or 0)
        if "tesserato_id" in cols and tid:
            row = conn.execute("SELECT * FROM minori WHERE tesserato_id=? LIMIT 1", (tid,)).fetchone()
            if row:
                return row
        if {"nome", "cognome"}.issubset(cols):
            nome = str(_row_get(tesserato_row, "nome", "") or "").strip().lower()
            cognome = str(_row_get(tesserato_row, "cognome", "") or "").strip().lower()
            if nome and cognome:
                return conn.execute("SELECT * FROM minori WHERE LOWER(nome)=? AND LOWER(cognome)=? LIMIT 1", (nome, cognome)).fetchone()
    except Exception:
        return None
    return None

def _guardian_issues(minor_row) -> list[str]:
    if not minor_row:
        return ["scheda tutela/genitore mancante", "consenso mancante"]
    issues = []
    if not str(_row_get(minor_row, "genitore", "") or "").strip():
        issues.append("genitore/tutore non indicato")
    if not (str(_row_get(minor_row, "telefono_genitore", "") or "").strip() or str(_row_get(minor_row, "email_genitore", "") or "").strip()):
        issues.append("contatto genitore mancante")
    consenso = str(_row_get(minor_row, "consenso_firmato", "0") or "0").strip().lower()
    if consenso not in {"1", "true", "si", "sì", "ok"}:
        issues.append("consenso/tutela da completare")
    return issues

def _active_tesserati_rows(conn):
    if not _has_table(conn, "tesserati"):
        return []
    t_cols = _table_columns(conn, "tesserati")
    wanted = ["id", "nome", "cognome", "telefono", "email", "corso", "data_nascita", "certificato_scadenza", "codice_fiscale", "attivo", "stato"]
    select_cols = [c for c in wanted if c in t_cols]
    if not select_cols:
        return []
    where = []
    if "attivo" in t_cols:
        where.append("COALESCE(attivo,1)=1")
    if "stato" in t_cols:
        where.append("LOWER(COALESCE(stato,'')) NOT IN ('archiviato','inattivo','sospeso')")
    where_sql = " WHERE " + " AND ".join(where) if where else ""
    order_cols = [c for c in ["cognome", "nome"] if c in t_cols]
    order_sql = (" ORDER BY " + ", ".join([c + " COLLATE NOCASE" for c in order_cols])) if order_cols else " ORDER BY id"
    return conn.execute(f"SELECT {', '.join(select_cols)} FROM tesserati{where_sql}{order_sql}").fetchall()

def get_operational_alerts(month=None, year=None, include_archived: bool = True):
    cur_m, cur_y = current_month_year()
    month = parse_int(month, cur_m)
    year = parse_int(year, cur_y)
    alerts = []
    conn = db()
    try:
        state_map = _get_task_state_map(conn)
        for t in _active_tesserati_rows(conn):
            tid = int(_row_get(t, "id", 0) or 0)
            name = _full_name(t)
            corso = str(_row_get(t, "corso", "") or "").strip()
            tess_url = f"/tesserati?edit={tid}&drawer=1" if tid else "/tesserati"
            is_minor, age = get_minor_status_from_birthdate(str(_row_get(t, "data_nascita", "") or ""))
            if is_minor:
                issues = _guardian_issues(_minor_guardian_row(conn, t))
                if issues:
                    alerts.append(_alert("critical", "minore", "Minore bloccato: consenso/tutela incompleta", name, "; ".join(issues).capitalize()+".", "Completa tutela", f"/minori?id={tid}", "Apri atleta", tess_url, {"tesserato_id": tid, "course": corso, "age": age, "month": month, "year": year, "blocker": 1}, next_step="Raccogli consenso e dati genitore prima della prossima lezione"))
            cert_key, cert_label = get_certificato_status(str(_row_get(t, "certificato_scadenza", "") or ""))
            if cert_key in {"mancante", "scaduto", "non_valido"}:
                alerts.append(_alert("critical", "certificato", "Atleta bloccato: certificato medico critico", name, f"Certificato: {cert_label.lower()}.", "Aggiorna certificato", tess_url, "Apri documenti", "/documenti", {"tesserato_id": tid, "course": corso, "cert_status": cert_key, "month": month, "year": year, "blocker": 1}, next_step="Carica o aggiorna la scadenza del certificato medico"))
            elif cert_key == "in_scadenza":
                alerts.append(_alert("warning", "certificato", "Certificato in scadenza", name, "Certificato medico in scadenza entro 30 giorni.", "Aggiorna certificato", tess_url, "Apri documenti", "/documenti", {"tesserato_id": tid, "course": corso, "cert_status": cert_key, "month": month, "year": year}, next_step="Chiedi rinnovo e inserisci nuova data appena disponibile"))
            missing = []
            t_cols = set(t.keys()) if hasattr(t, "keys") else set()
            for col, label in [("telefono","telefono"),("email","email"),("corso","corso"),("data_nascita","data nascita")]:
                if col in t_cols and not str(_row_get(t, col, "") or "").strip():
                    missing.append(label)
            if missing:
                alerts.append(_alert("warning", "anagrafica", "Scheda atleta incompleta", name, "Mancano: "+", ".join(missing)+".", "Completa scheda", tess_url, None, None, {"tesserato_id": tid, "course": corso, "month": month, "year": year}, next_step="Completa i campi essenziali per evitare moduli e promemoria incompleti"))
            if tid and not _registration_payment_exists(conn, tid, year):
                alerts.append(_alert(
                    "critical",
                    "tesseramento",
                    "Atleta bloccato: quota tesseramento mancante",
                    name,
                    f"Non risulta registrata la quota di tesseramento/iscrizione {int(year)}. Blocco immediato finché non viene registrata.",
                    "Registra tesseramento",
                    f"/pagamenti?tesserato_id={tid}&mese=1&anno={int(year)}&focus=iscrizioni_mancanti",
                    "Apri atleta",
                    tess_url,
                    {"tesserato_id": tid, "course": corso, "month": 1, "year": year, "blocker": 1, "reminder_after_days": 10, "causale": "iscrizione"},
                    task_key=_task_key("tesseramento", tid, 1, year, "quota-iscrizione"),
                    next_step="Registra la quota tesseramento. Se resta aperta, invia promemoria dopo 10 giorni."
                ))
            if tid and not _payment_exists_for_month(conn, tid, month, year):
                alerts.append(_alert("warning", "pagamento", "Quota mensile da incassare/verificare", name, f"Non risulta registrata la quota {int(month):02d}/{int(year)}.", "Registra quota", f"/pagamenti?tesserato_id={tid}&mese={int(month)}&anno={int(year)}", "Apri atleta", tess_url, {"tesserato_id": tid, "course": corso, "month": month, "year": year}, next_step="Verifica incasso o registra pagamento mensile"))
        for a in alerts:
            st = state_map.get(str(a.get("task_key") or ""), {})
            if st:
                a["status"] = st.get("status") or "open"
                a["state_note"] = st.get("note") or ""
                a["last_action"] = st.get("last_action") or ""
                a["updated_at"] = st.get("updated_at") or ""
        if not include_archived:
            alerts = [a for a in alerts if a.get("status") != "archiviato"]
    except Exception as exc:
        try: log_exception(f"get_operational_alerts: {exc}")
        except Exception: pass
    finally:
        try: conn.close()
        except Exception: pass
    order = {"critical":0, "warning":1, "info":2, "ok":3}
    status_order = {"open":0, "in_lavorazione":1, "posticipato":2, "archiviato":9}
    return sorted(alerts, key=lambda a: (order.get(a.get("severity"),9), status_order.get(a.get("status"),5), str(a.get("person_name","")).lower(), str(a.get("category", ""))))

def get_operational_tasks(month=None, year=None, include_archived: bool = False) -> list[dict]:
    tasks = get_operational_alerts(month, year, include_archived=include_archived)
    for t in tasks:
        sev = t.get("severity")
        cat = t.get("category")
        if sev == "critical":
            t["urgency_label"] = "BLOCCANTE"
            t["sla"] = "Da chiudere prima della prossima attività"
        elif cat == "tesseramento":
            t["urgency_label"] = "BLOCCANTE"
            t["sla"] = "Obbligatorio subito; promemoria se aperto da 10 giorni"
        elif cat == "pagamento":
            t["urgency_label"] = "INCASSO"
            t["sla"] = "Da verificare nel mese selezionato"
        else:
            t["urgency_label"] = "VERIFICA"
            t["sla"] = "Da completare appena possibile"
    return tasks

def generate_monthly_dues_check(month=None, year=None) -> dict:
    cur_m, cur_y = current_month_year()
    month = parse_int(month, cur_m)
    year = parse_int(year, cur_y)
    tasks = [t for t in get_operational_tasks(month, year) if t.get("category") == "pagamento"]
    return {"month": month, "year": year, "missing_count": len(tasks), "missing_names": [t.get("person_name") for t in tasks[:50]], "tasks": tasks}

def compute_member_status(tesserato_id=None, month=None, year=None, alerts=None) -> dict:
    alerts = list(alerts) if alerts is not None else get_operational_alerts(month, year)
    tid = str(tesserato_id or "")
    member_alerts = [a for a in alerts if tid and str((a.get("meta") or {}).get("tesserato_id") or "") == tid]
    critical = [a for a in member_alerts if a.get("severity") == "critical"]
    warnings = [a for a in member_alerts if a.get("severity") == "warning"]
    blockers = [a for a in critical if (a.get("meta") or {}).get("blocker")]
    if blockers:
        code, label, tone = "blocked", "BLOCCATO", "danger"
    elif critical:
        code, label, tone = "critical", "CRITICO", "danger"
    elif warnings:
        code, label, tone = "attention", "ATTENZIONE", "warning"
    else:
        code, label, tone = "ok", "OK", "ok"
    return {"code": code, "label": label, "tone": tone, "alerts": member_alerts, "critical_count": len(critical), "warning_count": len(warnings)}

def get_dashboard_metrics(month=None, year=None):
    cur_m, cur_y = current_month_year(); month=parse_int(month,cur_m); year=parse_int(year,cur_y)
    metrics = {"month": month, "year": year, "tesserati": 0, "pagamenti_ricevuti": 0, "incasso_mese": 0.0, "quote_mancanti": 0, "tesseramenti_mancanti": 0, "minori_critici": 0, "certificati_critici": 0, "dati_incompleti": 0, "task_aperti": 0, "task_in_lavorazione": 0, "bloccanti": 0, "oggi_presenti": 0, "oggi_assenti": 0, "oggi_corsi": 0, "oggi_bloccati": 0, "alerts": [], "tasks": []}
    conn = db()
    try:
        metrics["alerts"] = get_operational_alerts(month, year)
        metrics["tasks"] = get_operational_tasks(month, year)
        if _has_table(conn, "tesserati"):
            metrics["tesserati"] = int((conn.execute("SELECT COUNT(*) FROM tesserati").fetchone() or [0])[0] or 0)
        if _has_table(conn, "pagamenti"):
            metrics["pagamenti_ricevuti"] = int((conn.execute("SELECT COUNT(*) FROM pagamenti WHERE mese=? AND anno=?", (month, year)).fetchone() or [0])[0] or 0)
            metrics["incasso_mese"] = float((conn.execute("SELECT COALESCE(SUM(importo),0) FROM pagamenti WHERE mese=? AND anno=?", (month, year)).fetchone() or [0])[0] or 0)
        metrics["quote_mancanti"] = sum(1 for a in metrics["alerts"] if a.get("category") == "pagamento")
        metrics["tesseramenti_mancanti"] = sum(1 for a in metrics["alerts"] if a.get("category") == "tesseramento")
        metrics["minori_critici"] = sum(1 for a in metrics["alerts"] if a.get("category") == "minore" and a.get("severity") == "critical")
        metrics["certificati_critici"] = sum(1 for a in metrics["alerts"] if a.get("category") == "certificato" and a.get("severity") == "critical")
        metrics["dati_incompleti"] = sum(1 for a in metrics["alerts"] if a.get("category") == "anagrafica")
        metrics["task_aperti"] = sum(1 for a in metrics["tasks"] if a.get("status") in {"open", "in_lavorazione", "posticipato"})
        metrics["task_in_lavorazione"] = sum(1 for a in metrics["tasks"] if a.get("status") == "in_lavorazione")
        metrics["bloccanti"] = sum(1 for a in metrics["alerts"] if (a.get("meta") or {}).get("blocker"))
        metrics["oggi_presenti"] = get_today_presenze_count()
        metrics["oggi_assenti"] = get_today_assenti_count()
        metrics["oggi_corsi"] = get_today_courses_count()
        today_blocked = set()
        for _a in metrics["alerts"]:
            _m = _a.get("meta") or {}
            if _m.get("blocker") and _m.get("tesserato_id"):
                today_blocked.add(str(_m.get("tesserato_id")))
        metrics["oggi_bloccati"] = len(today_blocked)
    except Exception as exc:
        try: log_exception(f"get_dashboard_metrics: {exc}")
        except Exception: pass
    finally:
        try: conn.close()
        except Exception: pass
    return metrics

def render_member_status_badge(status: dict) -> str:
    tone = e(status.get("tone") or "ok")
    label = e(status.get("label") or "OK")
    detail = f"{int(status.get('critical_count') or 0)} critici · {int(status.get('warning_count') or 0)} verifiche"
    return f"<span class='a7-member-status {tone}' title='{e(detail)}'><span></span>{label}</span>"

def render_operational_alert_cards(alerts, limit=None, empty="Nessuna criticità operativa aperta.") -> str:
    data = list(alerts or [])
    if limit:
        data = data[:int(limit)]
    if not data:
        return f"<div class='a2-empty a7-empty'><strong>✓ Tutto in ordine</strong><span>{e(empty)}</span></div>"
    out=[]
    for idx, a in enumerate(data):
        sev=e(a.get("severity") or "warning"); cat=e(a.get("category") or "operativo"); course=e((a.get("meta") or {}).get("course") or "")
        status=e(a.get("status") or "open"); task_key=e(a.get("task_key") or "")
        badge="BLOCCANTE" if (a.get("meta") or {}).get("blocker") else ("CRITICO" if sev=="critical" else "VERIFICA")
        status_label={"open":"Da fare","in_lavorazione":"In lavorazione","posticipato":"Posticipato","archiviato":"Archiviato"}.get(a.get("status"),"Da fare")
        second=f"<a class='a2-btn ghost' href='{e(a.get('secondary_action_url'))}'>{e(a.get('secondary_action_label'))}</a>" if a.get('secondary_action_url') and a.get('secondary_action_label') else ""
        action_form=""
        if task_key:
            action_form=f"""<form method='POST' action='/promemoria/task-action' class='a7-task-form'>{csrf_input()}<input type='hidden' name='task_key' value='{task_key}'><input type='hidden' name='status' value='in_lavorazione'><input type='hidden' name='next' value='{e(request.full_path if request else "/promemoria")}'><button type='submit' class='a2-btn micro'>Prendi in carico</button></form>"""
        out.append(f"""<article class='a2-alert-card a7-task-card {sev} status-{status}' style='--a7-delay:{idx * 45}ms'><div class='a7-task-rail'></div><div class='a2-alert-main'><div class='a2-alert-top'><span class='a2-badge {sev}'>{e(badge)}</span><span class='a2-category'>{cat}</span>{f'<span>{course}</span>' if course else ''}<span class='a7-task-status {status}'>{e(status_label)}</span></div><h3>{e(a.get('title') or 'Azione richiesta')}</h3><div class='a2-person'>{e(a.get('person_name') or '')}</div><p>{e(a.get('description') or '')}</p><div class='a7-next-step'><b>Prossimo passo:</b> {e(a.get('next_step') or a.get('primary_action_label') or 'Apri la scheda')}</div></div><div class='a2-alert-actions a8-actions-nowrap'><a class='a2-btn primary {sev} a16-modal-link' data-modal-title='{e(a.get('primary_action_label') or 'Azione rapida')}' data-modal-text='{e(a.get('next_step') or a.get('description') or '')}' href='{e(a.get('primary_action_url') or '#')}'>{e(a.get('primary_action_label') or 'Apri')}</a>{second}{action_form}</div></article>""")
    return "".join(out)
