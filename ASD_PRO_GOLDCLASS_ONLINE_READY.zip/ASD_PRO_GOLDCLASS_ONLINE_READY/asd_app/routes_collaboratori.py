from .core import *
from reportlab.lib import colors
from reportlab.pdfgen import canvas



# COLLABORATORI
# ==============================
def get_collaboratore_by_id(cursor, collab_id: int):
    return cursor.execute(
        "SELECT * FROM collaboratori WHERE id=?",
        (collab_id,),
    ).fetchone()


def get_selected_month_year_from_request() -> tuple[int, int]:
    month_default, year_default = current_month_year()
    mese = parse_int(request.args.get("mese", month_default), month_default)
    anno = parse_int(request.args.get("anno", year_default), year_default)

    if mese < 1 or mese > 12:
        mese = month_default
    if anno < 2000 or anno > 2100:
        anno = year_default

    return mese, anno


@app.route("/collaboratori", methods=["GET", "POST"])
@login_required
def collaboratori():
    conn = db()
    c = conn.cursor()
    mese_corrente, anno_corrente = get_selected_month_year_from_request()

    if request.method == "POST":
        action = request.form.get("action", "").strip()
        mese_view = parse_int(request.form.get("mese_view", mese_corrente), mese_corrente)
        anno_view = parse_int(request.form.get("anno_view", anno_corrente), anno_corrente)

        if mese_view < 1 or mese_view > 12:
            mese_view = mese_corrente
        if anno_view < 2000 or anno_view > 2100:
            anno_view = anno_corrente

        if action in {"create_collaboratore", "update_collaboratore"}:
            try:
                nome = require_non_empty(request.form.get("nome", ""), "Nome")
                cognome = require_non_empty(request.form.get("cognome", ""), "Cognome")
                paga_oraria = round(parse_float(request.form.get("paga_oraria", "10"), 10.0), 2)
                if paga_oraria < 0:
                    raise ValueError("La paga oraria non può essere negativa.")

                telefono = truncate(request.form.get("telefono", "").strip(), 40)
                email = normalize_email(request.form.get("email", ""), 120)
                codice_fiscale = truncate(request.form.get("codice_fiscale", "").strip().upper(), 20)
                ruolo = truncate(request.form.get("ruolo", "").strip(), 80)
                tipo_rapporto = request.form.get("tipo_rapporto", "sportivo_co.co.co").strip()
                if tipo_rapporto not in {"sportivo_co.co.co", "amministrativo_co.co.co"}:
                    tipo_rapporto = "sportivo_co.co.co"
                copertura_previdenziale = request.form.get("copertura_previdenziale", "nessuna").strip()
                if copertura_previdenziale not in {"nessuna", "altra_previdenza"}:
                    copertura_previdenziale = "nessuna"
                franchigia_inps_precedente = max(0.0, parse_float(request.form.get("franchigia_inps_precedente", "0"), 0.0))
                compensi_sportivi_esterni_anno = max(0.0, parse_float(request.form.get("compensi_sportivi_esterni_anno", "0"), 0.0))
                attivita_inps_codice = truncate(request.form.get("attivita_inps_codice", "22").strip(), 4)
                codice_inps_sede = truncate(request.form.get("codice_inps_sede", "").strip(), 20)
                matricola_inps = truncate(request.form.get("matricola_inps", "").strip(), 40)
                contratto_firmato = 1 if request.form.get("contratto_firmato") == "on" else 0
                rasd_stato = request.form.get("rasd_stato", "da_verificare").strip()
                if rasd_stato not in {"da_verificare", "comunicata", "non_dovuta", "da_aggiornare"}:
                    rasd_stato = "da_verificare"
                rasd_data_comunicazione = request.form.get("rasd_data_comunicazione", "").strip()
                uniemens_stato = request.form.get("uniemens_stato", "da_verificare").strip()
                if uniemens_stato not in {"da_verificare", "trasmesso", "non_dovuto"}:
                    uniemens_stato = "da_verificare"
                data_fine = request.form.get("data_fine", "").strip()
                note = truncate(request.form.get("note", "").strip(), 1000)

                data_nascita = (
                    require_valid_date(request.form.get("data_nascita", "").strip(), "la data di nascita")
                    if request.form.get("data_nascita", "").strip()
                    else ""
                )
                data_inizio = (
                    require_valid_date(request.form.get("data_inizio", "").strip(), "la data di inizio")
                    if request.form.get("data_inizio", "").strip()
                    else ""
                )

                minor = 1 if request.form.get("minor") == "on" else 0
                attivo = 1 if request.form.get("attivo") == "on" else 0
            except ValueError as exc:
                conn.close()
                return redirect_with_message(
                    "/collaboratori",
                    str(exc),
                    "error",
                    mese=mese_view,
                    anno=anno_view,
                )

            if action == "create_collaboratore":
                foto_path = ""
                foto = request.files.get("foto")
                if foto and foto.filename:
                    try:
                        foto_path = save_uploaded_image(foto, "collaboratori")
                    except ValueError as exc:
                        conn.close()
                        return redirect_with_message(
                            "/collaboratori",
                            str(exc),
                            "error",
                            mese=mese_view,
                            anno=anno_view,
                        )

                c.execute(
                    """
                    INSERT INTO collaboratori(
                        nome, cognome, foto, minor, paga_oraria,
                        telefono, email, data_nascita, codice_fiscale,
                        ruolo, data_inizio, attivo, note,
                        tipo_rapporto, copertura_previdenziale, franchigia_inps_precedente,
                        compensi_sportivi_esterni_anno, attivita_inps_codice, codice_inps_sede, matricola_inps,
                        contratto_firmato, rasd_stato, rasd_data_comunicazione, uniemens_stato, data_fine
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        nome,
                        cognome,
                        foto_path,
                        minor,
                        paga_oraria,
                        telefono,
                        email,
                        data_nascita,
                        codice_fiscale,
                        ruolo,
                        data_inizio,
                        attivo,
                        note,
                        tipo_rapporto,
                        copertura_previdenziale,
                        franchigia_inps_precedente,
                        compensi_sportivi_esterni_anno,
                        attivita_inps_codice,
                        codice_inps_sede,
                        matricola_inps,
                        contratto_firmato,
                        rasd_stato,
                        rasd_data_comunicazione,
                        uniemens_stato,
                        data_fine,
                    ),
                )
                conn.commit()
                conn.close()
                return redirect_with_message(
                    "/collaboratori",
                    "Collaboratore salvato correttamente.",
                    "success",
                    mese=mese_view,
                    anno=anno_view,
                )

            rec_id = parse_int(request.form.get("id", "0"), 0)
            existing = get_collaboratore_by_id(c, rec_id)
            if not existing:
                conn.close()
                return redirect_with_message(
                    "/collaboratori",
                    "Collaboratore non trovato.",
                    "error",
                    mese=mese_view,
                    anno=anno_view,
                )

            foto_path = existing["foto"] or ""
            foto = request.files.get("foto")
            if foto and foto.filename:
                try:
                    new_foto_path = save_uploaded_image(foto, "collaboratori")
                except ValueError as exc:
                    conn.close()
                    return redirect_with_message(
                        "/collaboratori",
                        str(exc),
                        "error",
                        mese=mese_view,
                        anno=anno_view,
                        edit=rec_id,
                    )
                if foto_path and foto_path != new_foto_path:
                    delete_uploaded_image(foto_path)
                foto_path = new_foto_path

            c.execute(
                """
                UPDATE collaboratori
                SET nome=?, cognome=?, foto=?, minor=?, paga_oraria=?,
                    telefono=?, email=?, data_nascita=?, codice_fiscale=?,
                    ruolo=?, data_inizio=?, attivo=?, note=?,
                    tipo_rapporto=?, copertura_previdenziale=?, franchigia_inps_precedente=?,
                    compensi_sportivi_esterni_anno=?, attivita_inps_codice=?, codice_inps_sede=?, matricola_inps=?,
                    contratto_firmato=?, rasd_stato=?, rasd_data_comunicazione=?, uniemens_stato=?, data_fine=?
                WHERE id=?
                """,
                (
                    nome,
                    cognome,
                    foto_path,
                    minor,
                    paga_oraria,
                    telefono,
                    email,
                    data_nascita,
                    codice_fiscale,
                    ruolo,
                    data_inizio,
                    attivo,
                    note,
                    tipo_rapporto,
                    copertura_previdenziale,
                    franchigia_inps_precedente,
                    compensi_sportivi_esterni_anno,
                    attivita_inps_codice,
                    codice_inps_sede,
                    matricola_inps,
                    contratto_firmato,
                    rasd_stato,
                    rasd_data_comunicazione,
                    uniemens_stato,
                    data_fine,
                    rec_id,
                ),
            )
            conn.commit()
            conn.close()
            return redirect_with_message(
                "/collaboratori",
                "Collaboratore aggiornato correttamente.",
                "success",
                mese=mese_view,
                anno=anno_view,
            )

        if action in {"create_ora", "update_ora"}:
            try:
                collaboratore_id = parse_int(request.form.get("collaboratore_id", "0"), 0)
                if collaboratore_id <= 0:
                    raise ValueError("Collaboratore non valido.")
                if not get_collaboratore_by_id(c, collaboratore_id):
                    raise ValueError("Collaboratore inesistente.")

                data = require_valid_date(request.form.get("data", "").strip(), "la data")
                ore = round(parse_float(request.form.get("ore", "0"), 0.0), 2)

                if ore <= 0:
                    raise ValueError("Le ore devono essere maggiori di zero.")
                if ore > 24:
                    raise ValueError("Le ore giornaliere non possono superare 24.")

                dt = datetime.strptime(data, "%Y-%m-%d")
                mese_record = dt.month
                anno_record = dt.year
            except ValueError as exc:
                conn.close()
                return redirect_with_message(
                    "/collaboratori",
                    str(exc),
                    "error",
                    mese=mese_view,
                    anno=anno_view,
                )

            if action == "create_ora":
                existing_same_day = c.execute(
                    """
                    SELECT id, ore, liquidato
                    FROM ore_collaboratori
                    WHERE collaboratore_id=? AND data=?
                    """,
                    (collaboratore_id, data),
                ).fetchone()

                if existing_same_day:
                    if int(existing_same_day["liquidato"] or 0) == 1:
                        conn.close()
                        return redirect_with_message(
                            "/collaboratori",
                            "Questa riga è già liquidata e non può essere modificata.",
                            "error",
                            mese=mese_view,
                            anno=anno_view,
                        )

                    c.execute(
                        """
                        UPDATE ore_collaboratori
                        SET ore=?, mese=?, anno=?
                        WHERE id=?
                        """,
                        (ore, mese_record, anno_record, existing_same_day["id"]),
                    )
                    conn.commit()
                    conn.close()
                    return redirect_with_message(
                        "/collaboratori",
                        "Esisteva già una riga per questa data: le ore sono state aggiornate.",
                        "warning",
                        mese=mese_view,
                        anno=anno_view,
                    )

                c.execute(
                    """
                    INSERT INTO ore_collaboratori(collaboratore_id, data, ore, mese, anno, liquidato)
                    VALUES (?, ?, ?, ?, ?, 0)
                    """,
                    (collaboratore_id, data, ore, mese_record, anno_record),
                )
                conn.commit()
                conn.close()
                return redirect_with_message(
                    "/collaboratori",
                    "Ore registrate correttamente.",
                    "success",
                    mese=mese_view,
                    anno=anno_view,
                )

            ora_id = parse_int(request.form.get("ora_id", "0"), 0)
            existing_ora = c.execute(
                "SELECT * FROM ore_collaboratori WHERE id=?",
                (ora_id,),
            ).fetchone()

            if not existing_ora:
                conn.close()
                return redirect_with_message(
                    "/collaboratori",
                    "Riga ore non trovata.",
                    "error",
                    mese=mese_view,
                    anno=anno_view,
                )

            if int(existing_ora["liquidato"] or 0) == 1:
                conn.close()
                return redirect_with_message(
                    "/collaboratori",
                    "Questa riga è già liquidata e non può essere modificata.",
                    "error",
                    mese=mese_view,
                    anno=anno_view,
                )

            duplicate_target = c.execute(
                """
                SELECT id, liquidato
                FROM ore_collaboratori
                WHERE collaboratore_id=? AND data=? AND id<>?
                """,
                (collaboratore_id, data, ora_id),
            ).fetchone()

            if duplicate_target:
                conn.close()
                return redirect_with_message(
                    "/collaboratori",
                    "Esiste già un'altra riga per questo collaboratore nella stessa data.",
                    "warning",
                    mese=mese_view,
                    anno=anno_view,
                    edit_ora=ora_id,
                )

            c.execute(
                """
                UPDATE ore_collaboratori
                SET collaboratore_id=?, data=?, ore=?, mese=?, anno=?
                WHERE id=?
                """,
                (collaboratore_id, data, ore, mese_record, anno_record, ora_id),
            )
            conn.commit()
            conn.close()
            return redirect_with_message(
                "/collaboratori",
                "Riga ore aggiornata correttamente.",
                "success",
                mese=mese_view,
                anno=anno_view,
            )

        conn.close()
        return redirect_with_message(
            "/collaboratori",
            "Azione non valida.",
            "error",
            mese=mese_view,
            anno=anno_view,
        )

    edit_collaboratore = None
    if request.args.get("edit"):
        edit_id = parse_int(request.args.get("edit", "0"), 0)
        edit_collaboratore = c.execute(
            "SELECT * FROM collaboratori WHERE id=?",
            (edit_id,),
        ).fetchone()

    edit_ora = None
    if request.args.get("edit_ora"):
        edit_ora_id = parse_int(request.args.get("edit_ora", "0"), 0)
        edit_ora = c.execute(
            """
            SELECT oc.*, c.nome, c.cognome
            FROM ore_collaboratori oc
            JOIN collaboratori c ON c.id = oc.collaboratore_id
            WHERE oc.id=?
            """,
            (edit_ora_id,),
        ).fetchone()

    drawer_collab = request.args.get('new') == '1' or bool(edit_collaboratore)
    drawer_ore = request.args.get('new_ora') == '1' or bool(edit_ora)

    collaboratori_rows = c.execute(
        "SELECT * FROM collaboratori ORDER BY cognome, nome"
    ).fetchall()

    totali_mese_rows = c.execute(
        """
        SELECT
            c.id,
            COALESCE(SUM(oc.ore), 0) AS ore_mese,
            COALESCE(SUM(CASE WHEN COALESCE(oc.liquidato, 0)=0 THEN oc.ore ELSE 0 END), 0) AS ore_da_liquidare
        FROM collaboratori c
        LEFT JOIN ore_collaboratori oc
            ON oc.collaboratore_id = c.id
           AND COALESCE(oc.mese, CAST(strftime('%m', oc.data) AS INTEGER)) = ?
           AND COALESCE(oc.anno, CAST(strftime('%Y', oc.data) AS INTEGER)) = ?
        GROUP BY c.id
        ORDER BY c.cognome, c.nome
        """,
        (mese_corrente, anno_corrente),
    ).fetchall()

    totali_map = {row["id"]: float(row["ore_mese"] or 0) for row in totali_mese_rows}
    liquidabili_map = {row["id"]: float(row["ore_da_liquidare"] or 0) for row in totali_mese_rows}

    storico_rows = c.execute(
        """
        SELECT
            oc.id,
            oc.collaboratore_id,
            oc.data,
            oc.ore,
            oc.liquidato,
            c.nome,
            c.cognome,
            c.paga_oraria
        FROM ore_collaboratori oc
        JOIN collaboratori c ON c.id = oc.collaboratore_id
        WHERE COALESCE(oc.mese, CAST(strftime('%m', oc.data) AS INTEGER)) = ?
          AND COALESCE(oc.anno, CAST(strftime('%Y', oc.data) AS INTEGER)) = ?
        ORDER BY oc.data DESC, c.cognome ASC, c.nome ASC, oc.id DESC
        """,
        (mese_corrente, anno_corrente),
    ).fetchall()

    conn.close()

    total_month_hours = round(sum(float(row["ore"] or 0) for row in storico_rows), 2)
    total_month_cost = round(
        sum(float(row["ore"] or 0) * float(row["paga_oraria"] or 0) for row in storico_rows),
        2,
    )

    collab_form_action = "update_collaboratore" if edit_collaboratore else "create_collaboratore"
    ora_form_action = "update_ora" if edit_ora else "create_ora"
    collab_checked_minor = "checked" if (edit_collaboratore and int(edit_collaboratore["minor"] or 0) == 1) else ""
    collab_checked_attivo = "checked" if (not edit_collaboratore or int(edit_collaboratore["attivo"] or 0) == 1) else ""

    current_photo_html = ""
    if edit_collaboratore and edit_collaboratore["foto"]:
        current_photo_html = (
            f"<div class='small-muted'>Foto attuale</div>"
            f"<img src='{file_url(edit_collaboratore['foto'])}' class='thumb-60' "
            "onerror=\"this.style.display='none'\">"
        )

    active_count = sum(1 for r in collaboratori_rows if int(r["attivo"] or 0) == 1)
    minor_count = sum(1 for r in collaboratori_rows if int(r["minor"] or 0) == 1)
    total_liquidabili_hours = round(sum(float(liquidabili_map.get(r["id"], 0.0)) for r in collaboratori_rows), 2)

    html_out = f"""
    <div class="app-section-hero">
        <div class="kicker">Team</div>
        <h2 class="section-title">Collaboratori</h2>
        <div class="small-muted">Gestisci anagrafiche, ore, compensi e chiusura mensile con un flusso più ordinato e più vicino a un prodotto commerciale.</div>
        <div class="page-actions"><span class="filter-chip">Periodo {mese_corrente:02d}/{anno_corrente}</span><a href="/collaboratori?new=1&mese={mese_corrente}&anno={anno_corrente}" class="cta-primary">Nuovo collaboratore</a><a href="/collaboratori?new_ora=1&mese={mese_corrente}&anno={anno_corrente}" class="cta-secondary">Registra ore</a><a href="/collaboratori/ricevute" class="cta-secondary">Archivio ricevute</a><a href="/collaboratori/mensile?mese={mese_corrente}&anno={anno_corrente}" class="cta-secondary">Liquidazione mensile</a><a href="/collaboratori/adempimenti?mese={mese_corrente}&anno={anno_corrente}" class="cta-secondary">Adempimenti</a></div><div class="inline-guide"><strong>Come usare questa pagina</strong><p>Usa <b>Nuovo collaboratore</b> per creare la scheda anagrafica. Usa <b>Registra ore</b> per inserire o aggiornare le righe giornaliere del periodo selezionato.</p></div>
    </div>

    <div class="metric-strip">
        <div class="metric-box"><div class="label">Collaboratori</div><div class="value">{len(collaboratori_rows)}</div></div>
        <div class="metric-box"><div class="label">Attivi</div><div class="value">{active_count}</div></div>
        <div class="metric-box"><div class="label">Minori</div><div class="value">{minor_count}</div></div>
        <div class="metric-box"><div class="label">Ore periodo</div><div class="value">{total_month_hours:.2f}</div></div>
        <div class="metric-box"><div class="label">Ore da liquidare</div><div class="value">{total_liquidabili_hours:.2f}</div></div>
        <div class="metric-box"><div class="label">Costo periodo</div><div class="value">{euro(total_month_cost)}</div></div>
    </div>

    <div class="card form-panel card-elevated">
        <div class="kicker">Filtro periodo</div>
        <h3 class="section-title">Controllo mensile</h3>
        <form method="GET" class="form-row" style="margin-bottom:8px;">
            {number_input("mese", mese_corrente, "Mese", "1", 1)}
            {number_input("anno", anno_corrente, "Anno", "1", 2000)}
            <button type="submit">Visualizza periodo</button>
            <a href="/collaboratori" class="cta-secondary">Periodo corrente</a>
        </form>
        <div class="form-hint">Il filtro cambia il periodo operativo per ore, liquidazioni e riepiloghi senza modificare i dati esistenti.</div>
    </div>

    <div class="compact-grid">
        <div class="card card-elevated">
            <div class="kicker">Archivio team</div>
            <h3 class="section-title">Anagrafiche e compensi</h3>
            <div class="small-muted">Nuovi inserimenti e modifiche si aprono in drawer laterale per alleggerire la pagina e mantenere il focus sull'elenco.</div>
        </div>
        <div class="mini-card"><strong>Nuovo collaboratore</strong><div class="small-muted">Scheda anagrafica completa con ruolo, paga, foto e stato.</div></div>
        <div class="mini-card"><strong>Ore giornaliere</strong><div class="small-muted">Registra o modifica le ore senza perdere il contesto del periodo.</div></div>
    </div>

    <div class="drawer-shell {'open' if drawer_collab else ''}">
      <div class="drawer-backdrop" data-close-drawer="1"></div>
      <div class="drawer-panel">
        <div class="drawer-head"><div><div class="kicker">Anagrafica team</div><h3 class="section-title">{'Modifica collaboratore' if edit_collaboratore else 'Nuovo collaboratore'}</h3></div><a href="/collaboratori?mese={mese_corrente}&anno={anno_corrente}" class="drawer-close">×</a></div>
        <div class="card card-elevated">
            <div class="kicker">Anagrafica team</div>
            <h3 class="section-title">{'Modifica collaboratore' if edit_collaboratore else 'Nuovo collaboratore'}</h3>
            <form method="POST" enctype="multipart/form-data" class="form-row">
            {csrf_input()}
            <input type="hidden" name="action" value="{collab_form_action}">
            <input type="hidden" name="id" value="{edit_collaboratore['id'] if edit_collaboratore else ''}">
            <input type="hidden" name="mese_view" value="{mese_corrente}">
            <input type="hidden" name="anno_view" value="{anno_corrente}">

            <input name="nome" placeholder="Nome" required value="{e(edit_collaboratore['nome'] if edit_collaboratore else '')}">
            <input name="cognome" placeholder="Cognome" required value="{e(edit_collaboratore['cognome'] if edit_collaboratore else '')}">
            <input name="telefono" placeholder="Telefono" value="{e(edit_collaboratore['telefono'] if edit_collaboratore else '')}">
            <input name="email" placeholder="Email" value="{e(edit_collaboratore['email'] if edit_collaboratore else '')}">
            <input name="codice_fiscale" placeholder="Codice fiscale" value="{e(edit_collaboratore['codice_fiscale'] if edit_collaboratore else '')}">
            <input name="data_nascita" placeholder="Data nascita (DD/MM/YYYY)" value="{e(format_display_date(edit_collaboratore['data_nascita']) if edit_collaboratore else '')}">
            <input name="data_inizio" placeholder="Data inizio collaborazione (DD/MM/YYYY)" value="{e(format_display_date(edit_collaboratore['data_inizio']) if edit_collaboratore else '')}">
            <input name="ruolo" placeholder="Ruolo (es. istruttore)" value="{e(edit_collaboratore['ruolo'] if edit_collaboratore else '')}">
            <div class="form-col">
                <input type="file" name="foto" accept=".png,.jpg,.jpeg,.webp,.gif">
                {current_photo_html}
            </div>
            <label style="align-self:center;"><input type="checkbox" name="minor" {collab_checked_minor}> Minore</label>
            <label style="align-self:center;"><input type="checkbox" name="attivo" {collab_checked_attivo}> Attivo</label>
            {number_input("paga_oraria", float(edit_collaboratore['paga_oraria']) if edit_collaboratore else '10.0', 'Paga oraria (€)', '0.01', 0)}
            <select name="tipo_rapporto">
              <option value="sportivo_co.co.co" {"selected" if edit_collaboratore and edit_collaboratore["tipo_rapporto"]=="sportivo_co.co.co" else ""}>Lavoratore sportivo — co.co.co.</option>
              <option value="amministrativo_co.co.co" {"selected" if edit_collaboratore and edit_collaboratore["tipo_rapporto"]=="amministrativo_co.co.co" else ""}>Amministrativo-gestionale — co.co.co.</option>
            </select>
            <select name="copertura_previdenziale">
              <option value="nessuna" {"selected" if not edit_collaboratore or edit_collaboratore["copertura_previdenziale"]!="altra_previdenza" else ""}>Nessun'altra previdenza / non pensionato</option>
              <option value="altra_previdenza" {"selected" if edit_collaboratore and edit_collaboratore["copertura_previdenziale"]=="altra_previdenza" else ""}>Già assicurato altrove / pensionato</option>
            </select>
            {number_input("compensi_sportivi_esterni_anno", float(edit_collaboratore['compensi_sportivi_esterni_anno']) if edit_collaboratore else '0', 'Compensi sportivi da altri committenti nell’anno (€)', '0.01', 0)}
            {number_input("franchigia_inps_precedente", float(edit_collaboratore['franchigia_inps_precedente']) if edit_collaboratore else '0', 'Franchigia INPS già utilizzata (€)', '0.01', 0)}
            <input name="attivita_inps_codice" placeholder="Codice attività INPS (es. 22 istruttore)" value="{e(edit_collaboratore['attivita_inps_codice'] if edit_collaboratore else '22')}">
            <input name="codice_inps_sede" placeholder="Codice sede INPS (se noto)" value="{e(edit_collaboratore['codice_inps_sede'] if edit_collaboratore else '')}">
            <input name="matricola_inps" placeholder="Matricola/codice INPS (se noto)" value="{e(edit_collaboratore['matricola_inps'] if edit_collaboratore else '')}">
            <input name="data_fine" placeholder="Data fine collaborazione (DD/MM/YYYY)" value="{e(format_display_date(edit_collaboratore['data_fine']) if edit_collaboratore and edit_collaboratore['data_fine'] else '')}">
            <label style="align-self:center;"><input type="checkbox" name="contratto_firmato" {("checked" if edit_collaboratore and int(edit_collaboratore["contratto_firmato"] or 0) else "")}> Contratto firmato</label>
            <select name="rasd_stato">
              <option value="da_verificare" {("selected" if not edit_collaboratore or edit_collaboratore["rasd_stato"]=="da_verificare" else "")}>RASD: da verificare</option>
              <option value="comunicata" {("selected" if edit_collaboratore and edit_collaboratore["rasd_stato"]=="comunicata" else "")}>RASD: comunicata</option>
              <option value="da_aggiornare" {("selected" if edit_collaboratore and edit_collaboratore["rasd_stato"]=="da_aggiornare" else "")}>RASD: da aggiornare</option>
              <option value="non_dovuta" {("selected" if edit_collaboratore and edit_collaboratore["rasd_stato"]=="non_dovuta" else "")}>RASD: non dovuta</option>
            </select>
            <input name="rasd_data_comunicazione" placeholder="Data comunicazione RASD (DD/MM/YYYY)" value="{e(format_display_date(edit_collaboratore['rasd_data_comunicazione']) if edit_collaboratore and edit_collaboratore['rasd_data_comunicazione'] else '')}">
            <select name="uniemens_stato">
              <option value="da_verificare" {("selected" if not edit_collaboratore or edit_collaboratore["uniemens_stato"]=="da_verificare" else "")}>UNIEMENS: da verificare</option>
              <option value="trasmesso" {("selected" if edit_collaboratore and edit_collaboratore["uniemens_stato"]=="trasmesso" else "")}>UNIEMENS: trasmesso</option>
              <option value="non_dovuto" {("selected" if edit_collaboratore and edit_collaboratore["uniemens_stato"]=="non_dovuto" else "")}>UNIEMENS: non dovuto</option>
            </select>
            <textarea name="note" placeholder="Note interne...">{e(edit_collaboratore['note'] if edit_collaboratore else '')}</textarea>
            <button>{'Aggiorna collaboratore' if edit_collaboratore else 'Aggiungi collaboratore'}</button>
            {"<a href='/collaboratori?mese=%d&anno=%d' style='align-self:center;'>Annulla modifica</a>" % (mese_corrente, anno_corrente) if edit_collaboratore else ""}
        </form>
        </div>
      </div>
    </div>

    <div class="drawer-shell {'open' if drawer_ore else ''}">
      <div class="drawer-backdrop" data-close-drawer="1"></div>
      <div class="drawer-panel">
        <div class="drawer-head"><div><div class="kicker">Ore giornaliere</div><h3 class="section-title">{'Modifica riga ore' if edit_ora else 'Registra ore giornaliere'}</h3></div><a href="/collaboratori?mese={mese_corrente}&anno={anno_corrente}" class="drawer-close">×</a></div>
        <div class="card card-elevated">
        <div class="kicker">Ore giornaliere</div>
        <h3 class="section-title">{'Modifica riga ore' if edit_ora else 'Registra ore giornaliere'}</h3>
        <form method="POST" class="form-row">
            {csrf_input()}
            <input type="hidden" name="action" value="{ora_form_action}">
            <input type="hidden" name="ora_id" value="{edit_ora['id'] if edit_ora else ''}">
            <input type="hidden" name="mese_view" value="{mese_corrente}">
            <input type="hidden" name="anno_view" value="{anno_corrente}">
            <select name="collaboratore_id" required>
    """

    for c_row in collaboratori_rows:
        selected = "selected" if (edit_ora and int(edit_ora["collaboratore_id"]) == int(c_row["id"])) else ""
        html_out += (
            f'<option value="{c_row["id"]}" {selected}>'
            f'{e(c_row["nome"])} {e(c_row["cognome"])} - {e(c_row["ruolo"] or "")}'
            "</option>"
        )

    html_out += f"""
            </select>
            <input name="data" placeholder="Data (DD/MM/YYYY)" required value="{e(format_display_date(edit_ora['data']) if edit_ora else '')}">
            {number_input("ore", float(edit_ora['ore']) if edit_ora else '', 'Ore lavorate', '0.25', 0)}
            <button>{'Aggiorna ore' if edit_ora else 'Salva ore'}</button>
            {"<a href='/collaboratori?mese=%d&anno=%d' style='align-self:center;'>Annulla modifica ore</a>" % (mese_corrente, anno_corrente) if edit_ora else ""}
        </form>
        <div class="form-hint">Le righe già liquidate restano protette come nel comportamento attuale del gestionale.</div>
        </div>
      </div>
    </div>

    <div class="card">
        <div class="table-toolbar">
            <div>
                <div class="kicker">Riepilogo compensi</div>
                <h3 class="section-title" style="margin-bottom:4px;">Elenco collaboratori e compensi del periodo</h3>
                <div class="small-muted">Tabella principale per controllare disponibilità, ore e chiusura mese.</div>
            </div>
        </div>
        <table>
            <tr>
                <th>Foto</th>
                <th>Nome</th>
                <th>Ruolo</th>
                <th>Telefono</th>
                <th>Minore</th>
                <th>Paga oraria</th>
                <th>Ore periodo</th>
                <th>Ore da liquidare</th>
                <th>Retribuzione</th>
                <th>Stato</th>
                <th>Azioni</th>
            </tr>
    """

    for r in collaboratori_rows:
        foto_html = (
            f"<img src='{file_url(r['foto'])}' class='thumb-60' onerror=\"this.style.display='none'\">"
            if r["foto"] else ""
        )
        ore_tot = round(float(totali_map.get(r["id"], 0.0)), 2)
        ore_da_liquidare = round(float(liquidabili_map.get(r["id"], 0.0)), 2)
        retribuzione = round(ore_tot * float(r["paga_oraria"] or 0), 2)
        minore_label = "Sì" if int(r["minor"] or 0) == 1 else "No"
        stato_label = "Attivo" if int(r["attivo"] or 0) == 1 else "Non attivo"

        liquidazione_form = ""
        if ore_da_liquidare > 0:
            liquidazione_form = f"""
                <form method="POST" action="/collaboratori/chiudi_mese" class="inline-form" onsubmit="return confirm('Liquidare il mese selezionato per questo collaboratore?');">
                    {csrf_input()}
                    <input type="hidden" name="collaboratore_id" value="{r['id']}">
                    <input type="hidden" name="mese" value="{mese_corrente}">
                    <input type="hidden" name="anno" value="{anno_corrente}">
                    <button class="cta-primary">Genera ricevuta</button>
                </form>
            """

        html_out += f"""
            <tr>
                <td>{foto_html}</td>
                <td>{e(r['nome'])} {e(r['cognome'])}</td>
                <td>{e(r['ruolo'])}</td>
                <td>{e(r['telefono'])}</td>
                <td>{minore_label}</td>
                <td>{euro(r['paga_oraria'])}</td>
                <td>{ore_tot:.2f}</td>
                <td>{ore_da_liquidare:.2f}</td>
                <td>{euro(retribuzione)}</td>
                <td>{e(stato_label)}</td>
                <td>
                    <div class="actions">
                        <a href="/collaboratori?edit={r['id']}&mese={mese_corrente}&anno={anno_corrente}">Modifica</a>
                        {liquidazione_form}
                        <form method="POST" action="/collaboratori/delete" class="inline-form" onsubmit="return confirm('Eliminare questo collaboratore?');">
                            {csrf_input()}
                            <input type="hidden" name="id" value="{r['id']}">
                            <input type="hidden" name="mese_view" value="{mese_corrente}">
                            <input type="hidden" name="anno_view" value="{anno_corrente}">
                            <button class="danger">Elimina</button>
                        </form>
                    </div>
                </td>
            </tr>
        """

    html_out += """
        </table>
    </div>

    <div class="card">
        <div class="table-toolbar">
            <div>
                <div class="kicker">Storico ore</div>
                <h3 class="section-title" style="margin-bottom:4px;">Righe del periodo</h3>
                <div class="small-muted">Storico utile per modifiche puntuali prima della liquidazione.</div>
            </div>
        </div>
        <table>
            <tr>
                <th>Collaboratore</th>
                <th>Data</th>
                <th>Ore</th>
                <th>Paga oraria</th>
                <th>Importo</th>
                <th>Liquidazione</th>
                <th>Azioni</th>
            </tr>
    """

    if storico_rows:
        for row in storico_rows:
            importo_riga = round(float(row["ore"] or 0) * float(row["paga_oraria"] or 0), 2)
            liquidato_label = "Liquidata" if int(row["liquidato"] or 0) == 1 else "Da liquidare"

            if int(row["liquidato"] or 0) == 1:
                actions_html = "<span class='small-muted'>Bloccata</span>"
            else:
                actions_html = f"""
                    <div class="actions">
                        <a href="/collaboratori?edit_ora={row['id']}&mese={mese_corrente}&anno={anno_corrente}">Modifica</a>
                        <form method="POST" action="/collaboratori/delete_ora" class="inline-form" onsubmit="return confirm('Eliminare questa riga ore?');">
                            {csrf_input()}
                            <input type="hidden" name="id" value="{row['id']}">
                            <input type="hidden" name="mese_view" value="{mese_corrente}">
                            <input type="hidden" name="anno_view" value="{anno_corrente}">
                            <button class="danger">Elimina</button>
                        </form>
                    </div>
                """

            html_out += f"""
                <tr>
                    <td>{e(row['nome'])} {e(row['cognome'])}</td>
                    <td>{e(format_display_date(row['data']))}</td>
                    <td>{float(row['ore'] or 0):.2f}</td>
                    <td>{euro(row['paga_oraria'])}</td>
                    <td>{euro(importo_riga)}</td>
                    <td>{e(liquidato_label)}</td>
                    <td>{actions_html}</td>
                </tr>
            """
    else:
        html_out += """
            <tr>
                <td colspan="7">
                    <div class="empty-state">Nessuna riga ore presente per il periodo selezionato.</div>
                </td>
            </tr>
        """

    html_out += """
        </table>
    </div>
    """

    html_out += f"""<script>document.querySelectorAll('[data-close-drawer="1"]').forEach(function(el){{el.addEventListener('click', function(){{ window.location.href='/collaboratori?mese={mese_corrente}&anno={anno_corrente}'; }});}});</script>"""
    return layout(html_out)


@app.route("/collaboratori/chiudi_mese", methods=["POST"])
@login_required
def collaboratori_chiudi_mese():
    collaboratore_id = parse_int(request.form.get("collaboratore_id", "0"), 0)
    mese = parse_int(request.form.get("mese", current_month_year()[0]), current_month_year()[0])
    anno = parse_int(request.form.get("anno", current_month_year()[1]), current_month_year()[1])

    if collaboratore_id <= 0:
        return redirect_with_message(
            "/collaboratori",
            "Collaboratore non valido.",
            "error",
            mese=mese,
            anno=anno,
        )

    conn = db()
    c = conn.cursor()

    collab = get_collaboratore_by_id(c, collaboratore_id)
    if not collab:
        conn.close()
        return redirect_with_message(
            "/collaboratori",
            "Collaboratore non trovato.",
            "error",
            mese=mese,
            anno=anno,
        )

    rows = c.execute(
        """
        SELECT id, ore
        FROM ore_collaboratori
        WHERE collaboratore_id=?
          AND COALESCE(mese, CAST(strftime('%m', data) AS INTEGER))=?
          AND COALESCE(anno, CAST(strftime('%Y', data) AS INTEGER))=?
          AND COALESCE(liquidato, 0)=0
        ORDER BY data, id
        """,
        (collaboratore_id, mese, anno),
    ).fetchall()

    if not rows:
        conn.close()
        return redirect_with_message(
            "/collaboratori",
            "Nessuna ora da liquidare per il periodo selezionato.",
            "warning",
            mese=mese,
            anno=anno,
        )

    totale_ore = round(sum(float(r["ore"] or 0) for r in rows), 2)
    paga_oraria = round(float(collab["paga_oraria"] or 0), 2)
    totale_compenso = round(totale_ore * paga_oraria, 2)

    descrizione = (
        f"Compenso collaboratore {collab['nome']} {collab['cognome']} "
        f"- {mese:02d}/{anno:04d}"
    )

    try:
        c.execute(
            """
            INSERT INTO movimenti(tipo, categoria, descrizione, importo, data)
            VALUES (?, ?, ?, ?, ?)
            """,
            ("uscita", "collaboratori", descrizione, totale_compenso, now_iso_date()),
        )
        movimento_id = c.lastrowid

        PDF_DIR.mkdir(parents=True, exist_ok=True)
        cleanup_old_files(PDF_DIR, "ricevuta_collaboratore_*.pdf", keep=60)
        file_name = (
            f"ricevuta_collaboratore_{collaboratore_id}_{anno}_{mese:02d}_"
            f"{now().strftime('%Y%m%d_%H%M%S_%f')}.pdf"
        )
        file_path = PDF_DIR / file_name

        pdf = canvas.Canvas(str(file_path), pagesize=A4)
        width, height = A4
        left = 42
        right = width - 42
        top = height - 42
        usable_width = right - left

        pdf.setFillColor(colors.whitesmoke)
        pdf.rect(0, 0, width, height, fill=1, stroke=0)

        pdf.setFillColor(colors.HexColor("#18324d"))
        pdf.roundRect(left, top - 120, usable_width, 102, 14, fill=1, stroke=0)

        cfg = load_config()
        doc = cfg.get("documenti", {}) if isinstance(cfg.get("documenti"), dict) else {}
        header_title = (doc.get("denominazione") or cfg.get("nome_asd") or "ASD").strip()
        cf = (doc.get("cf") or "").strip()
        piva = (doc.get("piva") or "").strip()
        sede = " ".join(
            part
            for part in [
                (doc.get("sede_indirizzo") or "").strip(),
                (doc.get("sede_cap") or "").strip(),
                (doc.get("sede_comune") or "").strip(),
            ]
            if part
        ).strip()
        provincia = (doc.get("sede_provincia") or "").strip()
        if provincia:
            sede = f"{sede} ({provincia})".strip()
        contatti = " • ".join(
            part
            for part in [
                (doc.get("telefono") or "").strip(),
                (doc.get("email") or "").strip(),
                (doc.get("pec") or "").strip(),
            ]
            if part
        )

        pdf.setFillColor(colors.white)
        pdf.setFont("Helvetica-Bold", 16)
        pdf.drawString(left + 20, top - 34, truncate(header_title, 72))
        pdf.setFont("Helvetica", 9)
        line_y = top - 49
        for line in [
            " - ".join(
                part for part in [f"C.F. {cf}" if cf else "", f"P.IVA {piva}" if piva else ""] if part
            ),
            sede,
            contatti,
        ]:
            if line:
                pdf.drawString(left + 20, line_y, truncate(line, 95))
                line_y -= 12

        title_y = top - 150
        pdf.setFillColor(colors.HexColor("#111827"))
        pdf.setFont("Helvetica-Bold", 20)
        pdf.drawString(left, title_y, "RICEVUTA COLLABORATORE")
        pdf.setFont("Helvetica", 10)
        pdf.setFillColor(colors.HexColor("#4b5563"))
        pdf.drawRightString(right, title_y, f"Data emissione: {now().strftime('%d/%m/%Y')}")

        box_top = top - 178
        box_height = 255
        pdf.setFillColor(colors.white)
        pdf.setStrokeColor(colors.HexColor("#d1d5db"))
        pdf.roundRect(left, box_top - box_height, usable_width, box_height, 12, fill=1, stroke=1)

        label_x = left + 18
        value_x = left + 170
        row_y = box_top - 34

        rows_pdf = [
            ("Collaboratore", f"{collab['nome']} {collab['cognome']}"),
            ("Periodo", f"{mese:02d}/{anno:04d}"),
            ("Totale ore", f"{totale_ore:.2f}"),
            ("Paga oraria", euro(paga_oraria)),
            ("Totale compenso", euro(totale_compenso)),
            ("Descrizione", descrizione),
        ]

        for label, value in rows_pdf:
            pdf.setFillColor(colors.HexColor("#1f2937"))
            pdf.setFont("Helvetica-Bold", 10)
            pdf.drawString(label_x, row_y, label)
            pdf.setFillColor(colors.black)
            pdf.setFont("Helvetica", 10)
            pdf.drawString(value_x, row_y, truncate(str(value), 80))
            row_y -= 28

        pdf.setFillColor(colors.HexColor("#1f2937"))
        pdf.setFont("Helvetica-Bold", 10)
        pdf.drawString(label_x, row_y - 10, "Dichiarazione")
        pdf.setFont("Helvetica", 10)
        pdf.drawString(
            label_x,
            row_y - 30,
            truncate(
                f"Si attesta la liquidazione del compenso di {euro(totale_compenso)} per l'attività svolta nel periodo {mese:02d}/{anno:04d}.",
                120,
            ),
        )

        pdf.setStrokeColor(colors.HexColor("#cbd5e1"))
        pdf.line(left, 122, right, 122)
        pdf.setFillColor(colors.HexColor("#111827"))
        pdf.setFont("Helvetica", 9)
        firmatario = (doc.get("presidente") or cfg.get("firma") or "").strip()
        if firmatario:
            pdf.drawString(left, 102, truncate(f"Firma ASD: {firmatario}", 90))

        pdf.save()

        if not file_path.exists() or file_path.stat().st_size <= 0:
            raise RuntimeError("Il PDF della ricevuta collaboratore non è stato creato sul disco.")

        c.execute(
            """
            INSERT INTO collaboratori_ricevute(
                collaboratore_id, mese, anno, totale_ore, paga_oraria,
                totale_compenso, data_generazione, filename, movimento_id
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                collaboratore_id,
                mese,
                anno,
                totale_ore,
                paga_oraria,
                totale_compenso,
                now_iso_date(),
                file_name,
                movimento_id,
            ),
        )

        c.execute(
            """
            UPDATE ore_collaboratori
            SET liquidato=1, mese=?, anno=?
            WHERE collaboratore_id=?
              AND COALESCE(mese, CAST(strftime('%m', data) AS INTEGER))=?
              AND COALESCE(anno, CAST(strftime('%Y', data) AS INTEGER))=?
              AND COALESCE(liquidato, 0)=0
            """,
            (mese, anno, collaboratore_id, mese, anno),
        )

        conn.commit()

    except Exception as exc:
        conn.rollback()
        conn.close()
        return redirect_with_message(
            "/collaboratori",
            f"Errore durante la chiusura mese collaboratore: {exc}",
            "error",
            mese=mese,
            anno=anno,
        )

    conn.close()

    return redirect_with_message(
        "/collaboratori",
        f"Mese chiuso correttamente. Ricevuta collaboratore generata. Totale liquidato: {euro(totale_compenso)}.",
        "success",
        mese=mese,
        anno=anno,
    )


@app.route("/collaboratori/delete", methods=["POST"])
@login_required
def collaboratori_delete():
    rec_id = parse_int(request.form.get("id"), 0)
    mese_view = parse_int(request.form.get("mese_view", current_month_year()[0]), current_month_year()[0])
    anno_view = parse_int(request.form.get("anno_view", current_month_year()[1]), current_month_year()[1])

    conn = db()
    c = conn.cursor()

    row = c.execute("SELECT foto FROM collaboratori WHERE id=?", (rec_id,)).fetchone()
    if not row:
        conn.close()
        return redirect_with_message(
            "/collaboratori",
            "Collaboratore non trovato.",
            "error",
            mese=mese_view,
            anno=anno_view,
        )

    delete_uploaded_image(row["foto"] or "")
    c.execute("DELETE FROM collaboratori WHERE id=?", (rec_id,))
    conn.commit()
    conn.close()

    return redirect_with_message(
        "/collaboratori",
        "Collaboratore eliminato.",
        "success",
        mese=mese_view,
        anno=anno_view,
    )


@app.route("/collaboratori/delete_ora", methods=["POST"])
@login_required
def collaboratori_delete_ora():
    rec_id = parse_int(request.form.get("id"), 0)
    mese_view = parse_int(request.form.get("mese_view", current_month_year()[0]), current_month_year()[0])
    anno_view = parse_int(request.form.get("anno_view", current_month_year()[1]), current_month_year()[1])

    conn = db()
    c = conn.cursor()

    row = c.execute(
        "SELECT liquidato FROM ore_collaboratori WHERE id=?",
        (rec_id,),
    ).fetchone()

    if not row:
        conn.close()
        return redirect_with_message(
            "/collaboratori",
            "Riga ore non trovata.",
            "error",
            mese=mese_view,
            anno=anno_view,
        )

    if int(row["liquidato"] or 0) == 1:
        conn.close()
        return redirect_with_message(
            "/collaboratori",
            "Non puoi eliminare una riga già liquidata.",
            "error",
            mese=mese_view,
            anno=anno_view,
        )

    deleted = c.execute("DELETE FROM ore_collaboratori WHERE id=?", (rec_id,)).rowcount
    conn.commit()
    conn.close()

    if not deleted:
        return redirect_with_message(
            "/collaboratori",
            "Riga ore non trovata.",
            "error",
            mese=mese_view,
            anno=anno_view,
        )

    return redirect_with_message(
        "/collaboratori",
        "Riga ore eliminata.",
        "success",
        mese=mese_view,
        anno=anno_view,
    )


