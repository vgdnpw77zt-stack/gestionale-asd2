from .core import *

# PRENOTAZIONI
# ==============================
@app.route("/prenotazioni", methods=["GET", "POST"])
@login_required
def prenotazioni():
   conn = db()
   c = conn.cursor()
   selected_date = parse_date_input(request.args.get("data", "").strip()) or now_iso_date()

   if request.method == "POST":
       try:
           t_id = parse_int(request.form.get("tesserato_id", "0"))
           c_id = parse_int(request.form.get("corso_id", "0"))
           if t_id <= 0 or c_id <= 0:
               raise ValueError("Tesserato o corso non validi.")
           data = require_valid_date(request.form.get("data_pren", "").strip(), "la data prenotazione")
       except ValueError as exc:
           conn.close()
           return layout(alert_html(str(exc), "error"))

       max_row = c.execute("SELECT nome, max_iscritti FROM corsi WHERE id=?", (c_id,)).fetchone()
       if not max_row:
           conn.close()
           return layout(alert_html("Corso non trovato.", "error"))

       max_iscritti = int(max_row["max_iscritti"] or 0)
       if max_iscritti > 0:
           count = c.execute("SELECT COUNT(*) FROM prenotazioni WHERE corso_id=? AND data=?", (c_id, data)).fetchone()[0]
           if count >= max_iscritti:
               conn.close()
               return redirect_with_message("/prenotazioni", f"Il corso {max_row['nome']} è al completo per la data selezionata.", "error", data=data)

       try:
           c.execute("INSERT INTO prenotazioni(tesserato_id, corso_id, data) VALUES (?, ?, ?)", (t_id, c_id, data))
           conn.commit()
       except sqlite3.IntegrityError:
           conn.close()
           return redirect_with_message("/prenotazioni", "Prenotazione già presente per questa data.", "warning", data=data)

       conn.close()
       return redirect_with_message("/prenotazioni", "Prenotazione salvata.", "success", data=data)

   tesserati_list = c.execute("SELECT id, nome, cognome FROM tesserati ORDER BY cognome, nome").fetchall()
   corsi_list = c.execute("SELECT id, nome, max_iscritti FROM corsi ORDER BY nome").fetchall()
   pren = c.execute(
       """
       SELECT p.id, p.data, p.corso_id, t.nome as t_nome, t.cognome as t_cognome, c.nome as corso_nome
       FROM prenotazioni p
       JOIN tesserati t ON t.id = p.tesserato_id
       JOIN corsi c ON c.id = p.corso_id
       WHERE p.data=?
       ORDER BY c.nome, t.cognome, t.nome, p.id DESC
       """,
       (selected_date,),
   ).fetchall()
   occupancy = {
       row['id']: c.execute("SELECT COUNT(*) FROM prenotazioni WHERE corso_id=? AND data=?", (row['id'], selected_date)).fetchone()[0]
       for row in corsi_list
   }
   conn.close()

   options_t = ''.join([f"<option value='{t['id']}'>{e(t['nome'])} {e(t['cognome'])}</option>" for t in tesserati_list])
   options_c = []
   saturi = 0
   for c_r in corsi_list:
       count = occupancy.get(c_r['id'], 0)
       max_iscritti = int(c_r['max_iscritti'] or 0)
       if max_iscritti > 0 and count >= max_iscritti:
           saturi += 1
       posti = f"{count}/{max_iscritti}" if max_iscritti > 0 else f"{count}/∞"
       options_c.append(f"<option value='{c_r['id']}'>{e(c_r['nome'])} - posti {posti}</option>")
   rows = []
   for r in pren:
       rows.append(f"""
       <tr>
           <td><strong>{e(r['t_nome'])} {e(r['t_cognome'])}</strong></td>
           <td>{e(r['corso_nome'])}</td>
           <td>{e(format_display_date(r['data']))}</td>
           <td>
               <form method='POST' action='/prenotazioni/delete' class='inline-form' onsubmit="return confirm('Annullare questa prenotazione?');">
                   {csrf_input()}
                   <input type='hidden' name='id' value='{r['id']}'>
                   <input type='hidden' name='data' value='{selected_date}'>
                   <button class='danger'>Annulla</button>
               </form>
           </td>
       </tr>""")
   table_html = ''.join(rows) if rows else "<tr><td colspan='4'><div class='empty-state'>Nessuna prenotazione registrata per questa data.</div></td></tr>"

   return layout(f"""
   <div class='app-section-hero'>
       <div class='kicker'>Agenda corsi</div>
       <h2 class='section-title'>Prenotazioni</h2>
       <div class='small-muted'>Controlla rapidamente l’occupazione dei corsi per giornata, registra nuove prenotazioni e annulla quelle non più valide.</div>
   </div>
   <div class='metric-strip'>
      <div class='metric-box'><div class='label'>Data selezionata</div><div class='value' style='font-size:1.18rem;'>{e(format_display_date(selected_date))}</div></div>
      <div class='metric-box'><div class='label'>Prenotazioni</div><div class='value'>{len(pren)}</div></div>
      <div class='metric-box'><div class='label'>Corsi configurati</div><div class='value'>{len(corsi_list)}</div></div>
      <div class='metric-box'><div class='label'>Corsi saturi</div><div class='value'>{saturi}</div></div>
   </div>
   <div class='grid-2'>
      <div class='card form-panel'>
        <div class='kicker'>Filtro agenda</div>
        <h3 class='section-title'>Carica giornata</h3>
        <form method='GET' class='form-row' style='margin-bottom:10px;'>
           <input type='date' name='data' value='{selected_date}'>
           <button type='submit'>Mostra data</button>
        </form>
        <div class='small-muted'>La vista lavora su una singola data per mantenere il controllo rapido sui posti disponibili.</div>
      </div>
      <div class='card form-panel'>
        <div class='kicker'>Nuova prenotazione</div>
        <h3 class='section-title'>Inserimento assistito</h3>
        <form method='POST' class='form-row'>
           {csrf_input()}
           <select name='tesserato_id'>{options_t}</select>
           <select name='corso_id'>{''.join(options_c)}</select>
           <input type='date' name='data_pren' value='{selected_date}' required>
           <button>Prenota</button>
        </form>
      </div>
   </div>
   <div class='card'>
      <div class='table-toolbar'>
          <div>
              <div class='kicker'>Elenco del giorno</div>
              <h3 class='section-title' style='margin-bottom:4px;'>Prenotazioni registrate</h3>
              <div class='small-muted'>La tabella segue l’ordine corso → cognome → nome.</div>
          </div>
      </div>
      <table>
         <tr><th>Tesserato</th><th>Corso</th><th>Data</th><th>Azioni</th></tr>
         {table_html}
      </table>
   </div>
   """)


@app.route("/prenotazioni/delete", methods=["POST"])
@login_required
def prenotazioni_delete():
   rec_id = parse_int(request.form.get("id"), 0)
   selected_date = parse_date_input(request.form.get("data", "").strip()) or now_iso_date()
   conn = db()
   conn.execute("DELETE FROM prenotazioni WHERE id=?", (rec_id,))
   conn.commit()
   conn.close()
   return redirect_with_message("/prenotazioni", "Prenotazione annullata.", "success", data=selected_date)
