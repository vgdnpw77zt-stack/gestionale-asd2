from __future__ import annotations

from datetime import datetime
from pathlib import Path
import os
import sys
from typing import Any
import re

from docx import Document
from docx.shared import Inches

try:
    from PIL import Image
except Exception:  # pillow optional
    Image = None


def _get(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value).strip()


def _row_value(row: Any, field: str) -> str:
    if row is None:
        return ""
    try:
        value = row[field]
    except Exception:
        try:
            value = row.get(field, "")
        except Exception:
            value = getattr(row, field, "")
    return _get(value)


def _format_date(value: str) -> str:
    text = _get(value)
    if not text:
        return ""
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(text, fmt).strftime("%d/%m/%Y")
        except Exception:
            pass
    return text


def current_sport_season() -> str:
    now = datetime.now()
    year = now.year
    if now.month >= 9:
        return f"{year}/{year + 1}"
    return f"{year - 1}/{year}"


def _full_address(doc: dict) -> str:
    parts = [
        _get(doc.get("sede_indirizzo")),
        _get(doc.get("sede_cap")),
        _get(doc.get("sede_comune")),
    ]
    text = " ".join(p for p in parts if p).strip()
    prov = _get(doc.get("sede_provincia"))
    if prov:
        text = f"{text} ({prov})".strip()
    return text


def _contacts(doc: dict) -> str:
    parts = [
        _get(doc.get("telefono")),
        _get(doc.get("email")),
        _get(doc.get("pec")),
    ]
    return " • ".join(p for p in parts if p)


def _logo_path(cfg: dict) -> str:
    """Trova il logo caricato nelle Impostazioni/tenant anche quando il valore
    salvato è relativo a /static, a tenants/<slug>/..., oppure contiene già
    un path assoluto. Fallback su app_icon/logo_enterprise.
    """
    raw = _get(cfg.get("logo"))
    values = []
    if raw:
        values.append(raw.lstrip("/"))
        if raw.startswith("/static/"):
            values.append(raw.replace("/static/", "", 1))
    values.extend(["default_asd_logo.png", "app_icon.png", "logo_enterprise.png"])

    env_dir = os.environ.get("ASD_PRO_DATA_DIR", "").strip()
    if env_dir:
        data_dir = Path(env_dir).expanduser()
    elif sys.platform == "darwin":
        data_dir = Path.home() / "Library" / "Application Support" / "ASD Pro Goldclass"
    elif os.name == "nt":
        data_dir = Path(os.environ.get("APPDATA", str(Path.home()))) / "ASD Pro Goldclass"
    else:
        data_dir = Path.home() / ".asd_pro_goldclass"

    app_root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
    roots = [
        data_dir / "user_static",
        data_dir / "tenant_assets",
        data_dir / "media",
        app_root / "static",
        Path.cwd() / "static",
        app_root,
        Path.cwd(),
    ]
    for value in values:
        p = Path(value)
        candidates = [p] if p.is_absolute() else [root / value for root in roots]
        for path in candidates:
            try:
                if path.exists() and path.is_file():
                    return str(path)
            except Exception:
                pass
    return ""


def build_placeholder_map(cfg: dict, tesserato: Any) -> dict[str, str]:
    doc = cfg.get("documenti", {}) if isinstance(cfg.get("documenti"), dict) else {}

    nome = _row_value(tesserato, "nome")
    cognome = _row_value(tesserato, "cognome")
    telefono = _row_value(tesserato, "telefono")
    corso = _row_value(tesserato, "corso")
    cert = _format_date(_row_value(tesserato, "certificato_scadenza"))
    luogo_nascita = _row_value(tesserato, "luogo_nascita")
    data_nascita = _format_date(_row_value(tesserato, "data_nascita"))
    codice_fiscale = _row_value(tesserato, "codice_fiscale")
    residenza = _row_value(tesserato, "residenza")
    email = _row_value(tesserato, "email")
    documento_identita = _row_value(tesserato, "documento_identita")
    pacchetto = _row_value(tesserato, "pacchetto_tipo")
    ingressi_totali = _row_value(tesserato, "ingressi_totali")
    ingressi_residui = _row_value(tesserato, "ingressi_residui")
    pacchetto_scadenza = _format_date(_row_value(tesserato, "pacchetto_scadenza"))
    pacchetto_data_acquisto = _format_date(_row_value(tesserato, "pacchetto_data_acquisto"))
    pacchetto_note = _row_value(tesserato, "pacchetto_note")
    pacchetto_cert = _row_value(tesserato, "pacchetto_certificato_richiesto")

    genitore = _row_value(tesserato, "genitore") or _row_value(tesserato, "nome_genitore")
    telefono_genitore = _row_value(tesserato, "telefono_genitore")
    email_genitore = _row_value(tesserato, "email_genitore")

    denominazione = _get(doc.get("denominazione")) or _get(cfg.get("nome_asd")) or "ASD"
    cf_asd = _get(doc.get("cf"))
    piva_asd = _get(doc.get("piva"))
    indirizzo_completo = _full_address(doc)
    contatti_asd = _contacts(doc)
    presidente = _get(doc.get("presidente")) or _get(cfg.get("firma"))
    legale_rappresentante = presidente
    affiliazione = _get(doc.get("affiliazione"))
    referente_privacy = _get(doc.get("referente_privacy"))
    numero_affiliazione = _get(doc.get("numero_affiliazione"))
    pec_asd = _get(doc.get("pec"))
    iban_asd = _get(doc.get("iban")) or _get(cfg.get("iban"))
    sito_web = _get(doc.get("sito_web"))
    luogo_firma = _get(doc.get("luogo_firma"))
    foro_competente = _get(doc.get("foro_competente"))
    note_legali = _get(doc.get("note_legali"))
    branding = cfg.get("branding", {}) if isinstance(cfg.get("branding"), dict) else {}

    base_mapping = {
        "__LOGO_IMAGE_PATH__": _logo_path(cfg),
        "[LOGO ASD]": "",
        "[DENOMINAZIONE ASD]": denominazione,
        "[CF ASD]": cf_asd,
        "[PIVA ASD]": piva_asd,
        "[indirizzo completo]": indirizzo_completo,
        "[CONTATTI ASD]": contatti_asd,
        "[EMAIL ASD]": pec_asd or _get(doc.get("email")),
        "[TELEFONO ASD]": _get(doc.get("telefono")),
        "[SEDE LEGALE ASD]": indirizzo_completo,
        "[INDIRIZZO SEDE ASD]": _get(doc.get("sede_indirizzo")),
        "[CAP SEDE ASD]": _get(doc.get("sede_cap")),
        "[COMUNE SEDE ASD]": _get(doc.get("sede_comune")),
        "[PROVINCIA SEDE ASD]": _get(doc.get("sede_provincia")),
        "[PRESIDENTE]": presidente,
        "[LEGALE RAPPRESENTANTE]": legale_rappresentante,
        "[REFERENTE PRIVACY]": referente_privacy,
        "[AFFILIAZIONE]": affiliazione,
        "[NUMERO AFFILIAZIONE]": numero_affiliazione,
        "[PEC ASD]": pec_asd,
        "[IBAN ASD]": iban_asd,
        "[SITO WEB ASD]": sito_web,
        "[LUOGO FIRMA]": luogo_firma,
        "[FORO COMPETENTE]": foro_competente,
        "[NOTE LEGALI]": note_legali,
        "[CONSENSO IMMAGINI]": "",
        "[DATA INIZIO]": "",
        "[DATA FINE]": "",
        "[PREAVVISO]": "30",
        "[PARTI CONTRAENTI]": "",
        "[GIORNI ORARI]": "",
        "[COSTI UTILIZZO]": "",
        "[SOFTWARE]": _get(branding.get("app_name")) or "Asd Pro System",
        "[NOME E COGNOME]": f"{nome} {cognome}".strip(),
        "[NOME]": nome,
        "[COGNOME]": cognome,
        "[TELEFONO TESSERATO]": telefono,
        "[EMAIL TESSERATO]": email,
        "[EMAIL]": email,
        "[CODICE FISCALE]": codice_fiscale,
        "[INDIRIZZO TESSERATO]": residenza,
        "[LUOGO NASCITA]": luogo_nascita,
        "[DATA NASCITA]": data_nascita,
        "[DOCUMENTO IDENTITA]": documento_identita,
        "[DISCIPLINA]": corso,
        "[DISCIPLINA PRATICATA]": corso,
        "[STAGIONE SPORTIVA]": current_sport_season(),
        "[NUMERO QUIETANZA]": "",
        "[CAUSALE PAGAMENTO]": "",
        "[QUOTA ASSOCIATIVA]": "",
        "[QUOTA CORSO]": "",
        "[QUOTA ASSICURAZIONE]": "",
        "[ALTRI IMPORTI]": "",
        "[TOTALE VERSATO]": "",
        "[DATA PAGAMENTO]": "",
        "[RIFERIMENTO OPERAZIONE]": "",
        "[TIPO CERTIFICATO]": "",
        "[Data scadenza certificato]": cert,
        "[MEDICO CERTIFICATORE]": "",
        "[DATA CONSEGNA]": "",
        "[LUOGO E DATA]": (f"{luogo_firma}, " if luogo_firma else "") + datetime.now().strftime("%d/%m/%Y"),
        "[DESTINATARI DATI]": "EPS/FSN/DSA di affiliazione, consulenti amministrativi e soggetti autorizzati nei limiti di legge",
        "[GENITORE PAGANTE]": genitore,
        "[GENITORE]": genitore,
        "[NOME GENITORE]": genitore,
        "[NOME TUTORE]": genitore,
        "[MINORE TESSERATO]": f"{nome} {cognome}".strip(),
        "[GENITORE/TUTORE]": genitore,
        "[TUTORE]": genitore,
        "[TELEFONO GENITORE]": telefono_genitore,
        "[EMAIL GENITORE]": email_genitore,
        "[DATA CONSENSO]": _format_date(_row_value(tesserato, "data_consenso")) or datetime.now().strftime("%d/%m/%Y"),
        "[PERIODO RIFERIMENTO]": current_sport_season(),
        "[IMPORTO PAGATO]": "",
        "[RIFERIMENTO NORMATIVO]": "",
        "[ANNO FISCALE]": str(datetime.now().year),
        "[TIPOLOGIA ATTIVITA]": corso or "Supporto organizzativo / sportivo",
        "[VALUTAZIONE]": "Partecipazione regolare e proficua.",
        "[PERIODO ATTIVITA]": current_sport_season(),
        "[SPONSOR]": "",
        "[DURATA CONTRATTO]": "",
        "[CORRISPETTIVO]": "",
        "[KPI REPORT]": "",
        "[FORO COMPETENTE]": "",
        "[CODICE TRIBUTO]": "",
        "[RATEAZIONE]": "",
        "[IMPORTO A CREDITO]": "",
        "[NOTE F24]": "",
        "[PARTI CONTRAENTI]": "",
        "[GIORNI ORARI]": "",
        "[COSTI UTILIZZO]": "",
        "[PACCHETTO]": pacchetto,
        "[TIPO PACCHETTO]": pacchetto,
        "[INGRESSI TOTALI]": ingressi_totali,
        "[INGRESSI RESIDUI]": ingressi_residui,
        "[SCADENZA PACCHETTO]": pacchetto_scadenza,
        "[DATA ACQUISTO PACCHETTO]": pacchetto_data_acquisto,
        "[NOTE PACCHETTO]": pacchetto_note,
        "[CERTIFICATO RICHIESTO]": pacchetto_cert,

        "[NUMERO ISCRIZIONE RASD]": "",
        "[NUMERO RASD]": "",
        "[CODICE RASD]": "",
        "[COMPETENZE OSSERVATE]": "costanza nella frequenza; rispetto delle regole; coordinazione motoria; collaborazione con il gruppo; progressione tecnica coerente.",
        "[DATI TESSERATO]": f"{nome} {cognome} - CF {codice_fiscale} - nato/a a {luogo_nascita} il {data_nascita} - residente in {residenza}".strip(" -"),
    }

    return base_mapping




def _prepare_logo_for_docx(logo_path: str) -> str:
    """Rende leggibile nei DOCX anche un logo bianco/trasparente su pagina bianca.
    Se il logo ha canale alpha, lo compone su fondo antracite in una cache temporanea.
    """
    if not logo_path or Image is None:
        return logo_path
    try:
        src = Path(logo_path)
        if not src.exists():
            return logo_path
        img = Image.open(src).convert("RGBA")
        alpha = img.getchannel("A")
        # Se c'è trasparenza significativa, crea un riquadro scuro elegante.
        if alpha.getextrema()[0] < 250:
            pad = max(18, img.width // 18)
            bg = Image.new("RGBA", (img.width + pad * 2, img.height + pad * 2), (8, 15, 28, 255))
            bg.alpha_composite(img, (pad, pad))
            cache = Path("/tmp/asd_pro_docx_logo_cache")
            cache.mkdir(parents=True, exist_ok=True)
            out = cache / (src.stem + "_docx_visible.png")
            bg.save(out)
            return str(out)
    except Exception:
        return logo_path
    return logo_path

def _insert_logo(paragraph, logo_path: str) -> bool:
    if not logo_path:
        return False
    try:
        for run in paragraph.runs:
            run.text = ""
        run = paragraph.runs[0] if paragraph.runs else paragraph.add_run()
        run.add_picture(_prepare_logo_for_docx(logo_path), width=Inches(1.25))
        return True
    except Exception:
        return False


def _replace_in_paragraph(paragraph, mapping: dict[str, str]) -> None:
    text = "".join(run.text for run in paragraph.runs) if paragraph.runs else (paragraph.text or "")
    if not text:
        return

    if "[LOGO ASD]" in text:
        if _insert_logo(paragraph, mapping.get("__LOGO_IMAGE_PATH__", "")):
            text = "".join(run.text for run in paragraph.runs) if paragraph.runs else (paragraph.text or "")
        else:
            text = text.replace("[LOGO ASD]", "")

    new_text = text
    for key, val in mapping.items():
        if key.startswith("__"):
            continue
        new_text = new_text.replace(key, val or "")

    if new_text == text:
        unresolved = re.findall(r"\[[^\[\]]+\]", text)
        if not unresolved:
            return
        for token in unresolved:
            new_text = new_text.replace(token, mapping.get(token, ""))

    if new_text == text:
        return

    if not paragraph.runs:
        paragraph.text = new_text
        return

    first_run = paragraph.runs[0]
    for run in paragraph.runs:
        run.text = ""
    first_run.text = new_text


def _replace_in_cell(cell, mapping: dict[str, str]) -> None:
    for paragraph in cell.paragraphs:
        _replace_in_paragraph(paragraph, mapping)
    for table in cell.tables:
        for row in table.rows:
            for inner_cell in row.cells:
                _replace_in_cell(inner_cell, mapping)


def _replace_everywhere(doc: Document, mapping: dict[str, str]) -> None:
    for paragraph in doc.paragraphs:
        _replace_in_paragraph(paragraph, mapping)

    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                _replace_in_cell(cell, mapping)

    for section in doc.sections:
        header = section.header
        footer = section.footer
        for paragraph in header.paragraphs:
            _replace_in_paragraph(paragraph, mapping)
        for paragraph in footer.paragraphs:
            _replace_in_paragraph(paragraph, mapping)
        for table in header.tables:
            for row in table.rows:
                for cell in row.cells:
                    _replace_in_cell(cell, mapping)
        for table in footer.tables:
            for row in table.rows:
                for cell in row.cells:
                    _replace_in_cell(cell, mapping)


def _ensure_header_logo(doc: Document, logo_path: str) -> None:
    """Inserisce sempre il branding ASD nell'intestazione del DOCX.

    Se il modello contiene già un'immagine nel primo header non duplica il logo.
    In questo modo anche i modelli DOCX privi del placeholder [LOGO ASD] restano
    documenti professionali e coerenti.
    """
    if not logo_path:
        return
    try:
        for section in doc.sections:
            header = section.header
            if '<pic:pic' in header._element.xml:
                continue
            para = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
            para.alignment = 1
            run = para.add_run()
            run.add_picture(_prepare_logo_for_docx(logo_path), width=Inches(1.15))
    except Exception:
        # Il contenuto del documento resta comunque valido anche se il logo
        # non è disponibile; il modello può essere aperto e corretto dal cliente.
        return


def compile_docx(template_path: Path, output_path: Path, mapping: dict[str, str]) -> Path:
    doc = Document(str(template_path))
    _ensure_header_logo(doc, mapping.get("__LOGO_IMAGE_PATH__", ""))
    _replace_everywhere(doc, mapping)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(output_path))
    return output_path
