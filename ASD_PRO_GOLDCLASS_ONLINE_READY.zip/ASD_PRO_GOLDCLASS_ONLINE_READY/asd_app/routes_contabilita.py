from .core import *

# CONTABILITA
# ==============================
@app.route("/contabilita", methods=["GET", "POST"])
@login_required
def contabilita():
   conn = db()
   c = conn.cursor()

   edit_row = None
   edit_id = parse_int(request.args.get("edit", "0"), 0)
   if edit_id > 0:
       edit_row = c.execute("SELECT * FROM movimenti WHERE id=?", (edit_id,)).fetchone()
       if edit_row and (int(edit_row["auto_generato"] or 0) == 1 or edit_row["pagamento_id"]):
           edit_row = None

   if request.method == "POST":
       action = (request.form.get("action") or "create").strip().lower()
       tipo = request.form.get("tipo", "").strip()
       importo = parse_float(request.form.get("importo", 0))
       if tipo not in ("entrata", "uscita"):
           conn.close()
           return layout(alert_html("Tipo movimento non valido.", "error"))
       if importo <= 0:
           conn.close()
           return layout(alert_html("L'importo deve essere maggiore di zero.", "error"))

       categoria = truncate(request.form.get("categoria", "").strip(), 120)
       descrizione = truncate(request.form.get("descrizione", "").strip(), 200)
       data_mov = require_valid_date(request.form.get("data", "").strip(), "la data") if request.form.get("data", "").strip() else now_iso_date()

       if action == "update":
           rec_id = parse_int(request.form.get("id", "0"), 0)
           row = c.execute("SELECT * FROM movimenti WHERE id=?", (rec_id,)).fetchone()
           if not row:
               conn.close()
               return redirect_with_message("/contabilita", "Movimento non trovato.", "error")
           if int(row["auto_generato"] or 0) == 1 or row["pagamento_id"]:
               conn.close()
               return redirect_with_message("/contabilita", "I movimenti automatici non possono essere modificati da qui.", "warning")

           c.execute(
               "UPDATE movimenti SET tipo=?, categoria=?, descrizione=?, importo=?, data=? WHERE id=?",
               (tipo, categoria, descrizione, importo, data_mov, rec_id),
           )
           conn.commit()
           conn.close()
           return redirect_with_message("/contabilita", "Movimento contabile aggiornato.", "success")

       c.execute(
           "INSERT INTO movimenti(tipo, categoria, descrizione, importo, data, pagamento_id, auto_generato) VALUES (?, ?, ?, ?, ?, NULL, 0)",
           (tipo, categoria, descrizione, importo, data_mov),
       )
       conn.commit()
       conn.close()
       return redirect_with_message("/contabilita", "Movimento contabile salvato.", "success")

   rows = c.execute("SELECT * FROM movimenti ORDER BY data DESC, id DESC").fetchall()
   totale_entrate = c.execute("SELECT COALESCE(SUM(importo), 0) FROM movimenti WHERE tipo='entrata'").fetchone()[0]
   totale_uscite = c.execute("SELECT COALESCE(SUM(importo), 0) FROM movimenti WHERE tipo='uscita'").fetchone()[0]
   conn.close()

   form_action = "update" if edit_row else "create"
   button_label = "Aggiorna" if edit_row else "Salva"

   saldo_cont = float(totale_entrate or 0) - float(totale_uscite or 0)

   html_out = f"""
   <div class='app-section-hero'>
       <div class='kicker'>Flussi e bilancio</div>
       <h2 class='section-title'>Contabilità</h2>
       <div class='small-muted'>Questa sezione gestisce i movimenti manuali e protegge quelli automatici generati dal sistema.</div>
   </div>
   <div class='metric-strip'>
       <div class='metric-box'><div class='label'>Entrate</div><div class='value'>{euro(totale_entrate)}</div></div>
       <div class='metric-box'><div class='label'>Uscite</div><div class='value'>{euro(totale_uscite)}</div></div>
       <div class='metric-box'><div class='label'>Saldo</div><div class='value'>{euro(saldo_cont)}</div></div>
       <div class='metric-box'><div class='label'>Movimenti</div><div class='value'>{len(rows)}</div></div>
   </div>
   <div class="card">
       <div class="page-head">
           <div>
               <div class="kicker">Flussi</div>
               <h2 class="section-title">Contabilità</h2>
           </div>
       </div>
       <div class='table-toolbar'><div><div class='kicker'>Operatività manuale</div><h3 class='section-title' style='margin-bottom:4px;'>Movimenti inseriti a mano</h3><div class='small-muted'>Qui puoi creare, correggere o eliminare solo i movimenti manuali. I movimenti automatici restano protetti.</div></div></div>
       <form method="POST" class="form-row">
   """
   html_out += csrf_input()
   html_out += f"""
           <input type="hidden" name="action" value="{form_action}">
           <input type="hidden" name="id" value="{edit_row['id'] if edit_row else ''}">
           <select name="tipo">
               <option value="entrata" {'selected' if (edit_row and edit_row['tipo'] == 'entrata') else ''}>Entrata</option>
               <option value="uscita" {'selected' if (edit_row and edit_row['tipo'] == 'uscita') else ''}>Uscita</option>
           </select>
           <input name="categoria" placeholder="Categoria" value="{e(edit_row['categoria'] if edit_row else '')}">
           <input name="descrizione" placeholder="Descrizione" value="{e(edit_row['descrizione'] if edit_row else '')}">
           <input name="data" placeholder="Data (DD/MM/YYYY)" value="{e(format_display_date(edit_row['data']) if edit_row else format_display_date(now_iso_date()))}">
   """
   html_out += number_input("importo", f"{float(edit_row['importo'] or 0):.2f}" if edit_row else "", "Importo €", "0.01", 0)
   html_out += f"""
           <button>{button_label}</button>
           {"<a href='/contabilita' style='align-self:center;'>Annulla modifica</a>" if edit_row else ""}
       </form>
       <table><tr><th>Tipo</th><th>Categoria</th><th>Descrizione</th><th>Importo</th><th>Data</th><th>Origine</th><th>Azioni</th></tr>
   """
   for r in rows:
       automatico = int(r["auto_generato"] or 0) == 1 or bool(r["pagamento_id"])
       origine = "Pagamento automatico" if automatico else "Manuale"
       actions = "<span class='small-muted'>Bloccato</span>" if automatico else f"""
       <div class='actions'>
           <a href="/contabilita?edit={r['id']}">Modifica</a>
           <form method="POST" action="/contabilita/delete" class="inline-form" onsubmit="return confirm('Eliminare questo movimento contabile?');">
               {csrf_input()}
               <input type="hidden" name="id" value="{r['id']}">
               <button class="danger">Elimina</button>
           </form>
       </div>
       """
       html_out += f"""
       <tr>
           <td>{e(r['tipo'])}</td>
           <td>{e(r['categoria'])}</td>
           <td>{e(r['descrizione'])}</td>
           <td>{euro(r['importo'])}</td>
           <td>{e(format_display_date(r['data']))}</td>
           <td>{origine}</td>
           <td>{actions}</td>
       </tr>"""
   html_out += "</table></div>"
   return layout(html_out)


@app.route("/contabilita/delete", methods=["POST"])
@login_required
def contabilita_delete():
   rec_id = parse_int(request.form.get("id", "0"), 0)
   if rec_id <= 0:
       return redirect_with_message("/contabilita", "Movimento non valido.", "error")

   conn = db()
   c = conn.cursor()
   row = c.execute("SELECT * FROM movimenti WHERE id=?", (rec_id,)).fetchone()
   if not row:
       conn.close()
       return redirect_with_message("/contabilita", "Movimento non trovato.", "error")
   if int(row["auto_generato"] or 0) == 1 or row["pagamento_id"]:
       conn.close()
       return redirect_with_message("/contabilita", "I movimenti automatici non possono essere eliminati da qui.", "warning")

   c.execute("DELETE FROM movimenti WHERE id=?", (rec_id,))
   conn.commit()
   conn.close()
   return redirect_with_message("/contabilita", "Movimento eliminato.", "success")
