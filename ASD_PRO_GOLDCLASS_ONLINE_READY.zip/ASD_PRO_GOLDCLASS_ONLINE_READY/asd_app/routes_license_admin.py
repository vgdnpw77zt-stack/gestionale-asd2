from __future__ import annotations

import json

from .core import *
from .license_manager import (
    find_and_validate_license,
    license_file_path,
    validate_license_file,
    developer_bypass_enabled,
    developer_bypass_path,
)


@app.route('/licenza', methods=['GET', 'POST'])
@login_required
@admin_required
def gestione_licenza():
    lic_path = license_file_path(DATA_DIR)

    if request.method == 'POST':
        action = (request.form.get('action') or '').strip().lower()
        if action == 'upload_license':
            file = request.files.get('license_file')
            if not file or not file.filename:
                return redirect_with_message('/licenza', 'Seleziona un file licenza in formato JSON.', 'error')
            try:
                raw_bytes = file.read()
                raw = json.loads(raw_bytes.decode('utf-8'))
                # Produzione: non ri-firmare qui. Il cliente installa un license.json già firmato
                # dal generatore proprietario; qui si valida e poi si copia nel runtime.
                tmp_path = lic_path.with_suffix('.upload.tmp')
                tmp_path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding='utf-8')
                ok_tmp, payload_tmp = validate_license_file(tmp_path)
                if not ok_tmp:
                    tmp_path.unlink(missing_ok=True)
                    raise ValueError(str(payload_tmp))
                tmp_path.replace(lic_path)
                ok_after, payload_after, _ = find_and_validate_license(DATA_DIR, app_base_dir=BASE_DIR)
                if ok_after:
                    detail = 'Licenza installata e verificata correttamente.'
                    if developer_bypass_enabled(DATA_DIR, app_base_dir=BASE_DIR):
                        detail += ' Nota: la modalità sviluppo è attiva, quindi questa copia continuerà a usare il bypass finché non lo disattivi.'
                    log_audit('license_upload', details=f'Licenza installata e verificata in {lic_path.name}', entity_type='license')
                    return redirect_with_message('/licenza', detail, 'success')
                try:
                    lic_path.unlink(missing_ok=True)
                except Exception:
                    pass
                log_audit('license_upload_failed', details=f'File caricato ma non valido: {payload_after}', entity_type='license', status='error')
                return redirect_with_message('/licenza', f'File caricato ma licenza non valida: {payload_after}', 'error')
            except Exception as exc:
                return redirect_with_message('/licenza', f'Il file licenza non è valido: {exc}', 'error')

        if action == 'remove_license':
            if lic_path.exists():
                lic_path.unlink(missing_ok=True)
            log_audit('license_remove', details='Licenza rimossa', entity_type='license')
            return redirect_with_message('/licenza', 'Licenza rimossa.', 'warning')

    ok, payload, path = find_and_validate_license(DATA_DIR, app_base_dir=BASE_DIR)
    bypass = developer_bypass_enabled(DATA_DIR, app_base_dir=BASE_DIR)
    bypass_file = developer_bypass_path(DATA_DIR)
    status_badge = (
        "<span class='badge ok'>Modalità sviluppo attiva</span>"
        if bypass
        else ("<span class='badge ok'>Licenza attiva</span>" if ok else "<span class='badge bad'>Licenza da caricare</span>")
    )

    if ok and isinstance(payload, dict):
        rows = (
            f"<tr><th>Cliente</th><td>{e(payload.get('cliente') or '-')}</td></tr>"
            f"<tr><th>Codice cliente</th><td>{e(payload.get('codice_cliente') or '-')}</td></tr>"
            f"<tr><th>Piano</th><td>{e(payload.get('piano') or '-')}</td></tr>"
            f"<tr><th>Scadenza</th><td>{e(payload.get('scadenza') or '-')}</td></tr>"
            f"<tr><th>Utenti massimi</th><td>{int(payload.get('max_utenti') or 0)}</td></tr>"
            f"<tr><th>Funzioni abilitate</th><td>{e(', '.join(payload.get('features') or []))}</td></tr>"
        )
        detail_message = 'Licenza valida'
    else:
        rows = "<tr><th>Stato</th><td>Licenza non caricata o non valida</td></tr>"
        detail_message = str(payload)

    usage_text = 'Copia sviluppatore: nessuna licenza cliente richiesta. Se installi una licenza cliente, resterà salvata ma non verrà applicata finché non disattivi la modalità sviluppo.' if bypass else 'Copia cliente: serve una licenza valida.'
    details_text = "\n".join([
        f"Posizione file licenza: {e(str(path))}",
        f"Bypass sviluppo: {'attivo' if bypass else 'disattivo'}",
        f"File modalità sviluppo: {e(str(bypass_file))}",
        f"Messaggio: {e(detail_message)}",
    ])
    details_html = details_block('Mostra dettagli tecnici', details_text)

    html = (
        "<div class='card'>"
        "<div class='page-head'><div><div class='kicker'>Protezione software</div><h2 class='section-title'>Licenza</h2></div><div>" + status_badge + "</div></div>"
        "<p class='small-muted'>Qui installi o sostituisci il file licenza di questa copia del programma.</p>"
        "<table>" + rows + f"<tr><th>Uso di questa copia</th><td>{e(usage_text)}</td></tr></table>" + details_html
        + "<hr><h3>Installa o aggiorna licenza</h3>"
        + "<form method='POST' enctype='multipart/form-data' class='form-row'>" + csrf_input()
        + "<input type='hidden' name='action' value='upload_license'>"
        + "<input type='file' name='license_file' accept='.json' required>"
        + "<button>Installa licenza</button>"
        + "</form>"
        + "<div class='small-muted' style='margin-top:10px;'>Genera il file con il tool già incluso nel pacchetto e poi caricalo qui.</div>"
        + "<hr><h3>Rimuovi licenza</h3>"
        + "<form method='POST' onsubmit=\"return confirm('Rimuovere la licenza da questa installazione?');\">"
        + csrf_input()
        + "<input type='hidden' name='action' value='remove_license'>"
        + "<button class='danger'>Rimuovi licenza</button>"
        + "</form></div>"
    )
    return layout(html)
