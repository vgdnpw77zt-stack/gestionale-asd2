import React from "react";
import "./App.css";
import { HashRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import { AuthProvider, useAuth } from "./lib/auth.jsx";
import Login from "./pages/Login";
import Layout from "./pages/Layout";
import Dashboard from "./pages/Dashboard";
import Soci from "./pages/Soci";
import Tesseramenti from "./pages/Tesseramenti";
import Pagamenti from "./pages/Pagamenti";
import Certificati from "./pages/Certificati";
import Corsi from "./pages/Corsi";
import Presenze from "./pages/Presenze";
import Documenti from "./pages/Documenti";
import Modelli from "./pages/Modelli";
import Iscrizioni from "./pages/Iscrizioni";
import { PaymentSuccess, PaymentCancel } from "./pages/PaymentPages";
import Fatture from "./pages/Fatture";
import Giornata from "./pages/Giornata";
import Utenti from "./pages/Utenti";
import Reminders from "./pages/Reminders";
import MobileIstruttore from "./pages/MobileIstruttore";
import InstallPwaButton from "./components/InstallPwaButton";
import Comunicazioni from "./pages/Comunicazioni";
import AIAssistant from "./pages/AIAssistant";
import Backup from "./pages/Backup";
import Impostazioni from "./pages/Impostazioni";

function PrivateArea() {
  const { user, loading } = useAuth();
  if (loading) return <div className="p-10 text-slate-500">Caricamento…</div>;
  if (!user) return <Navigate to="/login" replace />;
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/soci" element={<Soci />} />
        <Route path="/tesseramenti" element={<Tesseramenti />} />
        <Route path="/pagamenti" element={<Pagamenti />} />
        <Route path="/certificati" element={<Certificati />} />
        <Route path="/corsi" element={<Corsi />} />
        <Route path="/presenze" element={<Presenze />} />
        <Route path="/documenti" element={<Documenti />} />
        <Route path="/modelli" element={<Modelli />} />
        <Route path="/iscrizioni" element={<Iscrizioni />} />
        <Route path="/fatture" element={<Fatture />} />
        <Route path="/giornata" element={<Giornata />} />
        <Route path="/utenti" element={<Utenti />} />
        <Route path="/reminders" element={<Reminders />} />
        <Route path="/comunicazioni" element={<Comunicazioni />} />
        <Route path="/ai" element={<AIAssistant />} />
        <Route path="/backup" element={<Backup />} />
        <Route path="/impostazioni" element={<Impostazioni />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  );
}

function App() {
  return (
    <div className="App">
      <AuthProvider>
        <HashRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/pagamento/successo" element={<PaymentSuccess />} />
            <Route path="/pagamento/annullato" element={<PaymentCancel />} />
            <Route path="/mobile" element={<MobileIstruttore />} />
            <Route path="/*" element={<PrivateArea />} />
          </Routes>
          <Toaster position="top-right" richColors closeButton />
          <InstallPwaButton />
        </HashRouter>
      </AuthProvider>
    </div>
  );
}

export default App;
