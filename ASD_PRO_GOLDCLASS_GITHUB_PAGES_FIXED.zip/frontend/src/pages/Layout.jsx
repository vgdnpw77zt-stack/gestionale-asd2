import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  LayoutDashboard, Users, IdCard, Receipt, HeartPulse, GraduationCap,
  ClipboardCheck, FolderOpen, MailPlus, Sparkles, DatabaseBackup, Settings,
  LogOut, Trophy, FileType2, Download, CreditCard, CalendarDays, FileText, ShieldCheck,
  BellRing, Smartphone,
} from "lucide-react";
import { useAuth } from "../lib/auth.jsx";

const items = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, testid: "nav-dashboard" },
  { to: "/giornata", label: "Oggi", icon: CalendarDays, testid: "nav-giornata" },
  { to: "/soci", label: "Anagrafica Soci", icon: Users, testid: "nav-soci" },
  { to: "/tesseramenti", label: "Tesseramenti", icon: IdCard, testid: "nav-tesseramenti" },
  { to: "/pagamenti", label: "Quote & Pagamenti", icon: Receipt, testid: "nav-pagamenti" },
  { to: "/fatture", label: "Fatture Elettroniche", icon: FileText, testid: "nav-fatture" },
  { to: "/iscrizioni", label: "Iscrizioni Online", icon: CreditCard, testid: "nav-iscrizioni" },
  { to: "/certificati", label: "Certificati Medici", icon: HeartPulse, testid: "nav-certificati" },
  { to: "/reminders", label: "Reminder Automatici", icon: BellRing, testid: "nav-reminders" },
  { to: "/corsi", label: "Corsi & Calendario", icon: GraduationCap, testid: "nav-corsi" },
  { to: "/presenze", label: "Presenze", icon: ClipboardCheck, testid: "nav-presenze" },
  { to: "/documenti", label: "Documenti Soci", icon: FolderOpen, testid: "nav-documenti" },
  { to: "/modelli", label: "Archivio Modelli", icon: FileType2, testid: "nav-modelli" },
  { to: "/comunicazioni", label: "Comunicazioni", icon: MailPlus, testid: "nav-comunicazioni" },
  { to: "/ai", label: "Assistente AI", icon: Sparkles, testid: "nav-ai" },
  { to: "/backup", label: "Backup / Restore", icon: DatabaseBackup, testid: "nav-backup" },
  { to: "/utenti", label: "Utenti Segreteria", icon: ShieldCheck, testid: "nav-utenti" },
  { to: "/impostazioni", label: "Impostazioni ASD", icon: Settings, testid: "nav-impostazioni" },
];

export default function Layout({ children }) {
  const { user, logout } = useAuth();
  return (
    <div className="min-h-screen flex bg-slate-50">
      <aside className="w-64 shrink-0 hidden md:flex flex-col bg-white border-r border-slate-200 sticky top-0 h-screen">
        <div className="px-5 py-5 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl gradient-header flex items-center justify-center text-white shadow-md">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <div className="font-extrabold tracking-tight text-slate-900">ASD Master</div>
              <div className="text-[11px] uppercase tracking-widest text-slate-400">Segreteria</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {items.map((it) => (
            <NavLink key={it.to} to={it.to} end={it.to === "/"} data-testid={it.testid}
              className={({ isActive }) => `sidebar-item ${isActive ? "active" : ""}`}>
              <it.icon className="w-4 h-4" />
              <span>{it.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="p-3 border-t border-slate-100">
          <div className="flex items-center gap-3 px-2 py-2">
            <div className="w-9 h-9 rounded-full bg-sky-100 text-sky-700 font-bold flex items-center justify-center">
              {(user?.username || "A").slice(0,1).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-slate-900 truncate">{user?.username || "admin"}</div>
              <div className="text-[11px] text-slate-400">Amministratore</div>
            </div>
            <button data-testid="logout-btn" onClick={logout}
              className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-rose-600 transition">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
      <main className="flex-1 min-w-0">
        <div className="max-w-[1400px] mx-auto p-6 sm:p-8">{children}</div>
      </main>
    </div>
  );
}
