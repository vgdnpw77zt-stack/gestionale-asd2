import React, { useState } from "react";
import { API } from "../lib/api";
import { PageHeader, Btn, Badge } from "./_ui";
import { toast } from "sonner";
import { DatabaseBackup, Download, Upload, ShieldCheck, AlertCircle } from "lucide-react";
import axios from "axios";

export default function Backup() {
  const [restoring, setRestoring] = useState(false);
  const [replace, setReplace] = useState(true);
  const [result, setResult] = useState(null);

  const doExport = async () => {
    try {
      const token = localStorage.getItem("asd_token");
      const res = await fetch(`${API}/backup/export`, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error("Errore export");
      const blob = await res.blob();
      const cd = res.headers.get("Content-Disposition") || "";
      const m = /filename="([^"]+)"/.exec(cd);
      const filename = m ? m[1] : `backup_asd_${Date.now()}.zip`;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url; a.download = filename; a.click();
      URL.revokeObjectURL(url);
      toast.success("Backup scaricato");
    } catch (e) { toast.error("Errore export: " + e.message); }
  };

  const doRestore = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!window.confirm(`Sicuro di voler ripristinare da ${file.name}? ${replace ? "Sostituirà" : "Fonderà"} i dati attuali.`)) return;
    setRestoring(true); setResult(null);
    try {
      const token = localStorage.getItem("asd_token");
      const fd = new FormData();
      fd.append("file", file);
      fd.append("replace", replace);
      const r = await axios.post(`${API}/backup/restore`, fd, {
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "multipart/form-data" },
      });
      setResult(r.data);
      toast.success("Ripristino completato");
    } catch (e) {
      const msg = e?.response?.data?.detail || e.message;
      setResult({ error: msg });
      toast.error("Errore restore: " + msg);
    } finally {
      setRestoring(false);
      e.target.value = "";
    }
  };

  return (
    <div>
      <PageHeader title="Backup / Restore" subtitle="Esporta e ripristina l'intera base dati in un unico ZIP." />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="card-elev p-6">
          <div className="w-12 h-12 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center mb-4"><Download className="w-6 h-6" /></div>
          <h3 className="font-bold text-lg mb-1">Esporta backup</h3>
          <p className="text-sm text-slate-500 mb-4">Scarica un ZIP con tutte le collezioni: soci, tesseramenti, pagamenti, certificati, corsi, presenze, documenti, comunicazioni, impostazioni.</p>
          <Btn testid="backup-export-btn" onClick={doExport}><Download className="w-4 h-4" />Scarica ZIP</Btn>
        </div>

        <div className="card-elev p-6">
          <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-4"><Upload className="w-6 h-6" /></div>
          <h3 className="font-bold text-lg mb-1">Ripristina backup</h3>
          <p className="text-sm text-slate-500 mb-3">Carica uno ZIP creato in precedenza. I nomi di file/cartelle sono permissivi: solo i tentativi di <span className="mono">../</span> vengono bloccati.</p>
          <label className="flex items-center gap-2 text-sm text-slate-700 mb-3">
            <input type="checkbox" data-testid="backup-replace-toggle" checked={replace} onChange={(e)=>setReplace(e.target.checked)} />
            Sostituisci i dati esistenti (altrimenti unisce per <span className="mono">id</span>)
          </label>
          <label className="inline-flex items-center gap-2 h-10 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold cursor-pointer transition">
            <Upload className="w-4 h-4" />
            {restoring ? "Ripristino in corso…" : "Carica ZIP"}
            <input type="file" data-testid="backup-restore-input" accept=".zip,application/zip" className="hidden" onChange={doRestore} />
          </label>
        </div>
      </div>

      {result && (
        <div className={`card-elev p-5 ${result.error ? "border-rose-200" : ""}`} data-testid="backup-result">
          {result.error ? (
            <div className="flex items-start gap-3 text-rose-700"><AlertCircle className="w-5 h-5 mt-0.5" /><div><div className="font-bold">Errore</div><div className="text-sm mt-1">{result.error}</div></div></div>
          ) : (
            <div>
              <div className="flex items-center gap-2 mb-3"><ShieldCheck className="w-5 h-5 text-emerald-600" /><span className="font-bold text-emerald-700">Ripristino completato</span></div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {Object.entries(result.restored || {}).map(([k,v]) => (
                  <div key={k} className="rounded-lg bg-slate-50 border border-slate-100 p-3">
                    <div className="text-xs text-slate-500 uppercase tracking-wider">{k}</div>
                    <div className="stat-num text-xl">{v}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <div className="card-elev p-5 mt-4">
        <div className="flex items-start gap-3">
          <DatabaseBackup className="w-5 h-5 text-sky-600 mt-1" />
          <div className="text-sm text-slate-600">
            <div className="font-semibold text-slate-800 mb-1">Note tecniche</div>
            <ul className="list-disc pl-5 space-y-1">
              <li>Il backup include tutte le collezioni MongoDB dell'app in formato JSON dentro <span className="mono">data/</span>.</li>
              <li>Il restore accetta qualsiasi nome di file/cartella purché non contenga <span className="mono">../</span> o path assoluti — l'errore <em>"Percorso non ammesso"</em> non si presenterà su nomi come <span className="mono">immagine/</span>, <span className="mono">allegati/</span>, ecc.</li>
              <li>I documenti allegati ai soci sono inclusi (base64) nel file <span className="mono">data/documenti.json</span>.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
