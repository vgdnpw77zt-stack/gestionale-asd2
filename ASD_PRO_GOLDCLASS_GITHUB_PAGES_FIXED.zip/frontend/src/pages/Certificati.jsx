import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { PageHeader, Input, Select, Btn, Modal, Badge, EmptyState } from "./_ui";
import { toast } from "sonner";
import { Plus, Trash2, Pencil, AlertTriangle, CircleCheck, Clock } from "lucide-react";
import { fmtDate } from "../lib/utils-app";

const empty = { socio_id: "", tipo: "non_agonistico", data_rilascio: "", data_scadenza: "", medico: "", struttura: "", note: "" };

const statoBadge = (s) => {
  if (s === "valido") return <Badge tone="emerald"><CircleCheck className="w-3 h-3 mr-1 inline" />Valido</Badge>;
  if (s === "in_scadenza") return <Badge tone="amber"><Clock className="w-3 h-3 mr-1 inline" />In scadenza</Badge>;
  if (s === "scaduto") return <Badge tone="rose"><AlertTriangle className="w-3 h-3 mr-1 inline" />Scaduto</Badge>;
  return <Badge>—</Badge>;
};

export default function Certificati() {
  const [items, setItems] = useState([]);
  const [soci, setSoci] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);
  const [filtro, setFiltro] = useState("");

  const load = async () => {
    const p = filtro ? { stato: filtro } : {};
    const [c, s] = await Promise.all([api.get("/certificati", { params: p }), api.get("/soci")]);
    setItems(c.data); setSoci(s.data);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [filtro]);

  const sName = (id) => { const s = soci.find(x => x.id === id); return s ? `${s.cognome} ${s.nome}` : "—"; };
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const openNew = () => { setEditing(null); setForm(empty); setModal(true); };
  const openEdit = (c) => { setEditing(c); setForm({ ...empty, ...c }); setModal(true); };

  const save = async () => {
    if (!form.socio_id || !form.data_scadenza) { toast.error("Socio e data scadenza obbligatori"); return; }
    if (editing) await api.put(`/certificati/${editing.id}`, form);
    else await api.post("/certificati", form);
    toast.success("Certificato salvato"); setModal(false); load();
  };

  const del = async (c) => {
    if (!window.confirm("Eliminare certificato?")) return;
    await api.delete(`/certificati/${c.id}`); toast.success("Eliminato"); load();
  };

  return (
    <div>
      <PageHeader title="Certificati Medici" subtitle="Alert automatici per certificati in scadenza e scaduti."
        action={<Btn testid="cert-new-btn" onClick={openNew}><Plus className="w-4 h-4" />Nuovo certificato</Btn>} />

      <div className="card-elev p-4 mb-4 flex gap-2 flex-wrap">
        {["","valido","in_scadenza","scaduto"].map(k => (
          <button key={k} data-testid={`cert-filter-${k || "tutti"}`} onClick={()=>setFiltro(k)}
            className={`h-9 px-3 rounded-lg text-sm font-semibold transition ${filtro===k ? "bg-sky-600 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"}`}>
            {k === "" ? "Tutti" : k === "valido" ? "Validi" : k === "in_scadenza" ? "In scadenza" : "Scaduti"}
          </button>
        ))}
      </div>

      {items.length === 0 ? <EmptyState title="Nessun certificato" action={<Btn onClick={openNew}><Plus className="w-4 h-4" />Nuovo</Btn>} /> : (
        <div className="card-elev overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
              <tr>
                <th className="text-left px-4 py-3">Socio</th>
                <th className="text-left px-4 py-3">Tipo</th>
                <th className="text-left px-4 py-3">Rilascio</th>
                <th className="text-left px-4 py-3">Scadenza</th>
                <th className="text-left px-4 py-3">Giorni</th>
                <th className="text-left px-4 py-3">Stato</th>
                <th className="text-left px-4 py-3">Medico</th>
                <th className="text-right px-4 py-3">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {items.map((c) => (
                <tr key={c.id} className="border-t border-slate-100 hover:bg-slate-50" data-testid={`cert-row-${c.id}`}>
                  <td className="px-4 py-3 font-semibold">{sName(c.socio_id)}</td>
                  <td className="px-4 py-3"><Badge tone={c.tipo === "agonistico" ? "indigo" : "sky"}>{c.tipo === "agonistico" ? "Agonistico" : "Non agon."}</Badge></td>
                  <td className="px-4 py-3">{fmtDate(c.data_rilascio)}</td>
                  <td className="px-4 py-3">{fmtDate(c.data_scadenza)}</td>
                  <td className="px-4 py-3 mono">{c.giorni_alla_scadenza != null ? c.giorni_alla_scadenza : "—"}</td>
                  <td className="px-4 py-3">{statoBadge(c.stato)}</td>
                  <td className="px-4 py-3">{c.medico || "—"}</td>
                  <td className="px-4 py-3 text-right">
                    <button data-testid={`cert-edit-${c.id}`} onClick={()=>openEdit(c)} className="p-2 rounded-lg hover:bg-sky-50 text-sky-700"><Pencil className="w-4 h-4" /></button>
                    <button data-testid={`cert-delete-${c.id}`} onClick={()=>del(c)} className="p-2 rounded-lg hover:bg-rose-50 text-rose-600"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={modal} onClose={()=>setModal(false)} title={editing ? "Modifica certificato" : "Nuovo certificato"}>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <Select testid="cert-form-socio" label="Socio *" value={form.socio_id} onChange={set("socio_id")}>
              <option value="">Seleziona…</option>
              {soci.map(s => <option key={s.id} value={s.id}>{s.cognome} {s.nome}</option>)}
            </Select>
          </div>
          <Select testid="cert-form-tipo" label="Tipo" value={form.tipo} onChange={set("tipo")}>
            <option value="non_agonistico">Non agonistico</option>
            <option value="agonistico">Agonistico</option>
          </Select>
          <div />
          <Input type="date" testid="cert-form-rilascio" label="Data rilascio" value={form.data_rilascio} onChange={set("data_rilascio")} />
          <Input type="date" testid="cert-form-scadenza" label="Data scadenza *" value={form.data_scadenza} onChange={set("data_scadenza")} />
          <Input testid="cert-form-medico" label="Medico" value={form.medico} onChange={set("medico")} />
          <Input testid="cert-form-struttura" label="Struttura" value={form.struttura} onChange={set("struttura")} />
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <Btn variant="ghost" onClick={()=>setModal(false)}>Annulla</Btn>
          <Btn testid="cert-form-save" onClick={save}>{editing ? "Salva" : "Crea"}</Btn>
        </div>
      </Modal>
    </div>
  );
}
