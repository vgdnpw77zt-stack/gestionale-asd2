import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth.jsx";
import { toast } from "sonner";
import { CheckCircle2, XCircle, LogOut, ChevronLeft, Save, Trophy, Loader2 } from "lucide-react";
import { todayIso, fmtDate } from "../lib/utils-app";

export default function MobileIstruttore() {
  const { user, logout, login } = useAuth();
  const nav = useNavigate();
  const [step, setStep] = useState(user ? "corsi" : "login");
  const [creds, setCreds] = useState({ username: "", password: "" });
  const [corsi, setCorsi] = useState([]);
  const [corso, setCorso] = useState(null);
  const [soci, setSoci] = useState([]);
  const [rec, setRec] = useState({});
  const [data, setData] = useState(todayIso());
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (step === "corsi" && user) {
      api.get("/corsi").then(r => setCorsi(r.data));
      api.get("/soci").then(r => setSoci(r.data));
    }
  }, [step, user]);

  const doLogin = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await login(creds.username, creds.password);
      setStep("corsi");
    } catch (err) { toast.error(err?.response?.data?.detail || "Credenziali non valide"); }
    finally { setBusy(false); }
  };

  const selectCorso = async (c) => {
    setCorso(c);
    const r = await api.get("/presenze", { params: { corso_id: c.id, data } });
    const m = {}; r.data.forEach(p => { m[p.socio_id] = p.presente; });
    setRec(m);
    setStep("presenze");
  };

  const soggetti = soci.filter(s => s.attivo && (!corso?.disciplina || !s.disciplina || s.disciplina === corso.disciplina));
  const toggle = (id) => setRec({ ...rec, [id]: !rec[id] });
  const totalPres = soggetti.filter(s => rec[s.id]).length;

  const save = async () => {
    if (!corso) return;
    setBusy(true);
    try {
      const records = soggetti.map(s => ({ socio_id: s.id, presente: !!rec[s.id] }));
      await api.post("/presenze/bulk", { corso_id: corso.id, data, records });
      toast.success(`Salvate ${totalPres} presenze`);
      setStep("corsi");
    } catch { toast.error("Errore"); }
    finally { setBusy(false); }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="sticky top-0 z-30 gradient-header text-white p-4 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-2">
          {step === "presenze" && (
            <button data-testid="m-back" onClick={()=>setStep("corsi")} className="p-2 -ml-2 rounded-lg hover:bg-white/10"><ChevronLeft className="w-5 h-5" /></button>
          )}
          <div>
            <div className="text-[11px] uppercase tracking-widest text-sky-100">Istruttore</div>
            <div className="font-bold text-lg leading-tight">ASD Master</div>
          </div>
        </div>
        {user && (
          <div className="flex items-center gap-2 text-sm">
            <div className="hidden sm:block text-right">
              <div className="font-semibold">{user.username}</div>
              <div className="text-[10px] uppercase text-sky-100">{user.role || "utente"}</div>
            </div>
            <button data-testid="m-logout" onClick={logout} className="p-2 rounded-lg hover:bg-white/10"><LogOut className="w-4 h-4" /></button>
          </div>
        )}
      </header>

      <main className="p-4 max-w-lg mx-auto">
        {step === "login" && (
          <form onSubmit={doLogin} className="card-elev p-6 mt-6" data-testid="m-login-form">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl gradient-header text-white flex items-center justify-center"><Trophy className="w-5 h-5" /></div>
              <div>
                <h1 className="font-extrabold text-xl">Presenze rapide</h1>
                <p className="text-slate-500 text-xs">Accedi con le tue credenziali</p>
              </div>
            </div>
            <label className="text-xs font-semibold text-slate-500 uppercase">Utente</label>
            <input data-testid="m-login-user" value={creds.username} onChange={(e)=>setCreds({...creds, username: e.target.value})}
              className="w-full h-11 mt-1 mb-4 px-3 rounded-lg border border-slate-200 focus:border-sky-500 focus:ring-2 focus:ring-sky-100 outline-none" />
            <label className="text-xs font-semibold text-slate-500 uppercase">Password</label>
            <input data-testid="m-login-pass" type="password" value={creds.password} onChange={(e)=>setCreds({...creds, password: e.target.value})}
              className="w-full h-11 mt-1 mb-6 px-3 rounded-lg border border-slate-200 focus:border-sky-500 focus:ring-2 focus:ring-sky-100 outline-none" />
            <button data-testid="m-login-submit" disabled={busy}
              className="w-full h-12 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-semibold flex items-center justify-center gap-2 disabled:opacity-60">
              {busy && <Loader2 className="w-4 h-4 animate-spin" />}Accedi
            </button>
          </form>
        )}

        {step === "corsi" && (
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Data</label>
            <input type="date" data-testid="m-data" value={data} onChange={(e)=>setData(e.target.value)}
              className="w-full h-11 mt-1 mb-4 px-3 rounded-lg border border-slate-200 focus:border-sky-500 outline-none bg-white" />
            <div className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-2">Seleziona corso</div>
            <div className="space-y-2">
              {corsi.filter(c => c.attivo).map(c => (
                <button key={c.id} data-testid={`m-corso-${c.id}`} onClick={()=>selectCorso(c)}
                  className="w-full text-left card-elev p-4 hover:border-sky-300 transition">
                  <div className="font-bold text-slate-900">{c.nome}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{c.disciplina} • {c.giorno_settimana} {c.ora_inizio}–{c.ora_fine}</div>
                  <div className="text-xs text-slate-400 mt-1">📍 {c.luogo || "—"} • 👤 {c.istruttore || "—"}</div>
                </button>
              ))}
              {corsi.length === 0 && <div className="text-slate-400 text-sm text-center py-8">Nessun corso disponibile.</div>}
            </div>
          </div>
        )}

        {step === "presenze" && corso && (
          <div>
            <div className="card-elev p-4 mb-3">
              <div className="text-xs uppercase text-slate-400 tracking-widest">Corso</div>
              <div className="font-bold text-lg">{corso.nome}</div>
              <div className="text-xs text-slate-500">{fmtDate(data)}</div>
              <div className="mt-2 flex items-center justify-between">
                <div className="text-sm font-semibold text-emerald-700">{totalPres} presenti</div>
                <div className="text-sm text-slate-500">{soggetti.length} atleti</div>
              </div>
            </div>
            <div className="space-y-2 pb-24">
              {soggetti.map(s => (
                <button key={s.id} data-testid={`m-pres-${s.id}`} onClick={()=>toggle(s.id)}
                  className={`w-full flex items-center justify-between p-4 rounded-xl border transition ${rec[s.id] ? "bg-emerald-50 border-emerald-300" : "bg-white border-slate-200"}`}>
                  <div className="text-left">
                    <div className="font-semibold text-slate-900">{s.cognome} {s.nome}</div>
                    <div className="text-xs text-slate-500">{s.disciplina || "—"}</div>
                  </div>
                  {rec[s.id] ? <CheckCircle2 className="w-7 h-7 text-emerald-600" /> : <XCircle className="w-7 h-7 text-slate-300" />}
                </button>
              ))}
            </div>
            <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur border-t border-slate-200">
              <div className="max-w-lg mx-auto">
                <button data-testid="m-save" onClick={save} disabled={busy}
                  className="w-full h-12 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-semibold flex items-center justify-center gap-2 disabled:opacity-60">
                  {busy ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}Salva presenze
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
