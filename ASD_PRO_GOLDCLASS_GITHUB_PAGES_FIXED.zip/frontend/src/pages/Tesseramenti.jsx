import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { PageHeader, Input, Select, Btn, Modal, Badge, EmptyState } from "./_ui";
import { toast } from "sonner";
import { Plus, Trash2, Pencil, IdCard } from "lucide-react";
import { enti, fmtDate } from "../lib/utils-app";

const empty = { socio_id: "", stagione: "2024/2025", ente: "CSEN", numero_tessera: "", data_emissione: "", data_scadenza: "", note: "" };

export default function Tesseramenti() {
  const [items, setItems] = useState([]);
  const [soci, setSoci] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);
  const [stagione, setStagione] = useState("");

  const load = async () => {
    const p = stagione ? { stagione } : {};
    const [t, s] = await Promise.all([api.get("/tesseramenti", { params: p }), api.get("/soci")]);
    setItems(t.data); setSoci(s.data);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [stagione]);

  const sName = (id) => { const s = soci.find(x => x.id === id); return s ? `${s.cognome} ${s.nome}` : "—"; };

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const openNew = () => { setEditing(null); setForm(empty); setModal(true); };
  const openEdit = (t) => { setEditing(t); setForm({ ...empty, ...t }); setModal(true); };

  const save = async () => {
    if (!form.socio_id || !form.stagione || !form.ente) { toast.error("Compila socio, stagione ed ente"); return; }
    try {
      if (editing) await api.put(`/tesseramenti/${editing.id}`, form);
      else await api.post("/tesseramenti", form);
      toast.success("Tesseramento salvato"); setModal(false); load();
    } catch (e) { toast.error(e?.response?.data?.detail || "Errore"); }
  };

  const del = async (t) => {
    if (!window.confirm("Eliminare il tesseramento?")) return;
    await api.delete(`/tesseramenti/${t.id}`);
    toast.success("Eliminato"); load();
  };

  return (
    <div>
      <PageHeader title="Tesseramenti" subtitle="Tessere CSEN / UISP / CSI / Federazioni per stagione sportiva."
        action={<Btn testid="tess-new-btn" onClick={openNew}><Plus className="w-4 h-4" />Nuovo tesseramento</Btn>} />

      <div className="card-elev p-4 mb-4 flex gap-3 items-center">
        <select data-testid="tess-filter-stagione" value={stagione} onChange={(e)=>setStagione(e.target.value)}
          className="h-10 px-3 rounded-lg border border-slate-200 bg-white text-sm">
          <option value="">Tutte le stagioni</option>
          <option>2023/2024</option><option>2024/2025</option><option>2025/2026</option>
        </select>
      </div>

      {items.length === 0 ? (
        <EmptyState title="Nessun tesseramento" action={<Btn onClick={openNew}><Plus className="w-4 h-4" />Nuovo</Btn>} />
      ) : (
        <div className="card-elev overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
              <tr>
                <th className="text-left px-4 py-3">Socio</th>
                <th className="text-left px-4 py-3">Stagione</th>
                <th className="text-left px-4 py-3">Ente</th>
                <th className="text-left px-4 py-3">N. Tessera</th>
                <th className="text-left px-4 py-3">Emissione</th>
                <th className="text-left px-4 py-3">Scadenza</th>
                <th className="text-right px-4 py-3">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {items.map((t) => (
                <tr key={t.id} className="border-t border-slate-100 hover:bg-slate-50" data-testid={`tess-row-${t.id}`}>
                  <td className="px-4 py-3 font-semibold">{sName(t.socio_id)}</td>
                  <td className="px-4 py-3"><Badge tone="sky">{t.stagione}</Badge></td>
                  <td className="px-4 py-3"><Badge tone="indigo">{t.ente}</Badge></td>
                  <td className="px-4 py-3 mono">{t.numero_tessera || "—"}</td>
                  <td className="px-4 py-3">{fmtDate(t.data_emissione)}</td>
                  <td className="px-4 py-3">{fmtDate(t.data_scadenza)}</td>
                  <td className="px-4 py-3 text-right">
                    <button data-testid={`tess-edit-${t.id}`} onClick={()=>openEdit(t)} className="p-2 rounded-lg hover:bg-sky-50 text-sky-700"><Pencil className="w-4 h-4" /></button>
                    <button data-testid={`tess-delete-${t.id}`} onClick={()=>del(t)} className="p-2 rounded-lg hover:bg-rose-50 text-rose-600"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={modal} onClose={()=>setModal(false)} title={editing ? "Modifica tesseramento" : "Nuovo tesseramento"}>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <Select testid="tess-form-socio" label="Socio *" value={form.socio_id} onChange={set("socio_id")}>
              <option value="">Seleziona socio…</option>
              {soci.map(s => <option key={s.id} value={s.id}>{s.cognome} {s.nome}</option>)}
            </Select>
          </div>
          <Input testid="tess-form-stagione" label="Stagione *" placeholder="2024/2025" value={form.stagione} onChange={set("stagione")} />
          <Select testid="tess-form-ente" label="Ente *" value={form.ente} onChange={set("ente")}>
            {enti.map(e => <option key={e}>{e}</option>)}
          </Select>
          <Input testid="tess-form-numero" label="Numero tessera" value={form.numero_tessera} onChange={set("numero_tessera")} />
          <div />
          <Input type="date" testid="tess-form-emissione" label="Data emissione" value={form.data_emissione} onChange={set("data_emissione")} />
          <Input type="date" testid="tess-form-scadenza" label="Data scadenza" value={form.data_scadenza} onChange={set("data_scadenza")} />
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <Btn variant="ghost" onClick={()=>setModal(false)}>Annulla</Btn>
          <Btn testid="tess-form-save" onClick={save}>{editing ? "Salva" : "Crea"}</Btn>
        </div>
      </Modal>
    </div>
  );
}
