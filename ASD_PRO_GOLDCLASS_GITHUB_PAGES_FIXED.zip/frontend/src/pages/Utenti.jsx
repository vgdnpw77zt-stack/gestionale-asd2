import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { PageHeader, Btn, Select, Modal, Badge, EmptyState, Input } from "./_ui";
import { toast } from "sonner";
import { CheckCircle2, XCircle, Trash2, ShieldCheck, UserPlus } from "lucide-react";
import { fmtDateTime } from "../lib/utils-app";

const ROLES = ["admin","presidente","segretario","istruttore","lettore"];

export default function Utenti() {
  const [items, setItems] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ username: "", email: "", full_name: "", password: "", role: "segretario" });

  const load = async () => {
    try {
      const r = await api.get("/users");
      setItems(r.data);
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Solo l'admin può gestire gli utenti");
    }
  };
  useEffect(() => { load(); }, []);

  const create = async () => {
    if (!form.username || !form.email || !form.password) { toast.error("Compila utente, email, password"); return; }
    try {
      await api.post("/auth/register", form);
      // Auto-approva subito
      await load();
      const list = await api.get("/users");
      const created = list.data.find(u => u.username === form.username);
      if (created && created.status !== "approved") await api.post(`/users/${created.id}/approve`);
      toast.success("Utente creato e approvato");
      setModal(false); setForm({ username: "", email: "", full_name: "", password: "", role: "segretario" });
      load();
    } catch (e) { toast.error(e?.response?.data?.detail || "Errore creazione"); }
  };

  const approve = async (u) => { await api.post(`/users/${u.id}/approve`); toast.success("Utente approvato"); load(); };
  const disable = async (u) => { await api.post(`/users/${u.id}/disable`); toast.success("Utente disabilitato"); load(); };
  const del = async (u) => { if (!window.confirm(`Eliminare ${u.username}?`)) return; try { await api.delete(`/users/${u.id}`); toast.success("Eliminato"); load(); } catch (e) { toast.error(e?.response?.data?.detail || "Errore"); } };
  const changeRole = async (u, role) => { await api.put(`/users/${u.id}/role`, { role }); toast.success("Ruolo aggiornato"); load(); };

  const statusBadge = (st) => {
    if (st === "approved") return <Badge tone="emerald"><CheckCircle2 className="w-3 h-3 mr-1 inline" />Attivo</Badge>;
    if (st === "pending") return <Badge tone="amber">In attesa</Badge>;
    return <Badge tone="rose">Disabilitato</Badge>;
  };

  return (
    <div>
      <PageHeader title="Utenti Segreteria" subtitle="Multi-utente con ruoli: admin, presidente, segretario, istruttore, lettore."
        action={<Btn testid="usr-new-btn" onClick={()=>setModal(true)}><UserPlus className="w-4 h-4" />Nuovo utente</Btn>} />

      {items.length === 0 ? <EmptyState title="Nessun utente" /> : (
        <div className="card-elev overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
              <tr>
                <th className="text-left px-4 py-3">Utente</th>
                <th className="text-left px-4 py-3">Email</th>
                <th className="text-left px-4 py-3">Ruolo</th>
                <th className="text-left px-4 py-3">Stato</th>
                <th className="text-left px-4 py-3">Creato</th>
                <th className="text-right px-4 py-3">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {items.map(u => (
                <tr key={u.id} className="border-t border-slate-100 hover:bg-slate-50" data-testid={`usr-row-${u.id}`}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-sky-100 text-sky-700 font-bold flex items-center justify-center text-xs">{u.username?.slice(0,2).toUpperCase()}</div>
                      <div>
                        <div className="font-semibold">{u.username}</div>
                        <div className="text-xs text-slate-500">{u.full_name}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-slate-600">{u.email}</td>
                  <td className="px-4 py-3">
                    <select data-testid={`usr-role-${u.id}`} value={u.role} onChange={(e)=>changeRole(u, e.target.value)}
                      className="h-8 px-2 rounded-md border border-slate-200 bg-white text-sm">
                      {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </td>
                  <td className="px-4 py-3">{statusBadge(u.status)}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">{fmtDateTime(u.created_at)}</td>
                  <td className="px-4 py-3 text-right">
                    {u.status === "pending" && (
                      <button data-testid={`usr-approve-${u.id}`} onClick={()=>approve(u)} className="p-2 rounded-lg hover:bg-emerald-50 text-emerald-700" title="Approva"><ShieldCheck className="w-4 h-4" /></button>
                    )}
                    {u.status === "approved" && u.role !== "admin" && (
                      <button data-testid={`usr-disable-${u.id}`} onClick={()=>disable(u)} className="p-2 rounded-lg hover:bg-amber-50 text-amber-700" title="Disabilita"><XCircle className="w-4 h-4" /></button>
                    )}
                    {u.role !== "admin" && (
                      <button data-testid={`usr-del-${u.id}`} onClick={()=>del(u)} className="p-2 rounded-lg hover:bg-rose-50 text-rose-600"><Trash2 className="w-4 h-4" /></button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={modal} onClose={()=>setModal(false)} title="Nuovo utente segreteria">
        <div className="space-y-3">
          <Input testid="usr-form-username" label="Username *" value={form.username} onChange={(e)=>setForm({...form, username: e.target.value})} />
          <Input testid="usr-form-email" label="Email *" type="email" value={form.email} onChange={(e)=>setForm({...form, email: e.target.value})} />
          <Input testid="usr-form-name" label="Nome completo" value={form.full_name} onChange={(e)=>setForm({...form, full_name: e.target.value})} />
          <Input testid="usr-form-pass" label="Password * (min 6 caratteri)" type="password" value={form.password} onChange={(e)=>setForm({...form, password: e.target.value})} />
          <Select testid="usr-form-role" label="Ruolo" value={form.role} onChange={(e)=>setForm({...form, role: e.target.value})}>
            {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
          </Select>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <Btn variant="ghost" onClick={()=>setModal(false)}>Annulla</Btn>
          <Btn testid="usr-form-create" onClick={create}>Crea utente</Btn>
        </div>
      </Modal>
    </div>
  );
}
