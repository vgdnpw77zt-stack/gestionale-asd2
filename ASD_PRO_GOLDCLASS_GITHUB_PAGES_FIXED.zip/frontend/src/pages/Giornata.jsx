import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { PageHeader, Btn, Badge, EmptyState } from "./_ui";
import { fmtEuro, fmtDate } from "../lib/utils-app";
import { CalendarDays, Users2, Wallet, AlertTriangle, Clock, GraduationCap, ClipboardCheck, CreditCard } from "lucide-react";

export default function Giornata() {
  const [d, setD] = useState(null);
  useEffect(() => { api.get("/oggi").then(r => setD(r.data)); const t = setInterval(()=>api.get("/oggi").then(r=>setD(r.data)), 30000); return () => clearInterval(t); }, []);
  if (!d) return <div className="text-slate-500">Caricamento…</div>;

  const Stat = ({ icon: I, label, value, tone="sky", sub, testid }) => (
    <div className="card-elev p-5 relative overflow-hidden" data-testid={testid}>
      <div className={`absolute -right-6 -top-6 w-24 h-24 rounded-full opacity-10 bg-${tone}-500`} />
      <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
        <I className={`w-4 h-4 text-${tone}-600`} />{label}
      </div>
      <div className="stat-num text-3xl mt-2">{value}</div>
      {sub && <div className="text-xs text-slate-500 mt-1">{sub}</div>}
    </div>
  );

  return (
    <div>
      <PageHeader title={`Oggi — ${d.giorno_settimana}`} subtitle={fmtDate(d.data)} />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Stat icon={GraduationCap} label="Corsi oggi" value={d.corsi_oggi.length} tone="indigo" testid="oggi-corsi" />
        <Stat icon={ClipboardCheck} label="Presenze registrate" value={d.presenze_oggi_count} tone="emerald" testid="oggi-presenze" />
        <Stat icon={Wallet} label="Incassi oggi" value={fmtEuro(d.incassi_oggi)} tone="sky" sub={`${d.pagamenti_oggi.length} pagamenti`} testid="oggi-incassi" />
        <Stat icon={CreditCard} label="Iscrizioni in attesa" value={d.iscrizioni_pending} tone="amber" testid="oggi-iscr" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card-elev p-5">
          <h3 className="font-bold text-lg mb-3 flex items-center gap-2"><GraduationCap className="w-5 h-5 text-indigo-600" />Corsi di oggi</h3>
          {d.corsi_oggi.length === 0 ? <div className="text-sm text-slate-400">Nessun corso oggi.</div> : (
            <div className="space-y-2">
              {d.corsi_oggi.map(c => (
                <div key={c.id} className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-100">
                  <div>
                    <div className="font-semibold text-slate-900">{c.nome}</div>
                    <div className="text-xs text-slate-500">{c.disciplina} • {c.istruttore || "—"} • {c.luogo || "—"}</div>
                  </div>
                  <Badge tone="indigo">{c.ora_inizio}–{c.ora_fine}</Badge>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card-elev p-5">
          <h3 className="font-bold text-lg mb-3 flex items-center gap-2"><AlertTriangle className="w-5 h-5 text-rose-600" />Certificati critici</h3>
          <div className="flex gap-2 mb-3">
            <Badge tone="rose">{d.certificati_scaduti} scaduti</Badge>
            <Badge tone="amber">{d.certificati_in_scadenza_7gg.length} in scadenza 7gg</Badge>
          </div>
          {d.certificati_in_scadenza_7gg.length === 0 ? <div className="text-sm text-slate-400">Nessun certificato in scadenza nei prossimi 7 giorni.</div> : (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {d.certificati_in_scadenza_7gg.map((c,i) => (
                <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-amber-50 border border-amber-100">
                  <div className="text-sm font-semibold text-amber-900">{c.socio || "—"}</div>
                  <div className="text-xs text-amber-700">Scade il {fmtDate(c.data_scadenza)} ({c.giorni}g)</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card-elev p-5 lg:col-span-2">
          <h3 className="font-bold text-lg mb-3 flex items-center gap-2"><Wallet className="w-5 h-5 text-emerald-600" />Pagamenti di oggi</h3>
          {d.pagamenti_oggi.length === 0 ? <div className="text-sm text-slate-400">Nessun pagamento oggi.</div> : (
            <div className="space-y-2">
              {d.pagamenti_oggi.map(p => (
                <div key={p.id} className="flex items-center justify-between p-3 rounded-lg bg-emerald-50 border border-emerald-100">
                  <div>
                    <div className="text-xs text-emerald-700 mono">Ric. {p.numero_ricevuta}</div>
                    <div className="text-sm font-semibold text-emerald-900">{p.causale}</div>
                  </div>
                  <div className="text-lg font-bold text-emerald-700">{fmtEuro(p.importo)}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
