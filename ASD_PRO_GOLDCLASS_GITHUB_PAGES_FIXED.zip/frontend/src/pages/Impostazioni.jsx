import React, { useEffect, useState } from "react";
import { api, API } from "../lib/api";
import { PageHeader, Btn, Input, Textarea } from "./_ui";
import { toast } from "sonner";
import { Save, Building2, Mail, RefreshCw } from "lucide-react";
import { fileToBase64 } from "../lib/utils-app";

export default function Impostazioni() {
  const [s, setS] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => { api.get("/settings").then(r => setS(r.data)); }, []);

  if (!s) return <div className="text-slate-500">Caricamento…</div>;

  const set = (k) => (e) => setS({ ...s, [k]: e.target.type === "checkbox" ? e.target.checked : (e.target.type === "number" ? Number(e.target.value) : e.target.value) });

  const onLogo = async (e) => {
    const f = e.target.files?.[0]; if (!f) return;
    const b64 = await fileToBase64(f);
    setS({ ...s, logo_base64: b64 });
  };

  const useDefaultLogo = async () => {
    try {
      const token = localStorage.getItem("asd_token");
      const res = await fetch(`${API}/logo/default`, { headers: { Authorization: `Bearer ${token}` } });
      const blob = await res.blob();
      const reader = new FileReader();
      reader.onload = () => setS({ ...s, logo_base64: reader.result });
      reader.readAsDataURL(blob);
      toast.success("Logo predefinito caricato");
    } catch { toast.error("Errore caricamento logo"); }
  };

  const save = async () => {
    setSaving(true);
    try { await api.put("/settings", s); toast.success("Impostazioni salvate"); }
    catch { toast.error("Errore salvataggio"); }
    finally { setSaving(false); }
  };

  return (
    <div>
      <PageHeader title="Impostazioni ASD" subtitle="Dati anagrafici e fiscali della tua Associazione."
        action={<Btn testid="settings-save-btn" onClick={save} disabled={saving}><Save className="w-4 h-4" />Salva</Btn>} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="card-elev p-6 lg:col-span-2">
          <div className="flex items-center gap-2 mb-4 text-slate-700"><Building2 className="w-4 h-4" /><span className="text-sm font-semibold">Dati generali</span></div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2"><Input testid="set-ragione" label="Ragione sociale" value={s.ragione_sociale} onChange={set("ragione_sociale")} /></div>
            <Input testid="set-cf" label="Codice fiscale" value={s.codice_fiscale} onChange={set("codice_fiscale")} />
            <Input testid="set-piva" label="Partita IVA" value={s.partita_iva} onChange={set("partita_iva")} />
            <Input testid="set-coni" label="N. iscrizione Registro CONI/RAS" value={s.n_registro_coni} onChange={set("n_registro_coni")} />
            <Input testid="set-presidente" label="Presidente" value={s.presidente} onChange={set("presidente")} />
            <div className="sm:col-span-2"><Input testid="set-indirizzo" label="Indirizzo" value={s.indirizzo} onChange={set("indirizzo")} /></div>
            <Input testid="set-citta" label="Città" value={s.citta} onChange={set("citta")} />
            <Input testid="set-cap" label="CAP" value={s.cap} onChange={set("cap")} />
            <Input testid="set-prov" label="Provincia" value={s.provincia} onChange={set("provincia")} />
            <Input testid="set-tel" label="Telefono" value={s.telefono} onChange={set("telefono")} />
            <Input testid="set-email" label="Email" value={s.email} onChange={set("email")} />
            <div className="sm:col-span-2"><Input testid="set-iban" label="IBAN" value={s.iban} onChange={set("iban")} /></div>
          </div>
        </div>

        <div className="card-elev p-6">
          <div className="text-sm font-semibold text-slate-700 mb-3">Logo ASD</div>
          <div className="aspect-square rounded-xl bg-slate-50 border border-dashed border-slate-200 flex items-center justify-center overflow-hidden">
            {s.logo_base64 ? <img alt="logo" src={s.logo_base64} className="max-h-full max-w-full object-contain" /> : <span className="text-slate-400 text-sm">Nessun logo</span>}
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <label className="inline-flex items-center gap-2 h-10 px-4 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-700 text-sm font-semibold cursor-pointer transition">
              Carica logo
              <input type="file" accept="image/*" data-testid="set-logo-input" onChange={onLogo} className="hidden" />
            </label>
            <button data-testid="set-logo-default" onClick={useDefaultLogo}
              className="inline-flex items-center gap-2 h-10 px-4 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-sm font-semibold">
              <RefreshCw className="w-4 h-4" />Usa predefinito
            </button>
          </div>
          {s.logo_base64 && (
            <button data-testid="set-logo-remove" onClick={()=>setS({...s, logo_base64: ""})} className="mt-2 text-xs text-rose-600 hover:underline">Rimuovi logo</button>
          )}
        </div>
      </div>

      <div className="card-elev p-6 mt-4">
        <div className="flex items-center gap-2 mb-2 text-slate-700"><Mail className="w-4 h-4" /><span className="text-sm font-semibold">Server SMTP (invio email)</span></div>
        <p className="text-xs text-slate-500 mb-4">Configura Gmail (smtp.gmail.com:587), Aruba (smtps.aruba.it:465) o qualunque provider SMTP. La password è salvata solo sul tuo server locale.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          <div className="lg:col-span-2"><Input testid="set-smtp-host" label="Host SMTP" placeholder="smtp.gmail.com" value={s.smtp_host || ""} onChange={set("smtp_host")} /></div>
          <Input testid="set-smtp-port" type="number" label="Porta" value={s.smtp_port || 587} onChange={set("smtp_port")} />
          <Input testid="set-smtp-user" label="Utente" placeholder="tua@email.com" value={s.smtp_user || ""} onChange={set("smtp_user")} />
          <Input testid="set-smtp-pass" type="password" label="Password" placeholder="••••••••" value={s.smtp_password || ""} onChange={set("smtp_password")} />
          <label className="flex items-center gap-2 text-sm text-slate-700 mt-6">
            <input type="checkbox" data-testid="set-smtp-tls" checked={s.smtp_use_tls !== false} onChange={set("smtp_use_tls")} />
            STARTTLS (necessario per porta 587)
          </label>
          <Input testid="set-smtp-from" label="Email mittente" placeholder="segreteria@asd.it" value={s.smtp_from_email || ""} onChange={set("smtp_from_email")} />
          <Input testid="set-smtp-fromname" label="Nome mittente" placeholder="Segreteria ASD" value={s.smtp_from_name || ""} onChange={set("smtp_from_name")} />
        </div>
      </div>
    </div>
  );
}
