import React from "react";

export const PageHeader = ({ title, subtitle, action }) => (
  <div className="flex items-start justify-between mb-6 flex-wrap gap-3">
    <div>
      <div className="text-xs font-semibold uppercase tracking-widest text-sky-700">ASD Master</div>
      <h1 className="text-3xl font-extrabold tracking-tight">{title}</h1>
      {subtitle && <p className="text-slate-500 text-sm mt-1">{subtitle}</p>}
    </div>
    {action}
  </div>
);

export const Input = ({ label, testid, ...props }) => (
  <label className="block">
    {label && <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{label}</span>}
    <input data-testid={testid} {...props}
      className="mt-1 w-full h-10 px-3 rounded-lg border border-slate-200 bg-white focus:border-sky-500 focus:ring-2 focus:ring-sky-100 outline-none text-sm" />
  </label>
);

export const Select = ({ label, testid, children, ...props }) => (
  <label className="block">
    {label && <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{label}</span>}
    <select data-testid={testid} {...props}
      className="mt-1 w-full h-10 px-3 rounded-lg border border-slate-200 bg-white focus:border-sky-500 focus:ring-2 focus:ring-sky-100 outline-none text-sm">
      {children}
    </select>
  </label>
);

export const Textarea = ({ label, testid, ...props }) => (
  <label className="block">
    {label && <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{label}</span>}
    <textarea data-testid={testid} {...props}
      className="mt-1 w-full min-h-[90px] px-3 py-2 rounded-lg border border-slate-200 bg-white focus:border-sky-500 focus:ring-2 focus:ring-sky-100 outline-none text-sm" />
  </label>
);

export const Btn = ({ variant = "primary", className = "", testid, children, ...props }) => {
  const v = {
    primary: "bg-sky-600 hover:bg-sky-700 text-white",
    secondary: "bg-slate-100 hover:bg-slate-200 text-slate-800",
    ghost: "bg-transparent hover:bg-slate-100 text-slate-700",
    danger: "bg-rose-600 hover:bg-rose-700 text-white",
    success: "bg-emerald-600 hover:bg-emerald-700 text-white",
    outline: "bg-white border border-slate-200 hover:bg-slate-50 text-slate-800",
  }[variant];
  return (
    <button data-testid={testid} {...props}
      className={`h-10 px-4 rounded-lg text-sm font-semibold transition inline-flex items-center gap-2 disabled:opacity-60 ${v} ${className}`}>
      {children}
    </button>
  );
};

export const Modal = ({ open, onClose, title, children, wide }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={onClose} />
      <div className={`relative bg-white rounded-2xl shadow-2xl w-full ${wide ? "max-w-3xl" : "max-w-lg"} max-h-[90vh] overflow-y-auto`}>
        <div className="sticky top-0 bg-white/90 backdrop-blur border-b border-slate-100 px-6 py-4 flex items-center justify-between rounded-t-2xl">
          <h3 className="font-bold text-lg">{title}</h3>
          <button data-testid="modal-close-btn" onClick={onClose} className="text-slate-400 hover:text-slate-600 text-xl leading-none">×</button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
};

export const Badge = ({ tone = "slate", children, testid }) => {
  const t = {
    slate: "bg-slate-100 text-slate-700 border-slate-200",
    emerald: "bg-emerald-50 text-emerald-700 border-emerald-200",
    amber: "bg-amber-50 text-amber-700 border-amber-200",
    rose: "bg-rose-50 text-rose-700 border-rose-200",
    sky: "bg-sky-50 text-sky-700 border-sky-200",
    indigo: "bg-indigo-50 text-indigo-700 border-indigo-200",
  }[tone];
  return <span data-testid={testid} className={`inline-flex items-center px-2 py-0.5 rounded-full border text-xs font-semibold ${t}`}>{children}</span>;
};

export const EmptyState = ({ title = "Nessun elemento", subtitle, action }) => (
  <div className="card-elev p-10 text-center">
    <div className="text-slate-400 text-4xl mb-2">◍</div>
    <div className="font-semibold text-slate-800">{title}</div>
    {subtitle && <div className="text-sm text-slate-500 mt-1">{subtitle}</div>}
    {action && <div className="mt-4">{action}</div>}
  </div>
);
