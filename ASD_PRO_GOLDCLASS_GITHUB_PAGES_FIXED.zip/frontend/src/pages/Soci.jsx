import React, { useEffect, useState } from "react";
import { api, API } from "../lib/api";
import { PageHeader, Input, Select, Btn, Modal, Badge, EmptyState, Textarea } from "./_ui";
import { toast } from "sonner";
import { UserPlus, Search, Pencil, Trash2, Phone, Mail, User, FileUp, Download } from "lucide-react";
import { disciplines, fmtDate } from "../lib/utils-app";

const empty = {
  nome: "", cognome: "", codice_fiscale: "", data_nascita: "", luogo_nascita: "", sesso: "M",
  indirizzo: "", citta: "", cap: "", provincia: "", telefono: "", email: "",
  disciplina: "", ruolo: "Socio", contatto_emergenza_nome: "", contatto_emergenza_telefono: "",
  note: "", attivo: true,
};

export default function Soci() {
  const [items, setItems] = useState([]);
  const [q, setQ] = useState("");
  const [disc, setDisc] = useState("");
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [importResult, setImportResult] = useState(null);

  const load = async () => {
    const params = {};
    if (q) params.q = q;
    if (disc) params.disciplina = disc;
    const r = await api.get("/soci", { params });
    setItems(r.data);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [q, disc]);

  const openNew = () => { setEditing(null); setForm(empty); setModal(true); };
  const openEdit = (s) => { setEditing(s); setForm({ ...empty, ...s }); setModal(true); };

  const save = async () => {
    try {
      if (!form.nome || !form.cognome) { toast.error("Nome e cognome obbligatori"); return; }
      if (editing) {
        await api.put(`/soci/${editing.id}`, form);
        toast.success("Socio aggiornato");
      } else {
        await api.post("/soci", form);
        toast.success("Socio creato");
      }
      setModal(false); load();
    } catch (e) { toast.error(e?.response?.data?.detail || "Errore"); }
  };

  const del = async (s) => {
    if (!window.confirm(`Eliminare ${s.nome} ${s.cognome}?`)) return;
    await api.delete(`/soci/${s.id}`);
    toast.success("Socio eliminato");
    load();
  };

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });

  const downloadTemplate = async () => {
    const token = localStorage.getItem("asd_token");
    const res = await fetch(`${API}/soci/csv/template`, { headers: { Authorization: `Bearer ${token}` } });
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "soci_template.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  const importCsv = async (e) => {
    const file = e.target.files?.[0]; if (!file) return;
    try {
      const fd = new FormData(); fd.append("file", file);
      const r = await api.post("/soci/csv/import", fd, { headers: { "Content-Type": "multipart/form-data" } });
      setImportResult(r.data);
      toast.success(`${r.data.created} soci importati, ${r.data.skipped} saltati`);
      load();
    } catch (err) { toast.error(err?.response?.data?.detail || "Errore import"); }
    finally { e.target.value = ""; }
  };

  return (
    <div>
      <PageHeader title="Anagrafica Soci" subtitle="Gestisci soci, atleti, istruttori e dirigenti."
        action={
          <div className="flex gap-2 flex-wrap">
            <Btn variant="outline" testid="soci-csv-template-btn" onClick={downloadTemplate}><Download className="w-4 h-4" />Template CSV</Btn>
            <label className="h-10 px-4 rounded-lg text-sm font-semibold transition inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer">
              <FileUp className="w-4 h-4" />Importa CSV
              <input type="file" data-testid="soci-csv-import-input" accept=".csv,text/csv" className="hidden" onChange={importCsv} />
            </label>
            <Btn testid="soci-new-btn" onClick={openNew}><UserPlus className="w-4 h-4" />Nuovo socio</Btn>
          </div>
        } />

      {importResult && (
        <div className="card-elev p-4 mb-4 bg-emerald-50 border-emerald-200" data-testid="soci-import-result">
          <div className="flex items-center justify-between">
            <div className="text-sm text-emerald-800">
              <b>Import completato:</b> {importResult.created} creati • {importResult.skipped} saltati (duplicati o incompleti)
              {importResult.errors?.length > 0 && <div className="text-rose-700 mt-1 text-xs">Errori: {importResult.errors.slice(0,3).join(" | ")}</div>}
            </div>
            <button onClick={()=>setImportResult(null)} className="text-slate-400 hover:text-slate-700">×</button>
          </div>
        </div>
      )}

      <div className="card-elev p-4 mb-4 flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input data-testid="soci-search-input" placeholder="Cerca per nome, cognome, CF, email…" value={q} onChange={(e)=>setQ(e.target.value)}
            className="w-full h-10 pl-9 pr-3 rounded-lg border border-slate-200 bg-white outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-100 text-sm" />
        </div>
        <select data-testid="soci-filter-disciplina" value={disc} onChange={(e)=>setDisc(e.target.value)}
          className="h-10 px-3 rounded-lg border border-slate-200 bg-white text-sm">
          <option value="">Tutte le discipline</option>
          {disciplines.map((d) => <option key={d}>{d}</option>)}
        </select>
      </div>

      {items.length === 0 ? (
        <EmptyState title="Nessun socio" subtitle="Inizia aggiungendo il primo socio o popola dati demo dal Dashboard."
          action={<Btn onClick={openNew}><UserPlus className="w-4 h-4" />Nuovo socio</Btn>} />
      ) : (
        <div className="card-elev overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
              <tr>
                <th className="text-left px-4 py-3">Socio</th>
                <th className="text-left px-4 py-3">Contatti</th>
                <th className="text-left px-4 py-3">Disciplina</th>
                <th className="text-left px-4 py-3">Ruolo</th>
                <th className="text-left px-4 py-3">Stato</th>
                <th className="text-right px-4 py-3">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {items.map((s) => (
                <tr key={s.id} className="border-t border-slate-100 hover:bg-slate-50" data-testid={`socio-row-${s.id}`}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center font-bold">
                        {s.nome?.[0]}{s.cognome?.[0]}
                      </div>
                      <div>
                        <div className="font-semibold text-slate-900">{s.cognome} {s.nome}</div>
                        <div className="text-xs text-slate-500 mono">{s.codice_fiscale || "—"}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1 text-slate-700 text-xs"><Phone className="w-3 h-3" />{s.telefono || "—"}</div>
                    <div className="flex items-center gap-1 text-slate-500 text-xs mt-1"><Mail className="w-3 h-3" />{s.email || "—"}</div>
                  </td>
                  <td className="px-4 py-3"><Badge tone="indigo">{s.disciplina || "—"}</Badge></td>
                  <td className="px-4 py-3 text-slate-700">{s.ruolo}</td>
                  <td className="px-4 py-3">{s.attivo ? <Badge tone="emerald">Attivo</Badge> : <Badge tone="slate">Non attivo</Badge>}</td>
                  <td className="px-4 py-3 text-right">
                    <button data-testid={`socio-edit-${s.id}`} onClick={()=>openEdit(s)} className="p-2 rounded-lg hover:bg-sky-50 text-sky-700"><Pencil className="w-4 h-4" /></button>
                    <button data-testid={`socio-delete-${s.id}`} onClick={()=>del(s)} className="p-2 rounded-lg hover:bg-rose-50 text-rose-600"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={modal} onClose={()=>setModal(false)} title={editing ? "Modifica socio" : "Nuovo socio"} wide>
        <div className="grid grid-cols-2 gap-3">
          <Input testid="socio-form-nome" label="Nome *" value={form.nome} onChange={set("nome")} />
          <Input testid="socio-form-cognome" label="Cognome *" value={form.cognome} onChange={set("cognome")} />
          <Input testid="socio-form-cf" label="Codice Fiscale" value={form.codice_fiscale} onChange={set("codice_fiscale")} />
          <Input type="date" testid="socio-form-nascita" label="Data di nascita" value={form.data_nascita} onChange={set("data_nascita")} />
          <Input testid="socio-form-luogo" label="Luogo di nascita" value={form.luogo_nascita} onChange={set("luogo_nascita")} />
          <Select testid="socio-form-sesso" label="Sesso" value={form.sesso} onChange={set("sesso")}>
            <option value="M">M</option><option value="F">F</option>
          </Select>
          <Input testid="socio-form-indirizzo" label="Indirizzo" value={form.indirizzo} onChange={set("indirizzo")} />
          <Input testid="socio-form-citta" label="Città" value={form.citta} onChange={set("citta")} />
          <Input testid="socio-form-cap" label="CAP" value={form.cap} onChange={set("cap")} />
          <Input testid="socio-form-provincia" label="Provincia" value={form.provincia} onChange={set("provincia")} />
          <Input testid="socio-form-telefono" label="Telefono" value={form.telefono} onChange={set("telefono")} />
          <Input testid="socio-form-email" label="Email" value={form.email} onChange={set("email")} />
          <Select testid="socio-form-disciplina" label="Disciplina" value={form.disciplina} onChange={set("disciplina")}>
            <option value="">—</option>
            {disciplines.map((d) => <option key={d}>{d}</option>)}
          </Select>
          <Select testid="socio-form-ruolo" label="Ruolo" value={form.ruolo} onChange={set("ruolo")}>
            {["Socio","Atleta","Istruttore","Dirigente"].map((r) => <option key={r}>{r}</option>)}
          </Select>
          <Input testid="socio-form-em-nome" label="Contatto emergenza" value={form.contatto_emergenza_nome} onChange={set("contatto_emergenza_nome")} />
          <Input testid="socio-form-em-tel" label="Telefono emergenza" value={form.contatto_emergenza_telefono} onChange={set("contatto_emergenza_telefono")} />
          <div className="col-span-2"><Textarea testid="socio-form-note" label="Note" value={form.note} onChange={set("note")} /></div>
          <label className="col-span-2 flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" data-testid="socio-form-attivo" checked={form.attivo} onChange={set("attivo")} />
            Socio attivo
          </label>
        </div>
        <div className="mt-6 flex items-center justify-end gap-2">
          <Btn variant="ghost" onClick={()=>setModal(false)}>Annulla</Btn>
          <Btn testid="socio-form-save" onClick={save}>{editing ? "Salva modifiche" : "Crea socio"}</Btn>
        </div>
      </Modal>
    </div>
  );
}
