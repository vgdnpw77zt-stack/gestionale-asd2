import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { PageHeader, Btn, Select, Input, EmptyState, Badge, Modal } from "./_ui";
import { toast } from "sonner";
import { Upload, Trash2, Download, FileText } from "lucide-react";
import { fmtDateTime, fileToBase64 } from "../lib/utils-app";

const tipi = ["carta_identita", "privacy", "iscrizione", "altro"];

export default function Documenti() {
  const [items, setItems] = useState([]);
  const [soci, setSoci] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ socio_id: "", nome: "", tipo: "altro", file: null, note: "" });

  const load = async () => {
    const [d, s] = await Promise.all([api.get("/documenti"), api.get("/soci")]);
    setItems(d.data); setSoci(s.data);
  };
  useEffect(() => { load(); }, []);

  const sName = (id) => { const s = soci.find(x => x.id === id); return s ? `${s.cognome} ${s.nome}` : "—"; };

  const save = async () => {
    if (!form.socio_id || !form.file) { toast.error("Seleziona socio e file"); return; }
    try {
      const b64 = await fileToBase64(form.file);
      await api.post("/documenti", {
        socio_id: form.socio_id, nome: form.nome || form.file.name,
        tipo: form.tipo, file_name: form.file.name, file_base64: b64,
        mime_type: form.file.type || "application/octet-stream", note: form.note,
      });
      toast.success("Documento caricato");
      setModal(false); setForm({ socio_id: "", nome: "", tipo: "altro", file: null, note: "" });
      load();
    } catch (e) { toast.error("Errore caricamento"); }
  };

  const download = async (d) => {
    const r = await api.get(`/documenti/${d.id}`);
    const a = document.createElement("a");
    a.href = r.data.file_base64;
    a.download = r.data.file_name;
    a.click();
  };

  const del = async (d) => { if (!window.confirm("Eliminare documento?")) return; await api.delete(`/documenti/${d.id}`); toast.success("Eliminato"); load(); };

  return (
    <div>
      <PageHeader title="Documenti" subtitle="Allegati per ogni socio (CI, privacy, iscrizioni, altro)."
        action={<Btn testid="doc-new-btn" onClick={()=>setModal(true)}><Upload className="w-4 h-4" />Carica documento</Btn>} />

      {items.length === 0 ? <EmptyState title="Nessun documento" /> : (
        <div className="card-elev overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
              <tr>
                <th className="text-left px-4 py-3">Socio</th>
                <th className="text-left px-4 py-3">Nome</th>
                <th className="text-left px-4 py-3">Tipo</th>
                <th className="text-left px-4 py-3">Caricato</th>
                <th className="text-right px-4 py-3">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {items.map((d) => (
                <tr key={d.id} className="border-t border-slate-100 hover:bg-slate-50" data-testid={`doc-row-${d.id}`}>
                  <td className="px-4 py-3 font-semibold">{sName(d.socio_id)}</td>
                  <td className="px-4 py-3"><div className="flex items-center gap-2"><FileText className="w-4 h-4 text-slate-400" />{d.nome} <span className="text-xs text-slate-400">({d.file_name})</span></div></td>
                  <td className="px-4 py-3"><Badge tone="indigo">{d.tipo}</Badge></td>
                  <td className="px-4 py-3">{fmtDateTime(d.created_at)}</td>
                  <td className="px-4 py-3 text-right">
                    <button data-testid={`doc-dl-${d.id}`} onClick={()=>download(d)} className="p-2 rounded-lg hover:bg-sky-50 text-sky-700"><Download className="w-4 h-4" /></button>
                    <button data-testid={`doc-del-${d.id}`} onClick={()=>del(d)} className="p-2 rounded-lg hover:bg-rose-50 text-rose-600"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={modal} onClose={()=>setModal(false)} title="Carica documento">
        <div className="space-y-3">
          <Select testid="doc-form-socio" label="Socio *" value={form.socio_id} onChange={(e)=>setForm({...form, socio_id: e.target.value})}>
            <option value="">Seleziona…</option>
            {soci.map(s => <option key={s.id} value={s.id}>{s.cognome} {s.nome}</option>)}
          </Select>
          <Input testid="doc-form-nome" label="Nome documento" value={form.nome} onChange={(e)=>setForm({...form, nome: e.target.value})} />
          <Select testid="doc-form-tipo" label="Tipo" value={form.tipo} onChange={(e)=>setForm({...form, tipo: e.target.value})}>
            {tipi.map(t => <option key={t}>{t}</option>)}
          </Select>
          <label className="block">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">File *</span>
            <input data-testid="doc-form-file" type="file" onChange={(e)=>setForm({...form, file: e.target.files[0]})}
              className="mt-1 block w-full text-sm text-slate-600 file:h-10 file:px-4 file:rounded-lg file:border-0 file:bg-sky-50 file:text-sky-700 file:font-semibold" />
          </label>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <Btn variant="ghost" onClick={()=>setModal(false)}>Annulla</Btn>
          <Btn testid="doc-form-save" onClick={save}>Carica</Btn>
        </div>
      </Modal>
    </div>
  );
}
