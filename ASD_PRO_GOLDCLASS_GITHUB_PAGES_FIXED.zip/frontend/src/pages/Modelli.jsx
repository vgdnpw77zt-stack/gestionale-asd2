import React, { useEffect, useState } from "react";
import { api, API } from "../lib/api";
import { PageHeader, Btn, Select, Modal, Badge, EmptyState, Input, Textarea } from "./_ui";
import { toast } from "sonner";
import { FileText, Download, Wand2, FileType2 } from "lucide-react";

const catColors = {
  iscrizione: "sky", privacy: "indigo", minori: "rose", medici: "emerald",
  fiscale: "amber", contratti: "slate", verbali: "sky", altro: "slate",
};
const catLabels = {
  iscrizione: "Iscrizione", privacy: "Privacy", minori: "Minori",
  medici: "Medici", fiscale: "Fiscale", contratti: "Contratti",
  verbali: "Verbali", altro: "Altro",
};

export default function Modelli() {
  const [items, setItems] = useState([]);
  const [soci, setSoci] = useState([]);
  const [cat, setCat] = useState("");
  const [q, setQ] = useState("");
  const [modal, setModal] = useState(null); // current template
  const [socioId, setSocioId] = useState("");
  const [extra, setExtra] = useState({ stagione: "2024/2025", causale: "", importo: "", medico: "", scadenza_certificato: "" });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      const [m, s] = await Promise.all([api.get("/modelli"), api.get("/soci")]);
      setItems(m.data); setSoci(s.data);
    })();
  }, []);

  const cats = Array.from(new Set(items.map(x => x.category)));
  const filtered = items.filter(x =>
    (!cat || x.category === cat) &&
    (!q || x.title.toLowerCase().includes(q.toLowerCase()) || x.id.includes(q.toLowerCase()))
  );

  const downloadBlank = async (t) => {
    const token = localStorage.getItem("asd_token");
    const res = await fetch(`${API}/modelli/${t.id}/download`, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) return toast.error("Errore download");
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = t.file_name; a.click();
    URL.revokeObjectURL(url);
    toast.success("Modello scaricato");
  };

  const openCompile = (t) => {
    if (t.format !== "docx") { toast.error("Solo i modelli DOCX possono essere compilati"); return; }
    setModal(t); setSocioId(""); setExtra({ stagione: "2024/2025", causale: "", importo: "", medico: "", scadenza_certificato: "" });
  };

  const compile = async () => {
    if (!modal) return;
    setBusy(true);
    try {
      const token = localStorage.getItem("asd_token");
      const res = await fetch(`${API}/modelli/${modal.id}/compile`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ socio_id: socioId || null, extra }),
      });
      if (!res.ok) { const t = await res.text(); throw new Error(t); }
      const blob = await res.blob();
      const socio = soci.find(s => s.id === socioId);
      const name = socio ? `${modal.id}_${socio.cognome}_${socio.nome}.docx` : `${modal.id}.docx`;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a"); a.href = url; a.download = name; a.click();
      URL.revokeObjectURL(url);
      toast.success("DOCX compilato scaricato");
      setModal(null);
    } catch (e) { toast.error("Errore compilazione"); }
    finally { setBusy(false); }
  };

  return (
    <div>
      <PageHeader title="Archivio Modelli" subtitle="24 modelli documento (DOCX/PDF) precompilabili con i dati della tua ASD e dei soci." />

      <div className="card-elev p-4 mb-4 flex flex-wrap gap-2 items-center">
        <input data-testid="modelli-search" placeholder="Cerca modello…" value={q} onChange={(e)=>setQ(e.target.value)}
          className="flex-1 min-w-[220px] h-10 px-3 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-sky-500" />
        <button data-testid="mod-cat-all" onClick={()=>setCat("")}
          className={`h-9 px-3 rounded-lg text-sm font-semibold ${cat==="" ? "bg-sky-600 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"}`}>Tutti</button>
        {cats.map(c => (
          <button key={c} data-testid={`mod-cat-${c}`} onClick={()=>setCat(c)}
            className={`h-9 px-3 rounded-lg text-sm font-semibold ${cat===c ? "bg-sky-600 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200"}`}>
            {catLabels[c] || c}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? <EmptyState title="Nessun modello" /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(t => (
            <div key={t.id} className="card-elev p-5 flex flex-col" data-testid={`mod-card-${t.id}`}>
              <div className="flex items-start justify-between mb-3">
                <div className={`w-10 h-10 rounded-xl bg-${catColors[t.category]||"slate"}-100 text-${catColors[t.category]||"slate"}-700 flex items-center justify-center`}>
                  <FileType2 className="w-5 h-5" />
                </div>
                <Badge tone={catColors[t.category] || "slate"}>{catLabels[t.category] || t.category}</Badge>
              </div>
              <h3 className="font-bold text-slate-900 leading-tight">{t.title}</h3>
              <div className="text-xs text-slate-400 mt-1 mono">{t.file_name} • {t.size_kb} KB</div>
              <div className="mt-4 flex gap-2 pt-3 border-t border-slate-100 mt-auto">
                <button data-testid={`mod-dl-${t.id}`} onClick={()=>downloadBlank(t)}
                  className="flex-1 h-9 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm font-semibold inline-flex items-center justify-center gap-1.5">
                  <Download className="w-4 h-4" />Vuoto
                </button>
                {t.format === "docx" && (
                  <button data-testid={`mod-compile-${t.id}`} onClick={()=>openCompile(t)}
                    className="flex-1 h-9 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold inline-flex items-center justify-center gap-1.5">
                    <Wand2 className="w-4 h-4" />Compila
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={!!modal} onClose={()=>setModal(null)} title={modal ? `Compila: ${modal.title}` : ""} wide>
        {modal && (
          <div className="space-y-4">
            <div className="rounded-lg bg-sky-50 border border-sky-200 p-3 text-sm text-sky-900">
              <b>Come funziona:</b> seleziona un socio (opzionale) e compila i campi. I placeholder <span className="mono text-xs">[NOME E COGNOME]</span>, <span className="mono text-xs">[DENOMINAZIONE ASD]</span>, ecc. verranno sostituiti nel DOCX.
            </div>
            <Select testid="mod-compile-socio" label="Socio (opzionale)" value={socioId} onChange={(e)=>setSocioId(e.target.value)}>
              <option value="">— Nessuno —</option>
              {soci.map(s => <option key={s.id} value={s.id}>{s.cognome} {s.nome}</option>)}
            </Select>
            <div className="grid grid-cols-2 gap-3">
              <Input testid="mod-extra-stagione" label="Stagione sportiva" value={extra.stagione} onChange={(e)=>setExtra({...extra, stagione: e.target.value})} />
              <Input testid="mod-extra-causale" label="Causale pagamento" value={extra.causale} onChange={(e)=>setExtra({...extra, causale: e.target.value})} />
              <Input testid="mod-extra-importo" label="Importo €" value={extra.importo} onChange={(e)=>setExtra({...extra, importo: e.target.value})} />
              <Input testid="mod-extra-scad" type="date" label="Scadenza certificato" value={extra.scadenza_certificato} onChange={(e)=>setExtra({...extra, scadenza_certificato: e.target.value})} />
              <Input testid="mod-extra-medico" label="Medico certificatore" value={extra.medico} onChange={(e)=>setExtra({...extra, medico: e.target.value})} />
              <Input testid="mod-extra-sponsor" label="Sponsor / Controparte" value={extra.sponsor || ""} onChange={(e)=>setExtra({...extra, sponsor: e.target.value})} />
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <Btn variant="ghost" onClick={()=>setModal(null)}>Annulla</Btn>
              <Btn testid="mod-compile-generate" onClick={compile} disabled={busy}>
                <Wand2 className="w-4 h-4" />{busy ? "Genero…" : "Genera DOCX"}
              </Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
