// Same-origin proxy for the FastAPI backend.
// Set BACKEND_URL in Netlify environment variables, e.g. https://api.example.com
exports.handler = async (event) => {
  const backend = (process.env.BACKEND_URL || "").replace(/\/$/, "");
  if (!backend) {
    return { statusCode: 500, body: "BACKEND_URL non configurato su Netlify" };
  }

  const prefix = "/.netlify/functions/api";
  const path = event.path.startsWith(prefix)
    ? event.path.slice(prefix.length)
    : event.path.replace(/^\/api/, "");
  const query = event.rawQuery ? `?${event.rawQuery}` : "";
  const url = `${backend}/api${path || "/"}${query}`;

  const headers = { ...event.headers };
  delete headers.host;
  delete headers["content-length"];
  delete headers["x-nf-request-id"];

  let body;
  if (event.body != null) {
    body = event.isBase64Encoded
      ? Buffer.from(event.body, "base64")
      : event.body;
  }

  try {
    const response = await fetch(url, {
      method: event.httpMethod,
      headers,
      body: ["GET", "HEAD"].includes(event.httpMethod) ? undefined : body,
      redirect: "manual",
    });

    const contentType = response.headers.get("content-type") || "";
    const buffer = Buffer.from(await response.arrayBuffer());
    const isText = /^(text\/|application\/json|application\/xml|application\/javascript)/i.test(contentType);

    const responseHeaders = {};
    response.headers.forEach((value, key) => {
      if (!['content-length', 'transfer-encoding', 'connection'].includes(key.toLowerCase())) {
        responseHeaders[key] = value;
      }
    });

    return {
      statusCode: response.status,
      headers: responseHeaders,
      isBase64Encoded: !isText,
      body: isText ? buffer.toString("utf8") : buffer.toString("base64"),
    };
  } catch (error) {
    return {
      statusCode: 502,
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ detail: "Backend non raggiungibile", error: String(error?.message || error) }),
    };
  }
};
