# ASD Master — PRD

## Problema originale
> "confronta queste due versioni del programma, creane una totalmente funzionante con tutte le skills necessarie, elimina il superfluo sapendo che per ora non mettero il programma online e lo utilizzerò prevlentemente su mac, e un software gestionale per asd e quando vado a ripristinare il backuo mi da errore Errore restore: Percorso non ammesso nel backup: immagine ecc ecc o altro..."

## Scelte utente
- Web app fullstack (React + FastAPI + MongoDB), uso locale su Mac
- Tutte le funzionalità: anagrafica, tesseramenti, quote, certificati medici, corsi, presenze, documenti, comunicazioni, backup/restore, impostazioni
- Login admin locale (credenziali da `.env`)
- Assistente AI (Claude Sonnet 4.6 via Emergent LLM Key)
- Italiano, stile moderno pulito, palette sportiva

## Architettura
- **Backend**: FastAPI single-file (`server.py`) con router `/api`, MongoDB (motor), JWT auth, Emergent Integrations per LLM.
- **Frontend**: React 19 + React Router 7 + Tailwind + shadcn (sonner per toast) + recharts + lucide-react.
- **Font**: Outfit / Plus Jakarta Sans / JetBrains Mono.

## Moduli implementati (2026-02)
1. Login admin (JWT) — credenziali `admin / admin123` da `.env`
2. Dashboard con statistiche live e grafici (linee/barre)
3. Anagrafica Soci — CRUD, ricerca full-text, filtri
4. Tesseramenti — CSEN/UISP/CSI/FIP/FIGC/... per stagione
5. Quote & Pagamenti — ricevute numerate progressive, stampa
6. Certificati Medici — alert automatici valido/in_scadenza/scaduto (30gg)
7. Corsi & Calendario — griglia card con giorno/ora/luogo
8. Presenze — check-in rapido per corso+data (bulk save)
9. Documenti — upload/download allegati (base64 in Mongo)
10. Comunicazioni — modelli sollecito certificato, quota, assemblea
11. Assistente AI — Claude Sonnet 4-6, suggerimenti pronti + storico
12. Backup / Restore — export ZIP completo, restore permissivo (fix del bug "Percorso non ammesso")
13. Impostazioni ASD — dati anagrafici, fiscali, logo

## Fix del bug segnalato
- Il vecchio codice aveva una **whitelist rigida** di cartelle ammesse (`media/`, `database/`, `pdf/`, `user_static/`, ecc.). Qualsiasi ZIP che conteneva nomi diversi (es. `immagine/`, `allegati/`) veniva rifiutato con `Percorso non ammesso nel backup`.
- Nuovo comportamento: la funzione `_is_safe_relpath` blocca **solo** path traversal (`../`) e path assoluti. Qualsiasi altro nome di file/cartella è ammesso. File non JSON sotto `data/` vengono ignorati silenziosamente.
- Testato con ZIP contenente `immagini/qualcosa.png` → restore OK.

## Credenziali test
Vedi `/app/memory/test_credentials.md`.

## Backlog / Prossimi step
- P1: Export PDF ricevute (server-side reportlab) invece che solo stampa HTML
- P1: Presenze — vista storico e statistiche per socio
- P2: Import CSV soci (bulk onboarding)
- P2: Invio email comunicazioni (Resend integration)
- P2: Multi-utente con ruoli (segreteria / presidente / lettore)
- P3: Build app desktop Mac (electron o webview) per uso 100% offline
