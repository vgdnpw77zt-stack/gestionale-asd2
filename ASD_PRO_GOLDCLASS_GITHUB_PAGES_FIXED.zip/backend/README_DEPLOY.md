# Backend ASD Pro Goldclass

Questo backend è FastAPI + MongoDB. Netlify ospita il frontend React; il backend va eseguito su un servizio server/container e deve avere un MongoDB raggiungibile.

## Variabili obbligatorie
- `MONGO_URL`
- `DB_NAME`
- `JWT_SECRET`
- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`
- `CORS_ORIGINS` = dominio Netlify del frontend

Le integrazioni Stripe, Resend e AI sono opzionali e funzionano solo se le relative variabili sono configurate.

## Avvio container
`docker build -t asd-pro-goldclass-backend .`

`docker run --env-file .env -p 8000:8000 asd-pro-goldclass-backend`

Health check: `GET /api/`.
